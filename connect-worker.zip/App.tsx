import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Layout } from './components/Layout';
import { Login } from './pages/Login';
import { RoleSelector } from './components/RoleSelector';
import { ClientDashboard } from './pages/ClientDashboard';
import { WorkerDashboard } from './pages/WorkerDashboard';
import { AdminDashboard } from './pages/AdminDashboard';
import { ProfileSettings } from './pages/ProfileSettings';
import { Loader2 } from 'lucide-react';

const AppContent: React.FC = () => {
  const { user, isLoading, currentView } = useApp();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  let content;

  // Global Settings View Override
  if (currentView === 'settings') {
    content = <ProfileSettings />;
  } else {
    // Dashboard Logic based on role
    if (!user.roleSelected) {
       content = <RoleSelector />;
    } else if (user.role === 'client') {
       content = <ClientDashboard />;
    } else if (user.role === 'worker') {
       content = <WorkerDashboard />;
    } else if (user.role === 'admin') {
       content = <AdminDashboard />;
    } else {
       content = <RoleSelector />;
    }
  }

  return (
    <Layout>
      <div className="space-y-6">
        {content}
      </div>
    </Layout>
  );
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;