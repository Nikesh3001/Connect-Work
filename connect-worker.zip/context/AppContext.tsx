import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { User, Job } from '../types';
import { api } from '../services/store';

type AppView = 'dashboard' | 'settings';

interface AppContextType {
  user: User | null;
  isLoading: boolean;
  currentView: AppView;
  setView: (view: AppView) => void;
  login: (email: string, pass: string) => Promise<void>;
  register: (data: any) => Promise<void>;
  logout: () => void;
  updateUserProfile: (data: Partial<User>) => Promise<void>;
  refreshUser: () => void;
  requestNotificationPermission: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [currentView, setView] = useState<AppView>('dashboard');
  
  // Ref to track the last time we checked for jobs to avoid notifying about old jobs on reload
  const lastJobCheckRef = useRef<number>(Date.now());

  // Load session on mount
  useEffect(() => {
    const checkSession = () => {
      const stored = localStorage.getItem('connectwork_db_v3');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.currentUser) {
          setUser(parsed.currentUser);
        }
      }
      setIsLoading(false);
    };
    checkSession();
  }, []);

  // Real-time Notification Listener
  useEffect(() => {
    if (user?.role === 'worker') {
        // Automatically ask for permission if not decided
        if (Notification.permission === 'default') {
            Notification.requestPermission();
        }

        const handleStorageChange = (e: StorageEvent) => {
            if (e.key === 'connectwork_db_v3' && e.newValue) {
                const db = JSON.parse(e.newValue);
                const jobs = db.jobs as Job[];
                
                // Filter for NEW jobs posted after our last check
                const newJobs = jobs.filter(j => j.postedAt > lastJobCheckRef.current && j.status === 'OPEN');
                
                if (newJobs.length > 0) {
                    // Update timestamp to now so we don't notify again for these
                    lastJobCheckRef.current = Date.now();

                    newJobs.forEach(job => {
                        // 1. Check Category Match
                        const hasCategory = user.workerProfile?.categories.includes(job.category);
                        
                        // 2. Check Location Match (Fuzzy)
                        // Checks if user's location is inside job location OR job location is inside user's
                        const userLoc = user.location?.toLowerCase() || '';
                        const jobLoc = job.location?.toLowerCase() || '';
                        const hasLocation = userLoc && jobLoc && (jobLoc.includes(userLoc) || userLoc.includes(jobLoc));

                        if (hasCategory && hasLocation) {
                            if (Notification.permission === 'granted') {
                                new Notification(`New ${job.category} Job!`, {
                                    body: `${job.title} in ${job.location}`,
                                    // Using a standard placeholder icon if none exists
                                    icon: 'https://cdn-icons-png.flaticon.com/512/3043/3043233.png'
                                });
                            }
                        }
                    });
                }
            }
        };

        window.addEventListener('storage', handleStorageChange);
        return () => window.removeEventListener('storage', handleStorageChange);
    }
  }, [user]);

  const refreshUser = () => {
    const stored = localStorage.getItem('connectwork_db_v3');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.currentUser) {
          setUser(parsed.currentUser);
        }
      }
  }

  const login = async (email: string, pass: string) => {
    setIsLoading(true);
    try {
      const loggedInUser = await api.login(email, pass);
      setUser(loggedInUser);
      setView('dashboard');
      lastJobCheckRef.current = Date.now(); // Reset check time on login
    } catch (e) {
      console.error(e);
      throw e;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: any) => {
    setIsLoading(true);
    try {
        const newUser = await api.register(data);
        setUser(newUser);
        setView('dashboard');
        lastJobCheckRef.current = Date.now();
    } catch (e) {
        console.error(e);
        throw e;
    } finally {
        setIsLoading(false);
    }
  }

  const logout = async () => {
    await api.logout();
    setUser(null);
    setView('dashboard');
  };

  const updateUserProfile = async (data: Partial<User>) => {
    setIsLoading(true);
    try {
      const updated = await api.updateUser(data);
      setUser(updated);
    } finally {
      setIsLoading(false);
    }
  };

  const requestNotificationPermission = async () => {
      if (!('Notification' in window)) {
          alert("This browser does not support desktop notification");
          return;
      }
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
          new Notification("Notifications Enabled", { body: "You will now receive job alerts!" });
      }
  };

  return (
    <AppContext.Provider value={{ user, isLoading, currentView, setView, login, register, logout, updateUserProfile, refreshUser, requestNotificationPermission }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};