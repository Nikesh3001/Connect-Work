import React from 'react';
import { useApp } from '../context/AppContext';
import { LogOut, User as UserIcon, Briefcase, ShieldCheck } from 'lucide-react';
import { APP_NAME } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { user, logout, updateUserProfile, currentView, setView } = useApp();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col max-w-md mx-auto shadow-2xl overflow-hidden border-x border-slate-200">
      {/* Header */}
      <header className="bg-indigo-600 text-white p-4 flex justify-between items-center sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-bold tracking-tight">{APP_NAME}</h1>
          {user && (
            <span className="text-xs bg-indigo-700 px-2 py-0.5 rounded-full uppercase tracking-wider font-semibold">
              {user.role}
            </span>
          )}
        </div>
        
        {user && (
          <div className="flex items-center gap-3">
             {user.isAdmin && <ShieldCheck size={20} className="text-yellow-300" />}
             {!user.isAdmin && user.roleSelected && (
                <button 
                  onClick={() => updateUserProfile({ roleSelected: false })} 
                  className="text-xs bg-indigo-500 hover:bg-indigo-400 text-white px-2 py-1 rounded transition-colors"
                >
                  Switch Role
                </button>
             )}
            <button onClick={logout} className="p-2 hover:bg-indigo-700 rounded-full transition-colors">
              <LogOut size={20} />
            </button>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-4 scrollbar-hide">
        {children}
      </main>

      {/* Bottom Nav (Only if logged in and not admin) */}
      {user && !user.isAdmin && user.roleSelected && (
        <nav className="bg-white border-t border-slate-200 p-3 flex justify-around items-center">
          <button 
            onClick={() => setView('dashboard')}
            className={`flex flex-col items-center transition-colors ${currentView === 'dashboard' ? 'text-indigo-600' : 'text-slate-400'}`}
          >
            <Briefcase size={24} />
            <span className="text-xs font-medium mt-1">Jobs</span>
          </button>
           <button 
             onClick={() => setView('settings')}
             className={`flex flex-col items-center transition-colors ${currentView === 'settings' ? 'text-indigo-600' : 'text-slate-400'}`}
           >
            <UserIcon size={24} />
            <span className="text-xs font-medium mt-1">Profile</span>
          </button>
        </nav>
      )}
    </div>
  );
};