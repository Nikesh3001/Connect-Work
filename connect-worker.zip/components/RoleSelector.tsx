import React from 'react';
import { useApp } from '../context/AppContext';
import { Briefcase, Hammer, Shield } from 'lucide-react';
import { Role } from '../types';

export const RoleSelector: React.FC = () => {
  const { user, updateUserProfile } = useApp();

  if (!user) return null;

  const handleRoleSelect = (role: Role) => {
    updateUserProfile({ role, roleSelected: true });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="text-center py-6">
        <h2 className="text-2xl font-bold text-slate-800">Welcome, {user.name || 'User'}!</h2>
        <p className="text-slate-500 mt-2">How would you like to use KaamConnect today?</p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {/* Client Card */}
        <button
          onClick={() => handleRoleSelect('client')}
          className="group relative flex items-center p-6 bg-white border-2 border-slate-100 rounded-xl shadow-sm hover:border-indigo-500 hover:shadow-md transition-all text-left"
        >
          <div className="bg-indigo-50 p-4 rounded-full mr-4 group-hover:bg-indigo-100 transition-colors">
            <Briefcase className="w-8 h-8 text-indigo-600" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-800">Hire a Worker</h3>
            <p className="text-sm text-slate-500">Post jobs and find skilled local help.</p>
          </div>
        </button>

        {/* Worker Card */}
        <button
          onClick={() => handleRoleSelect('worker')}
          className="group relative flex items-center p-6 bg-white border-2 border-slate-100 rounded-xl shadow-sm hover:border-emerald-500 hover:shadow-md transition-all text-left"
        >
          <div className="bg-emerald-50 p-4 rounded-full mr-4 group-hover:bg-emerald-100 transition-colors">
            <Hammer className="w-8 h-8 text-emerald-600" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-800">Find Work</h3>
            <p className="text-sm text-slate-500">Browse jobs nearby and earn money.</p>
          </div>
        </button>
        
        {/* Admin Link (Hidden usually, visible for demo if admin) */}
        {user.isAdmin && (
           <button
           onClick={() => handleRoleSelect('admin')}
           className="mt-4 flex items-center justify-center p-3 text-slate-400 hover:text-slate-600 text-sm"
         >
           <Shield className="w-4 h-4 mr-2" />
           Access Admin Panel
         </button>
        )}
      </div>
    </div>
  );
};