export type Role = 'client' | 'worker' | 'admin';

export type JobStatus = 'OPEN' | 'BOOKED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';

export enum WorkerCategory {
  PLUMBER = 'Plumber',
  ELECTRICIAN = 'Electrician',
  MECHANIC = 'Mechanic',
  CARPENTER = 'Carpenter',
  PAINTER = 'Painter',
  MASON = 'Mason',
  CLEANER = 'Cleaner',
  DRIVER = 'Driver',
  LABORER = 'Daily Wage Laborer',
  OTHER = 'Other'
}

export interface PersonalEvent {
  id: string;
  title: string;
  date: number; // Timestamp for the date
  time: string; // e.g., "14:00"
  description: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  phone: string;
  location: string;
  coords?: { lat: number; lng: number };
  language?: string;
  role: Role;
  roleSelected?: boolean;
  isVerified: boolean;
  workerProfile?: WorkerProfile;
  isAdmin?: boolean;
}

export interface WorkerProfile {
  categories: WorkerCategory[];
  experienceYears: number;
  bio: string;
  availability: boolean;
  personalSchedule?: PersonalEvent[];
}

export interface Job {
  id: string;
  clientId: string;
  clientName: string;
  clientPhone: string;
  title: string;
  description: string;
  category: WorkerCategory;
  location: string;
  coords?: { lat: number; lng: number };
  postedAt: number;
  status: JobStatus;
  interestedWorkerIds: string[];
  assignedWorkerId?: string;
}

export interface Notification {
  id: string;
  userId: string;
  message: string;
  type: 'info' | 'success' | 'warning';
  read: boolean;
  timestamp: number;
}