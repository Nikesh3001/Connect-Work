import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/store';
import { Job, WorkerCategory, User, PersonalEvent } from '../types';
import { CATEGORIES_LIST, MOCK_CITIES } from '../constants';
import { MapPin, Phone, CheckCircle, AlertCircle, Calendar, ChevronLeft, ChevronRight, Plus, X, Trash2, Clock, RefreshCw } from 'lucide-react';

export const WorkerDashboard: React.FC = () => {
  const { user, refreshUser } = useApp();
  const [activeTab, setActiveTab] = useState<'find' | 'schedule' | 'profile'>('find');
  const [availableJobs, setAvailableJobs] = useState<Job[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Profile Form
  const [editName, setEditName] = useState(user?.name || '');
  const [editBio, setEditBio] = useState(user?.workerProfile?.bio || '');
  const [selectedCats, setSelectedCats] = useState<WorkerCategory[]>(user?.workerProfile?.categories || []);
  const [editLocation, setEditLocation] = useState(user?.location || '');

  // Calendar State
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDateJobs, setSelectedDateJobs] = useState<Job[]>([]);
  const [selectedDateEvents, setSelectedDateEvents] = useState<PersonalEvent[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  
  // Add Event Form State
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [newEventTitle, setNewEventTitle] = useState('');
  const [newEventTime, setNewEventTime] = useState('');
  const [newEventDesc, setNewEventDesc] = useState('');

  const loadJobs = async () => {
    if (!user) return;
    setIsRefreshing(true);
    const jobs = await api.getJobs({ type: 'worker', userId: user.id });
    setAvailableJobs(jobs);
    setIsRefreshing(false);
  };

  useEffect(() => {
    if (user && (activeTab === 'find' || activeTab === 'schedule')) {
      loadJobs();
    }
  }, [user, activeTab]);

  // Listen for storage events to auto-refresh jobs when a client posts a job in another tab
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
        if (e.key === 'connectwork_db_v3') {
            loadJobs();
        }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [user]);

  // Calendar Logic
  useEffect(() => {
     if(activeTab === 'schedule') {
        const isSameDay = (d1: Date, d2: Date) => 
            d1.getDate() === d2.getDate() && 
            d1.getMonth() === d2.getMonth() && 
            d1.getFullYear() === d2.getFullYear();

        // Filter Jobs
        const jobsOnDate = availableJobs.filter(job => {
            if (job.status !== 'BOOKED' || job.assignedWorkerId !== user?.id) return false;
            return isSameDay(new Date(job.postedAt), selectedDate);
        });
        setSelectedDateJobs(jobsOnDate);

        // Filter Personal Events
        const myEvents = user?.workerProfile?.personalSchedule || [];
        const eventsOnDate = myEvents.filter(event => 
            isSameDay(new Date(event.date), selectedDate)
        );
        setSelectedDateEvents(eventsOnDate);
     }
  }, [selectedDate, availableJobs, activeTab, user]);

  const toggleCategory = (cat: WorkerCategory) => {
    if (selectedCats.includes(cat)) {
      setSelectedCats(selectedCats.filter(c => c !== cat));
    } else {
      setSelectedCats([...selectedCats, cat]);
    }
  };

  const handleSaveProfile = async () => {
    await api.updateUser({
      name: editName,
      location: editLocation,
      workerProfile: {
        categories: selectedCats,
        bio: editBio,
        experienceYears: 3, 
        availability: true,
        personalSchedule: user?.workerProfile?.personalSchedule || []
      }
    });
    refreshUser();
    alert('Profile Updated! You are active and visible to clients.');
  };

  const handleExpressInterest = async (jobId: string) => {
    if (!user) return;
    await api.expressInterest(jobId, user.id);
    const jobs = await api.getJobs({ type: 'worker', userId: user.id });
    setAvailableJobs(jobs);
  };

  const handleAddEvent = async () => {
    if(!newEventTitle || !newEventTime) return;
    
    await api.addPersonalEvent({
        title: newEventTitle,
        time: newEventTime,
        description: newEventDesc,
        date: selectedDate.getTime()
    });
    
    // Reset form
    setNewEventTitle('');
    setNewEventTime('');
    setNewEventDesc('');
    setShowAddEvent(false);
    refreshUser(); 
  };

  const handleDeleteEvent = async (eventId: string) => {
    if(window.confirm("Delete this event?")) {
        await api.deletePersonalEvent(eventId);
        refreshUser();
    }
  };

  // Calendar Helpers
  const getDaysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const getFirstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

  const renderCalendar = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);
    
    const days = [];
    // Empty slots
    for (let i = 0; i < firstDay; i++) {
        days.push(<div key={`empty-${i}`} className="h-10"></div>);
    }
    
    // Days
    for (let day = 1; day <= daysInMonth; day++) {
        const dateObj = new Date(year, month, day);
        
        // Check for jobs
        const hasJob = availableJobs.some(job => {
             const jobDate = new Date(job.postedAt);
             return job.assignedWorkerId === user?.id && 
                    job.status === 'BOOKED' &&
                    jobDate.getDate() === day && 
                    jobDate.getMonth() === month && 
                    jobDate.getFullYear() === year;
        });

        // Check for personal events
        const hasEvent = user?.workerProfile?.personalSchedule?.some(event => {
            const evDate = new Date(event.date);
            return evDate.getDate() === day && 
                   evDate.getMonth() === month && 
                   evDate.getFullYear() === year;
        });

        const isSelected = selectedDate.getDate() === day && selectedDate.getMonth() === month;

        days.push(
            <button 
                key={day}
                onClick={() => setSelectedDate(dateObj)}
                className={`h-10 w-10 mx-auto rounded-full flex flex-col items-center justify-center relative text-sm font-medium transition-all ${
                    isSelected ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-100 text-slate-700'
                }`}
            >
                {day}
                <div className="flex gap-0.5 mt-0.5">
                    {hasJob && (
                        <span className={`w-1 h-1 rounded-full ${isSelected ? 'bg-white' : 'bg-green-500'}`}></span>
                    )}
                    {hasEvent && (
                        <span className={`w-1 h-1 rounded-full ${isSelected ? 'bg-white' : 'bg-orange-400'}`}></span>
                    )}
                </div>
            </button>
        );
    }
    return days;
  };

  const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));


  if (!user?.workerProfile && activeTab === 'find') {
     return (
         <div className="p-6 text-center">
             <AlertCircle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
             <h2 className="text-xl font-bold mb-2">Become a Worker</h2>
             <p className="text-slate-600 mb-6">You need to set up your worker profile before you can see jobs.</p>
             <button 
                onClick={() => setActiveTab('profile')}
                className="bg-indigo-600 text-white px-6 py-2 rounded-lg"
            >
                Create Profile
            </button>
         </div>
     )
  }

  return (
    <div className="pb-20">
      {/* Tabs */}
      <div className="flex border-b border-slate-200 mb-6 overflow-x-auto">
        <button
          onClick={() => setActiveTab('find')}
          className={`flex-1 py-3 text-sm font-medium whitespace-nowrap px-4 ${
            activeTab === 'find' ? 'text-emerald-600 border-b-2 border-emerald-600' : 'text-slate-500'
          }`}
        >
          Find Work
        </button>
        <button
          onClick={() => setActiveTab('schedule')}
          className={`flex-1 py-3 text-sm font-medium whitespace-nowrap px-4 ${
            activeTab === 'schedule' ? 'text-emerald-600 border-b-2 border-emerald-600' : 'text-slate-500'
          }`}
        >
          Schedule
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`flex-1 py-3 text-sm font-medium whitespace-nowrap px-4 ${
            activeTab === 'profile' ? 'text-emerald-600 border-b-2 border-emerald-600' : 'text-slate-500'
          }`}
        >
          My Profile
        </button>
      </div>

      {activeTab === 'find' ? (
        <div className="space-y-4 animate-fade-in relative">
            {/* Refresh Indicator */}
            <div className="flex justify-between items-center mb-2 px-1">
                 <h3 className="font-bold text-slate-700">Matching Jobs</h3>
                 <button onClick={loadJobs} className="p-1.5 bg-white border rounded-full hover:bg-slate-50 text-slate-500">
                    <RefreshCw size={14} className={isRefreshing ? "animate-spin" : ""} />
                 </button>
            </div>

          {availableJobs.length === 0 ? (
            <div className="text-center py-10 text-slate-400">
              <p>No matching jobs found nearby.</p>
            </div>
          ) : (
            availableJobs.map((job) => {
              const hasApplied = job.interestedWorkerIds.includes(user!.id);
              const isAssignedToMe = job.assignedWorkerId === user!.id;
              
              if (job.status === 'BOOKED' && !isAssignedToMe) return null; 

              return (
                <div key={job.id} className={`p-4 rounded-xl border shadow-sm ${
                    isAssignedToMe ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-slate-200'
                }`}>
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-semibold text-slate-800">{job.category}</h3>
                    <span className="text-xs text-slate-500">{new Date(job.postedAt).toLocaleDateString()}</span>
                  </div>
                  <p className="text-sm text-slate-600 mb-3">{job.description}</p>
                  <div className="flex items-center text-xs text-slate-400 mb-4">
                    <MapPin className="w-3 h-3 mr-1" /> {job.location}
                  </div>

                  {isAssignedToMe ? (
                     <div className="mt-3 pt-3 border-t border-emerald-200">
                         <p className="text-emerald-800 font-bold text-sm mb-2">YOU ARE BOOKED!</p>
                         <div className="bg-white p-3 rounded border border-emerald-100">
                            <p className="text-xs text-slate-500">Client Contact:</p>
                            <p className="font-medium">{job.clientName}</p>
                            <div className="flex gap-2 mt-2">
                                <a href={`tel:${job.clientPhone}`} className="flex items-center px-3 py-1 bg-emerald-600 text-white rounded text-xs">
                                    <Phone size={12} className="mr-1"/> Call
                                </a>
                            </div>
                         </div>
                     </div>
                  ) : (
                    <button
                        onClick={() => handleExpressInterest(job.id)}
                        disabled={hasApplied}
                        className={`w-full py-2 rounded-lg text-sm font-medium transition-colors ${
                        hasApplied
                            ? 'bg-slate-100 text-slate-500 cursor-not-allowed'
                            : 'bg-emerald-600 text-white hover:bg-emerald-700'
                        }`}
                    >
                        {hasApplied ? 'Interest Sent' : 'I am Interested'}
                    </button>
                  )}
                </div>
              );
            })
          )}
        </div>
      ) : activeTab === 'schedule' ? (
        <div className="animate-fade-in space-y-6">
            {/* Calendar Header */}
            <div className="flex items-center justify-between px-2">
                <button onClick={prevMonth} className="p-2 hover:bg-slate-100 rounded-full"><ChevronLeft size={20}/></button>
                <h3 className="font-bold text-lg text-slate-800">
                    {currentDate.toLocaleDateString('default', { month: 'long', year: 'numeric' })}
                </h3>
                <button onClick={nextMonth} className="p-2 hover:bg-slate-100 rounded-full"><ChevronRight size={20}/></button>
            </div>

            {/* Calendar Grid */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                <div className="grid grid-cols-7 mb-2 text-center text-xs font-semibold text-slate-400 uppercase tracking-wide">
                    <div>Su</div><div>Mo</div><div>Tu</div><div>We</div><div>Th</div><div>Fr</div><div>Sa</div>
                </div>
                <div className="grid grid-cols-7 gap-y-1">
                    {renderCalendar()}
                </div>
                <div className="mt-4 flex items-center justify-center gap-4 text-xs text-slate-500">
                    <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500"></span> Client Job</div>
                    <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-orange-400"></span> My Schedule</div>
                </div>
            </div>

            {/* Agenda View */}
            <div>
                <div className="flex justify-between items-center mb-4 px-1">
                    <h4 className="font-bold text-slate-800">
                        {selectedDate.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}
                    </h4>
                    <button 
                        onClick={() => setShowAddEvent(true)}
                        className="flex items-center gap-1 text-xs bg-indigo-600 text-white px-3 py-1.5 rounded-full hover:bg-indigo-700"
                    >
                        <Plus size={14} /> Add Event
                    </button>
                </div>

                {showAddEvent && (
                    <div className="bg-white p-4 rounded-xl border border-indigo-100 shadow-lg mb-4 animate-in fade-in slide-in-from-top-2">
                        <div className="flex justify-between items-center mb-3">
                            <h5 className="font-bold text-indigo-900 text-sm">New Personal Event</h5>
                            <button onClick={() => setShowAddEvent(false)} className="text-slate-400 hover:text-slate-600"><X size={16}/></button>
                        </div>
                        <input 
                            type="text" 
                            placeholder="Event Title (e.g. Doctor Appt)" 
                            className="w-full text-sm p-2 border border-slate-300 rounded mb-2"
                            value={newEventTitle}
                            onChange={e => setNewEventTitle(e.target.value)}
                        />
                        <input 
                            type="time" 
                            className="w-full text-sm p-2 border border-slate-300 rounded mb-2"
                            value={newEventTime}
                            onChange={e => setNewEventTime(e.target.value)}
                        />
                        <textarea 
                            placeholder="Description (Optional)" 
                            rows={2}
                            className="w-full text-sm p-2 border border-slate-300 rounded mb-2"
                            value={newEventDesc}
                            onChange={e => setNewEventDesc(e.target.value)}
                        />
                        <button 
                            onClick={handleAddEvent}
                            disabled={!newEventTitle || !newEventTime}
                            className="w-full bg-indigo-600 text-white text-sm py-2 rounded font-medium disabled:opacity-50"
                        >
                            Save to Schedule
                        </button>
                    </div>
                )}

                <div className="space-y-3">
                    {selectedDateJobs.length === 0 && selectedDateEvents.length === 0 ? (
                        <div className="text-center py-8 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                            <Calendar className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                            <p className="text-slate-500 text-sm">No schedule for today.</p>
                        </div>
                    ) : (
                        <>
                            {/* Client Jobs */}
                            {selectedDateJobs.map(job => (
                                <div key={job.id} className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl shadow-sm relative overflow-hidden">
                                    <div className="absolute top-0 left-0 w-1 h-full bg-emerald-500"></div>
                                    <div className="flex justify-between items-center mb-1">
                                        <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">Client Job</span>
                                        <span className="text-xs text-emerald-700 font-bold bg-emerald-100 px-2 py-0.5 rounded">9:00 AM (Est)</span>
                                    </div>
                                    <h4 className="font-bold text-slate-800">{job.category} - {job.description.substring(0, 30)}...</h4>
                                    <div className="mt-2 pt-2 border-t border-emerald-100 flex justify-between items-center">
                                        <div className="text-xs text-slate-600">
                                            Client: <span className="font-medium">{job.clientName}</span>
                                        </div>
                                        <a href={`tel:${job.clientPhone}`} className="bg-white border border-emerald-200 text-emerald-700 p-1.5 rounded-lg shadow-sm">
                                            <Phone size={14} />
                                        </a>
                                    </div>
                                </div>
                            ))}

                            {/* Personal Events */}
                            {selectedDateEvents.map(event => (
                                <div key={event.id} className="bg-orange-50 border border-orange-200 p-4 rounded-xl shadow-sm relative overflow-hidden">
                                    <div className="absolute top-0 left-0 w-1 h-full bg-orange-400"></div>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <div className="flex items-center gap-2 mb-1">
                                                <Clock size={14} className="text-orange-500"/>
                                                <span className="text-sm font-bold text-slate-700">{event.time}</span>
                                            </div>
                                            <h4 className="font-bold text-slate-800">{event.title}</h4>
                                            {event.description && <p className="text-xs text-slate-500 mt-1">{event.description}</p>}
                                        </div>
                                        <button 
                                            onClick={() => handleDeleteEvent(event.id)}
                                            className="text-orange-300 hover:text-red-500 transition-colors p-1"
                                        >
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </>
                    )}
                </div>
            </div>
        </div>
      ) : (
        <div className="space-y-6 animate-fade-in p-1">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
            <input
              type="text"
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              className="w-full p-3 border border-slate-300 rounded-lg"
              placeholder="e.g. Ramesh Kumar"
            />
          </div>

          <div>
             <label className="block text-sm font-medium text-slate-700 mb-1">Base Location</label>
             <select
                value={editLocation}
                onChange={(e) => setEditLocation(e.target.value)}
                className="w-full p-3 border border-slate-300 rounded-lg"
              >
                <option value="">Select City</option>
                {MOCK_CITIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Skills (Select all that apply)</label>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES_LIST.map((cat) => (
                <button
                  key={cat}
                  onClick={() => toggleCategory(cat)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${
                    selectedCats.includes(cat)
                      ? 'bg-emerald-600 border-emerald-600 text-white'
                      : 'bg-white border-slate-300 text-slate-600'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Short Bio</label>
            <textarea
              value={editBio}
              onChange={(e) => setEditBio(e.target.value)}
              rows={3}
              className="w-full p-3 border border-slate-300 rounded-lg"
              placeholder="e.g. 5 years experience in house wiring..."
            />
          </div>

          <button
            onClick={handleSaveProfile}
            className="w-full py-3 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700"
          >
            Save Profile
          </button>
        </div>
      )}
    </div>
  );
};