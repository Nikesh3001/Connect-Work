import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Mail, Lock, User, Phone, MapPin, ArrowRight, Chrome, Facebook, Key } from 'lucide-react';
import { APP_NAME } from '../constants';

export const Login: React.FC = () => {
  const { login, register } = useApp();
  const [isLoginView, setIsLoginView] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  // Form States
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');

  const fillDemo = (role: 'client' | 'worker') => {
    if (role === 'client') {
        setEmail('priya@example.com');
        setPassword('password');
    } else {
        setEmail('raju@example.com');
        setPassword('password');
    }
    setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    try {
      if (isLoginView) {
        await login(email, password);
      } else {
        if (!name || !email || !password || !phone) {
            throw new Error("Please fill in all required fields.");
        }
        await register({ name, email, password, phone, location });
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-[90vh] flex flex-col items-center justify-center p-4 bg-slate-50">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden">
        {/* Header Tabs */}
        <div className="flex text-sm font-medium border-b border-slate-100">
          <button 
            onClick={() => setIsLoginView(true)}
            className={`flex-1 py-4 text-center transition-colors ${isLoginView ? 'text-indigo-600 bg-indigo-50 border-b-2 border-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Login
          </button>
          <button 
            onClick={() => setIsLoginView(false)}
            className={`flex-1 py-4 text-center transition-colors ${!isLoginView ? 'text-indigo-600 bg-indigo-50 border-b-2 border-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Sign Up
          </button>
        </div>

        <div className="p-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-slate-800">
              {isLoginView ? 'Welcome Back!' : 'Create Account'}
            </h2>
            <p className="text-slate-500 text-sm mt-2">
              {isLoginView ? 'Enter your credentials to access your account.' : `Join ${APP_NAME} to find work or hire experts.`}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLoginView && (
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  type="text"
                  placeholder="Full Name"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="block w-full pl-10 pr-3 py-3 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
                />
              </div>
            )}

            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail className="h-5 w-5 text-slate-400" />
              </div>
              <input
                type="email"
                placeholder="Email Address"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full pl-10 pr-3 py-3 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
              />
            </div>

            {!isLoginView && (
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Phone className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  type="tel"
                  placeholder="Phone Number"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="block w-full pl-10 pr-3 py-3 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
                />
              </div>
            )}
            
            {!isLoginView && (
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <MapPin className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  type="text"
                  placeholder="City / Location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="block w-full pl-10 pr-3 py-3 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
                />
              </div>
            )}

            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Lock className="h-5 w-5 text-slate-400" />
              </div>
              <input
                type="password"
                placeholder="Password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full pl-10 pr-3 py-3 border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
              />
            </div>

            {isLoginView && (
              <div className="text-right">
                <button type="button" className="text-sm text-indigo-600 hover:text-indigo-800 font-medium">
                  Forgot Password?
                </button>
              </div>
            )}

            {error && <p className="text-red-500 text-sm text-center animate-pulse">{error}</p>}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full flex justify-center items-center py-3.5 px-4 border border-transparent rounded-lg shadow-sm text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 transition-all transform active:scale-[0.98]"
            >
              {isSubmitting ? 'Processing...' : (isLoginView ? 'Sign In' : 'Create Account')}
              {!isSubmitting && <ArrowRight className="ml-2 w-4 h-4" />}
            </button>
          </form>

          {/* Demo Helper */}
          {isLoginView && (
             <div className="mt-6 bg-indigo-50 border border-indigo-100 rounded-xl p-4">
                 <div className="flex items-center gap-2 mb-3 text-indigo-800 font-semibold text-sm">
                     <Key className="w-4 h-4" /> Demo Credentials
                 </div>
                 <div className="grid grid-cols-2 gap-3">
                     <button 
                        onClick={() => fillDemo('client')}
                        className="text-xs text-left p-2 bg-white rounded border border-indigo-100 hover:border-indigo-300 transition-colors"
                     >
                        <div className="font-bold text-slate-700">Client Demo</div>
                        <div className="text-slate-500 mt-1">priya@example.com</div>
                        <div className="text-slate-400">pass: password</div>
                     </button>
                     <button 
                        onClick={() => fillDemo('worker')}
                        className="text-xs text-left p-2 bg-white rounded border border-indigo-100 hover:border-indigo-300 transition-colors"
                     >
                        <div className="font-bold text-slate-700">Worker Demo</div>
                        <div className="text-slate-500 mt-1">raju@example.com</div>
                        <div className="text-slate-400">pass: password</div>
                     </button>
                 </div>
             </div>
          )}

          {/* Social Login Visuals */}
          <div className="mt-8">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-slate-500">Or continue with</span>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-3 max-w-xs mx-auto">
              <button className="flex justify-center items-center py-2 px-4 border border-slate-200 rounded-lg shadow-sm bg-white hover:bg-slate-50 transition-colors">
                 <Chrome className="w-5 h-5 text-red-500" />
              </button>
              <button className="flex justify-center items-center py-2 px-4 border border-slate-200 rounded-lg shadow-sm bg-white hover:bg-slate-50 transition-colors">
                 <Facebook className="w-5 h-5 text-blue-600" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};