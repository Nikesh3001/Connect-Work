import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { User, Mail, MapPin, Phone, Lock, Save, Camera, Languages, Bell } from 'lucide-react';
import { SUPPORTED_LANGUAGES } from '../constants';

export const ProfileSettings: React.FC = () => {
  const { user, updateUserProfile, requestNotificationPermission } = useApp();
  const [isEditing, setIsEditing] = useState(false);
  
  // Local state for form
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [location, setLocation] = useState(user?.location || '');
  const [password, setPassword] = useState(user?.password || '');
  const [language, setLanguage] = useState(user?.language || 'en');

  if (!user) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateUserProfile({
        name,
        email,
        phone,
        location,
        password,
        language
    });
    setIsEditing(false);
    alert('Settings updated successfully!');
  };

  return (
    <div className="animate-fade-in pb-20">
      <div className="bg-indigo-600 pb-16 pt-6 px-4 rounded-b-3xl -mx-4 mb-4 shadow-lg text-white">
          <div className="flex flex-col items-center">
             <div className="relative">
                <div className="w-24 h-24 rounded-full bg-white/20 flex items-center justify-center text-4xl font-bold backdrop-blur-sm border-4 border-white/10 mb-3">
                    {user.name.charAt(0).toUpperCase()}
                </div>
                <button className="absolute bottom-2 right-0 bg-white text-indigo-600 p-1.5 rounded-full shadow-lg">
                    <Camera size={16} />
                </button>
             </div>
             <h2 className="text-xl font-bold">{user.name}</h2>
             <p className="text-indigo-100 text-sm">{user.role.toUpperCase()}</p>
          </div>
      </div>

      <div className="px-4 -mt-10">
          <form onSubmit={handleSave} className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 space-y-5">
             <div className="flex justify-between items-center mb-2">
                 <h3 className="font-bold text-slate-800">Account Settings</h3>
                 <button 
                    type="button" 
                    onClick={() => setIsEditing(!isEditing)}
                    className="text-sm text-indigo-600 font-medium hover:text-indigo-800"
                 >
                    {isEditing ? 'Cancel' : 'Edit'}
                 </button>
             </div>

             <div className="space-y-4">
                 
                 {/* Language Section */}
                 <div className="group">
                    <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">App Language</label>
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg group-focus-within:ring-2 group-focus-within:ring-indigo-500/20 transition-all">
                        <Languages className="w-5 h-5 text-slate-400" />
                        <select 
                            disabled={!isEditing}
                            value={language}
                            onChange={(e) => setLanguage(e.target.value)}
                            className="bg-transparent w-full outline-none text-slate-700 disabled:text-slate-500 bg-none"
                        >
                            {SUPPORTED_LANGUAGES.map(lang => (
                                <option key={lang.code} value={lang.code}>{lang.name}</option>
                            ))}
                        </select>
                    </div>
                 </div>

                 {/* Notifications Section */}
                 {user.role === 'worker' && (
                     <div className="group">
                        <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">Alerts</label>
                        <button 
                            type="button"
                            onClick={requestNotificationPermission}
                            className="w-full flex items-center gap-3 p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-all text-left"
                        >
                            <Bell className="w-5 h-5 text-indigo-500" />
                            <span className="text-slate-700 text-sm">Enable Job Notifications</span>
                        </button>
                     </div>
                 )}

                 <div className="group">
                    <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">Full Name</label>
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg group-focus-within:ring-2 group-focus-within:ring-indigo-500/20 transition-all">
                        <User className="w-5 h-5 text-slate-400" />
                        <input 
                            type="text" 
                            disabled={!isEditing}
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="bg-transparent w-full outline-none text-slate-700 disabled:text-slate-500"
                        />
                    </div>
                 </div>

                 <div className="group">
                    <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">Email Address</label>
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg group-focus-within:ring-2 group-focus-within:ring-indigo-500/20 transition-all">
                        <Mail className="w-5 h-5 text-slate-400" />
                        <input 
                            type="email" 
                            disabled={!isEditing}
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="bg-transparent w-full outline-none text-slate-700 disabled:text-slate-500"
                        />
                    </div>
                 </div>

                 <div className="group">
                    <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">Phone Number</label>
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg group-focus-within:ring-2 group-focus-within:ring-indigo-500/20 transition-all">
                        <Phone className="w-5 h-5 text-slate-400" />
                        <input 
                            type="tel" 
                            disabled={!isEditing}
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            className="bg-transparent w-full outline-none text-slate-700 disabled:text-slate-500"
                        />
                    </div>
                 </div>

                 <div className="group">
                    <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">Default Location</label>
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg group-focus-within:ring-2 group-focus-within:ring-indigo-500/20 transition-all">
                        <MapPin className="w-5 h-5 text-slate-400" />
                        <input 
                            type="text" 
                            disabled={!isEditing}
                            value={location}
                            onChange={(e) => setLocation(e.target.value)}
                            className="bg-transparent w-full outline-none text-slate-700 disabled:text-slate-500"
                        />
                    </div>
                 </div>

                 <div className="group">
                    <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">Password</label>
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg group-focus-within:ring-2 group-focus-within:ring-indigo-500/20 transition-all">
                        <Lock className="w-5 h-5 text-slate-400" />
                        <input 
                            type={isEditing ? "text" : "password"}
                            disabled={!isEditing}
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="bg-transparent w-full outline-none text-slate-700 disabled:text-slate-500"
                        />
                    </div>
                 </div>
             </div>

             {isEditing && (
                 <button 
                    type="submit"
                    className="w-full flex justify-center items-center py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 shadow-md shadow-indigo-200 transition-all active:scale-95"
                 >
                    <Save className="w-4 h-4 mr-2" /> Save Changes
                 </button>
             )}
          </form>

          <div className="mt-6 text-center text-xs text-slate-400">
             <p>Member since {new Date().getFullYear()}</p>
             <p className="mt-1">Version 1.0.3</p>
          </div>
      </div>
    </div>
  );
};