import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/store';
import { optimizeJobDescription } from '../services/geminiService';
import { Job, WorkerCategory, User } from '../types';
import { CATEGORIES_LIST, MOCK_CITIES } from '../constants';
import { MapPin, Wand2, Phone, MessageCircle, CheckCircle, Clock, Navigation, Loader2 } from 'lucide-react';

export const ClientDashboard: React.FC = () => {
  const { user, refreshUser } = useApp();
  const [activeTab, setActiveTab] = useState<'post' | 'my-jobs'>('post');
  
  // Job Form State
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<WorkerCategory>(WorkerCategory.PLUMBER);
  const [location, setLocation] = useState(user?.location || '');
  const [coords, setCoords] = useState<{lat: number, lng: number} | undefined>(undefined);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [isPosting, setIsPosting] = useState(false);
  const [isLocating, setIsLocating] = useState(false);

  // My Jobs State
  const [myJobs, setMyJobs] = useState<Job[]>([]);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [interestedWorkers, setInterestedWorkers] = useState<User[]>([]);

  // Profile completion check
  if (!user?.name) {
    return (
      <div className="p-6 bg-white rounded-xl shadow-sm">
        <h2 className="text-xl font-bold mb-4">Complete Profile</h2>
        <input 
            type="text" 
            placeholder="Your Name" 
            className="w-full p-3 border rounded mb-4"
            onBlur={(e) => {
                if(e.target.value) {
                    api.updateUser({ name: e.target.value }).then(refreshUser);
                }
            }}
        />
        <p className="text-sm text-slate-500">Please enter your name to continue.</p>
      </div>
    );
  }

  const fetchMyJobs = async () => {
    if (user) {
      const jobs = await api.getJobs({ type: 'client', userId: user.id });
      setMyJobs(jobs);
    }
  };

  useEffect(() => {
    if (activeTab === 'my-jobs') {
      fetchMyJobs();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab]);

  const handleOptimize = async () => {
    if (!description) return;
    setIsOptimizing(true);
    const optimized = await optimizeJobDescription(description, category);
    setDescription(optimized);
    setIsOptimizing(false);
  };

  const handleLocationDetect = () => {
    if (!navigator.geolocation) {
        alert("Geolocation is not supported by your browser");
        return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
        async (position) => {
            const { latitude, longitude } = position.coords;
            setCoords({ lat: latitude, lng: longitude });
            
            // Reverse Geocoding via OpenStreetMap Nominatim
            try {
                const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`);
                const data = await response.json();
                
                // Try to construct a readable address: Village/Area + City + District
                let humanReadableAddress = '';
                
                if (data.address) {
                    const parts = [
                        data.address.village || data.address.suburb || data.address.residential || data.address.neighbourhood,
                        data.address.city || data.address.town || data.address.county,
                        data.address.state_district || data.address.state
                    ].filter(Boolean); // Remove undefined/null
                    
                    if (parts.length > 0) {
                        humanReadableAddress = parts.join(', ');
                    } else {
                        humanReadableAddress = data.display_name;
                    }
                } else {
                    humanReadableAddress = `GPS: ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
                }
                
                setLocation(humanReadableAddress);
            } catch (error) {
                console.error("Geocoding failed", error);
                // Fallback to coordinates if API fails
                setLocation(`${latitude.toFixed(5)}, ${longitude.toFixed(5)}`);
            } finally {
                setIsLocating(false);
            }
        },
        (error) => {
            console.error(error);
            alert("Unable to retrieve your location. Please ensure location permissions are granted.");
            setIsLocating(false);
        }
    );
  };

  const handlePostJob = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setIsPosting(true);
    await api.postJob({
      clientId: user.id,
      clientName: user.name,
      clientPhone: user.phone,
      title: `${category} needed in ${location}`,
      description,
      category,
      location,
      coords,
    });
    setIsPosting(false);
    setDescription('');
    // Optional: Reset location to default or keep it
    setActiveTab('my-jobs');
  };

  const handleViewWorkers = async (job: Job) => {
    setSelectedJob(job);
    const workers = await api.getWorkersByIds(job.interestedWorkerIds);
    setInterestedWorkers(workers);
  };

  const handleBookWorker = async (workerId: string) => {
    if (!selectedJob) return;
    await api.bookWorker(selectedJob.id, workerId);
    setSelectedJob(null);
    fetchMyJobs();
  };

  return (
    <div className="pb-20">
      {/* Tabs */}
      <div className="flex border-b border-slate-200 mb-6">
        <button
          onClick={() => setActiveTab('post')}
          className={`flex-1 py-3 text-sm font-medium ${
            activeTab === 'post' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500'
          }`}
        >
          Post a Job
        </button>
        <button
          onClick={() => setActiveTab('my-jobs')}
          className={`flex-1 py-3 text-sm font-medium ${
            activeTab === 'my-jobs' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500'
          }`}
        >
          My Jobs
        </button>
      </div>

      {activeTab === 'post' ? (
        <form onSubmit={handlePostJob} className="space-y-6 animate-fade-in">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Service Category</label>
            <div className="grid grid-cols-2 gap-2">
              {CATEGORIES_LIST.slice(0, 6).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`p-3 rounded-lg text-sm border ${
                    category === cat
                      ? 'bg-indigo-50 border-indigo-500 text-indigo-700 font-medium'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Location</label>
            <div className="relative">
              <MapPin className="absolute left-3 top-3.5 h-5 w-5 text-slate-400" />
              <input
                type="text"
                list="cities"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="City, Area, or Village"
                className="w-full pl-10 pr-12 py-3 border border-slate-300 rounded-lg focus:ring-indigo-500"
              />
               <datalist id="cities">
                {MOCK_CITIES.map(c => <option key={c} value={c} />)}
              </datalist>
              <button 
                type="button"
                onClick={handleLocationDetect}
                disabled={isLocating}
                className="absolute right-2 top-2 p-1.5 text-indigo-600 hover:bg-indigo-50 rounded transition-colors disabled:opacity-50"
                title="Detect Live Location Name"
              >
                {isLocating ? <Loader2 size={20} className="animate-spin" /> : <Navigation size={20} />}
              </button>
            </div>
            <p className="text-xs text-slate-400 mt-1 ml-1">Click compass for live address (e.g. Komerapudi)</p>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="block text-sm font-medium text-slate-700">Description</label>
              <button
                type="button"
                onClick={handleOptimize}
                disabled={!description || isOptimizing}
                className="text-xs flex items-center text-indigo-600 hover:text-indigo-800 disabled:opacity-50"
              >
                <Wand2 className="w-3 h-3 mr-1" />
                {isOptimizing ? 'Optimizing...' : 'AI Polish'}
              </button>
            </div>
            <textarea
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-3 border border-slate-300 rounded-lg focus:ring-indigo-500"
              placeholder="Describe the issue (e.g., dripping tap in kitchen)..."
            />
          </div>

          <button
            type="submit"
            disabled={isPosting}
            className="w-full py-3 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 disabled:opacity-50 shadow-lg shadow-indigo-200 transition-transform active:scale-95"
          >
            {isPosting ? 'Posting...' : 'Post Job'}
          </button>
        </form>
      ) : (
        <div className="space-y-4 animate-fade-in">
          {myJobs.length === 0 ? (
            <div className="text-center py-10 text-slate-400">
              <p>No jobs posted yet.</p>
            </div>
          ) : (
            myJobs.map((job) => (
              <div key={job.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-slate-800">{job.category}</h3>
                  <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                    job.status === 'OPEN' ? 'bg-green-100 text-green-700' :
                    job.status === 'BOOKED' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'
                  }`}>
                    {job.status}
                  </span>
                </div>
                <p className="text-sm text-slate-600 mb-3">{job.description}</p>
                <div className="flex items-center text-xs text-slate-400 mb-4">
                  <MapPin className="w-3 h-3 mr-1" /> {job.location}
                  <span className="mx-2">•</span>
                  <Clock className="w-3 h-3 mr-1" /> {new Date(job.postedAt).toLocaleDateString()}
                </div>

                {job.status === 'OPEN' && (
                  <button
                    onClick={() => handleViewWorkers(job)}
                    className="w-full py-2 border border-indigo-200 text-indigo-600 rounded-lg text-sm font-medium hover:bg-indigo-50"
                  >
                    View Interested Workers ({job.interestedWorkerIds.length})
                  </button>
                )}

                {job.status === 'BOOKED' && (
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <p className="text-xs text-slate-500 font-medium uppercase mb-2">Assigned Worker</p>
                    <div className="flex items-center justify-between">
                       <span className="text-sm font-bold text-slate-800">Worker ID: {job.assignedWorkerId}</span>
                       <div className="flex gap-2">
                         <button className="p-2 bg-green-500 text-white rounded-full"><Phone size={16} /></button>
                         <button className="p-2 bg-blue-500 text-white rounded-full"><MessageCircle size={16} /></button>
                       </div>
                    </div>
                     <p className="text-xs text-slate-400 mt-2">Contact details shared securely.</p>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {/* Modal for Selecting Workers */}
      {selectedJob && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-t-2xl sm:rounded-2xl p-6">
            <h3 className="text-lg font-bold mb-4">Select a Worker</h3>
            <div className="max-h-60 overflow-y-auto space-y-3 mb-4">
              {interestedWorkers.length === 0 ? (
                <p className="text-slate-500 text-center py-4">No interest expressed yet.</p>
              ) : (
                interestedWorkers.map(w => (
                  <div key={w.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-semibold text-sm">{w.name}</p>
                      <div className="flex items-center text-xs text-yellow-500 mt-1">
                         ★★★★☆ <span className="text-slate-400 ml-1">(4.5)</span>
                      </div>
                    </div>
                    <button
                      onClick={() => handleBookWorker(w.id)}
                      className="px-3 py-1.5 bg-indigo-600 text-white text-xs rounded-lg hover:bg-indigo-700"
                    >
                      Book
                    </button>
                  </div>
                ))
              )}
            </div>
            <button
              onClick={() => setSelectedJob(null)}
              className="w-full py-3 text-slate-500 font-medium hover:text-slate-700"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};