import React, { useEffect, useState } from 'react';
import { api } from '../services/store';
import { User } from '../types';
import { Shield, User as UserIcon, MapPin } from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const [workers, setWorkers] = useState<User[]>([]);

  useEffect(() => {
    const load = async () => {
      const allWorkers = await api.getAllWorkers();
      setWorkers(allWorkers);
    };
    load();
  }, []);

  return (
    <div>
      <div className="flex items-center gap-2 mb-6">
        <Shield className="text-indigo-600" size={24} />
        <h2 className="text-xl font-bold text-slate-800">Admin Dashboard</h2>
      </div>
      
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wide">Registered Workers ({workers.length})</h3>
        
        {workers.length === 0 ? (
            <div className="p-8 bg-white rounded-lg border border-dashed border-slate-300 text-center text-slate-400">
                No workers registered yet.
            </div>
        ) : (
            workers.map(worker => (
            <div key={worker.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col gap-3">
                <div className="flex justify-between items-start">
                    <div className="flex items-center gap-3">
                        <div className="bg-slate-100 p-2 rounded-full">
                            <UserIcon size={20} className="text-slate-500"/>
                        </div>
                        <div>
                            <h4 className="font-bold text-slate-800">{worker.name}</h4>
                            <p className="text-sm text-slate-500">{worker.phone}</p>
                        </div>
                    </div>
                    <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full font-medium">Active</span>
                </div>
                
                <div className="flex items-center text-xs text-slate-400">
                    <MapPin size={12} className="mr-1" /> {worker.location}
                </div>

                <div className="flex gap-1 flex-wrap">
                        {worker.workerProfile?.categories.map(c => (
                            <span key={c} className="bg-slate-50 text-slate-600 border border-slate-100 text-[10px] px-2 py-1 rounded-full">{c}</span>
                        ))}
                </div>
                
                {worker.workerProfile?.bio && (
                    <div className="bg-slate-50 p-2 rounded text-xs text-slate-600 italic border-l-2 border-indigo-200">
                        "{worker.workerProfile.bio}"
                    </div>
                )}
            </div>
            ))
        )}
      </div>
    </div>
  );
};