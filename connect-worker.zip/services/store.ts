import { Job, User, WorkerCategory, Notification, PersonalEvent } from "../types";
import { delay } from "../constants";

// Key for localStorage
const STORAGE_KEY = 'connectwork_db_v3';

interface DB {
  users: User[];
  jobs: Job[];
  notifications: Notification[];
  currentUser: User | null;
}

// Initial Mock Data
const initialDB: DB = {
  users: [
    {
      id: 'admin-1',
      name: 'System Admin',
      email: 'admin@connectwork.com',
      password: 'admin',
      phone: '9999999999',
      location: 'HQ',
      language: 'en',
      role: 'admin',
      isVerified: true,
      isAdmin: true,
      roleSelected: true
    },
    {
      id: 'worker-1',
      name: 'Raju Mechanic',
      email: 'raju@example.com',
      password: 'password',
      phone: '9876543210',
      location: 'Downtown',
      language: 'te',
      role: 'worker',
      isVerified: true,
      roleSelected: true,
      workerProfile: {
        categories: [WorkerCategory.MECHANIC, WorkerCategory.DRIVER],
        experienceYears: 5,
        bio: 'Expert car mechanic with 5 years experience.',
        availability: true,
        personalSchedule: []
      }
    },
    {
      id: 'client-1',
      name: 'Priya Sharma',
      email: 'priya@example.com',
      password: 'password',
      phone: '9876543211',
      location: 'Westside',
      language: 'hi',
      role: 'client',
      isVerified: true,
      roleSelected: true
    }
  ],
  jobs: [],
  notifications: [],
  currentUser: null
};

// Load from storage or use initial
const loadDB = (): DB => {
  const stored = localStorage.getItem(STORAGE_KEY);
  return stored ? JSON.parse(stored) : initialDB;
};

const saveDB = (db: DB) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
};

// --- API Methods ---

export const api = {
  // Auth
  login: async (email: string, password: string): Promise<User> => {
    await delay(800);
    const db = loadDB();
    
    const normalizedEmail = email.trim().toLowerCase();
    
    const user = db.users.find(u => 
        u.email && 
        u.email.toLowerCase() === normalizedEmail && 
        u.password === password
    );
    
    if (!user) {
      throw new Error('Invalid email or password');
    }
    
    db.currentUser = user;
    saveDB(db);
    return user;
  },

  register: async (userData: { name: string; email: string; password: string; phone: string; location: string }): Promise<User> => {
    await delay(1000);
    const db = loadDB();
    
    const normalizedEmail = userData.email.trim().toLowerCase();

    if (db.users.find(u => u.email && u.email.toLowerCase() === normalizedEmail)) {
        throw new Error('Email already registered');
    }

    const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        name: userData.name,
        email: userData.email,
        password: userData.password,
        phone: userData.phone,
        location: userData.location,
        language: 'en',
        role: 'client', // Default role
        roleSelected: false,
        isVerified: true 
    };

    db.users.push(newUser);
    db.currentUser = newUser;
    saveDB(db);
    return newUser;
  },

  logout: async () => {
    const db = loadDB();
    db.currentUser = null;
    saveDB(db);
  },

  updateUser: async (updates: Partial<User>) => {
    const db = loadDB();
    if (!db.currentUser) throw new Error("Not logged in");

    const index = db.users.findIndex(u => u.id === db.currentUser?.id);
    if (index === -1) throw new Error("User not found");

    const updatedUser = { ...db.users[index], ...updates };
    db.users[index] = updatedUser;
    db.currentUser = updatedUser;
    saveDB(db);
    return updatedUser;
  },

  // Personal Schedule
  addPersonalEvent: async (event: Omit<PersonalEvent, 'id'>) => {
    const db = loadDB();
    if (!db.currentUser || db.currentUser.role !== 'worker' || !db.currentUser.workerProfile) {
        throw new Error("Only workers can add schedule events");
    }

    const index = db.users.findIndex(u => u.id === db.currentUser?.id);
    if (index === -1) throw new Error("User not found");

    const newEvent: PersonalEvent = {
        ...event,
        id: Math.random().toString(36).substr(2, 9)
    };

    const user = db.users[index];
    if (!user.workerProfile!.personalSchedule) {
        user.workerProfile!.personalSchedule = [];
    }
    user.workerProfile!.personalSchedule.push(newEvent);
    
    db.users[index] = user;
    db.currentUser = user;
    saveDB(db);
    return user;
  },

  deletePersonalEvent: async (eventId: string) => {
     const db = loadDB();
     if (!db.currentUser || db.currentUser.role !== 'worker' || !db.currentUser.workerProfile) {
        throw new Error("Unauthorized");
     }

     const index = db.users.findIndex(u => u.id === db.currentUser?.id);
     const user = db.users[index];

     if (user.workerProfile?.personalSchedule) {
         user.workerProfile.personalSchedule = user.workerProfile.personalSchedule.filter(e => e.id !== eventId);
     }
     
     db.users[index] = user;
     db.currentUser = user;
     saveDB(db);
     return user;
  },

  // Jobs
  postJob: async (jobData: Omit<Job, 'id' | 'postedAt' | 'status' | 'interestedWorkerIds'>) => {
    await delay(600);
    const db = loadDB();
    const newJob: Job = {
      ...jobData,
      id: Math.random().toString(36).substr(2, 9),
      postedAt: Date.now(),
      status: 'OPEN',
      interestedWorkerIds: []
    };
    db.jobs.unshift(newJob);
    saveDB(db);
    return newJob;
  },

  getJobs: async (filter?: { type: 'client' | 'worker', userId: string, category?: string }) => {
    await delay(400);
    const db = loadDB();
    let jobs = db.jobs;

    if (filter?.type === 'client') {
      return jobs.filter(j => j.clientId === filter.userId);
    } 
    
    if (filter?.type === 'worker') {
      const worker = db.users.find(u => u.id === filter.userId);
      if (!worker) return [];

      return jobs.filter(j => {
         const isRelevant = j.status === 'OPEN'; 
         const isAssigned = j.assignedWorkerId === filter.userId;
         return isRelevant || isAssigned;
      });
    }

    return jobs;
  },

  expressInterest: async (jobId: string, workerId: string) => {
    await delay(500);
    const db = loadDB();
    const job = db.jobs.find(j => j.id === jobId);
    if (!job) throw new Error("Job not found");
    
    if (!job.interestedWorkerIds.includes(workerId)) {
      job.interestedWorkerIds.push(workerId);
      saveDB(db);
    }
    return job;
  },

  bookWorker: async (jobId: string, workerId: string) => {
    await delay(500);
    const db = loadDB();
    const job = db.jobs.find(j => j.id === jobId);
    if (!job) throw new Error("Job not found");

    job.assignedWorkerId = workerId;
    job.status = 'BOOKED';
    saveDB(db);
    return job;
  },

  updateJobStatus: async (jobId: string, status: Job['status']) => {
    await delay(300);
    const db = loadDB();
    const job = db.jobs.find(j => j.id === jobId);
    if (!job) throw new Error("Job not found");
    job.status = status;
    saveDB(db);
    return job;
  },

  // Admin
  getAllWorkers: async () => {
    const db = loadDB();
    return db.users.filter(u => u.role === 'worker');
  },

  getWorkersByIds: async (ids: string[]) => {
      const db = loadDB();
      return db.users.filter(u => ids.includes(u.id));
  }
};