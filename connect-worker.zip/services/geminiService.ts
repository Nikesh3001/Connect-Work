import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';

// We use a singleton pattern or simple function export. 
// Since API Key is required, we check it before making calls.

export const optimizeJobDescription = async (rawInput: string, category: string): Promise<string> => {
  if (!apiKey) {
    console.warn("Gemini API Key missing");
    return rawInput; // Fallback
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const model = ai.models;

    const prompt = `
      You are an assistant for a local service marketplace. 
      A user wants to hire a ${category}. 
      They typed: "${rawInput}".
      
      Rewrite this into a professional, clear, and concise job description (max 2 sentences) that a worker would understand.
      Do not add markdown. Just plain text.
    `;

    const response = await model.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text?.trim() || rawInput;
  } catch (error) {
    console.error("Gemini optimization failed:", error);
    return rawInput;
  }
};