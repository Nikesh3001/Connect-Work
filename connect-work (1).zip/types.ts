export type Role = 'client' | 'worker' | 'admin';

export type JobStatus = 'OPEN' | 'BOOKED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';

export type PaymentStatus = 'PENDING' | 'ESCROW_LOCKED' | 'RELEASED' | 'REFUNDED';

export type KYCStatus = 'PENDING' | 'VERIFIED' | 'REJECTED' | 'NOT_SUBMITTED';

export enum WorkerCategory {
  AGRICULTURE = 'Agriculture',
  PLUMBER = 'Plumber',
  ELECTRICIAN = 'Electrician',
  MECHANIC = 'Mechanic',
  CARPENTER = 'Carpenter',
  PAINTER = 'Painter',
  MASON = 'Mason',
  CLEANER = 'Cleaner',
  DRIVER = 'Driver',
  LABORER = 'Daily Wage Laborer',
  OTHER = 'Other'
}

export interface PersonalEvent {
  id: string;
  title: string;
  date: number; // Timestamp for the date
  time: string; // e.g., "14:00"
  description: string;
}

export interface Rating {
  id: string;
  jobId: string;
  workerId: string;
  clientId: string;
  stars: number;
  comment?: string;
  timestamp: number;
}

export interface ChatMessage {
  id: string;
  jobId: string;
  senderId: string;
  text: string;
  timestamp: number;
  read: boolean;
}

export interface PaymentDetails {
  upiId?: string;
  bankAccount?: string;
  ifsc?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  phone: string;
  location: string;
  coords?: { lat: number; lng: number };
  language?: string;
  role: Role;
  roleSelected?: boolean;
  isVerified: boolean;
  kycStatus?: KYCStatus;
  workerProfile?: WorkerProfile;
  isAdmin?: boolean;
  profilePicture?: string;
  notificationsEnabled?: boolean;
  
  // Fintech Fields
  walletBalance?: number;
  paymentDetails?: PaymentDetails;
}

export interface WorkerProfile {
  categories: WorkerCategory[];
  experienceYears: number;
  bio: string;
  availability: boolean;
  personalSchedule?: PersonalEvent[];
  notificationsEnabled?: boolean; // Deprecated in favor of User.notificationsEnabled, but kept for compatibility
  rating?: number;
  ratingCount?: number;
}

export interface JobStatusEntry {
  status: JobStatus;
  timestamp: number;
  note?: string;
}

export interface Job {
  id: string;
  clientId: string;
  clientName: string;
  clientPhone: string;
  title: string;
  description: string;
  category: WorkerCategory;
  subCategory?: string;
  location: string;
  coords?: { lat: number; lng: number };
  postedAt: number;
  
  // Financials
  budget: number;
  paymentStatus: PaymentStatus;
  paymentMethod?: 'ONLINE' | 'CASH'; // Track how the user chose to pay
  completionCode?: string; // Secret code for QR generation
  
  status: JobStatus;
  statusHistory: JobStatusEntry[];
  interestedWorkerIds: string[];
  assignedWorkerId?: string;
  assignedWorkerName?: string;
  assignedWorkerPhone?: string;
  assignedWorkerVerified?: boolean;
  isRated?: boolean;
}

export interface Notification {
  id: string;
  userId: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'payment';
  read: boolean;
  timestamp: number;
}