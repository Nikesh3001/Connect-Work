import { WorkerCategory } from "./types";

export const APP_NAME = "Connect Work";

export const CATEGORIES_LIST = Object.values(WorkerCategory);

export const AGRI_SUB_CATEGORIES = [
  { id: 'land_prep', label: 'Land Work / Preparation', icon: '🚜' },
  { id: 'sowing', label: 'Sowing & Seeding', icon: '🌱' },
  { id: 'machinery', label: 'Farm Machinery Rental', icon: '⚙️' },
  { id: 'drone', label: 'Pesticide Drone Services', icon: '🚁' },
  { id: 'irrigation', label: 'Irrigation & Motor Work', icon: '💧' },
  { id: 'harvest', label: 'Harvesting', icon: '🌾' },
  { id: 'labor', label: 'General Farm Labor', icon: '👨‍🌾' },
  { id: 'transport', label: 'Crop Transport', icon: '🚚' }
];

export const MOCK_CITIES = [
  "Downtown",
  "North Hills",
  "Westside",
  "Industrial Park",
  "Suburbs",
  "Green Valley Village",
  "River Banks Farm Area"
];

export const SUPPORTED_LANGUAGES = [
  { code: 'en', name: 'English' },
  { code: 'hi', name: 'Hindi (हिंदी)' },
  { code: 'te', name: 'Telugu (తెలుగు)' },
  { code: 'ta', name: 'Tamil (தமிழ்)' },
  { code: 'kn', name: 'Kannada (ಕನ್ನಡ)' },
  { code: 'ml', name: 'Malayalam (മലയാളം)' },
  { code: 'mr', name: 'Marathi (मराठी)' },
  { code: 'bn', name: 'Bengali (বাংলা)' }
];

// Helper to simulate delay
export const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));