import { GoogleGenAI } from "@google/genai";
import { SUPPORTED_LANGUAGES } from "../constants";

// Helper to get AI instance with the latest key from environment
const getAI = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API_KEY is not configured in the environment.");
  }
  return new GoogleGenAI({ apiKey });
};

export const optimizeJobDescription = async (rawInput: string, category: string): Promise<string> => {
  try {
    const ai = getAI();
    const prompt = `
      You are an assistant for a local service marketplace. 
      A user wants to hire a ${category}. 
      They typed: "${rawInput}".
      
      Rewrite this into a professional, clear, and concise job description (max 2 sentences) that a worker would understand.
      Do not add markdown. Just plain text.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text?.trim() || rawInput;
  } catch (error) {
    console.error("Gemini optimization failed:", error);
    return rawInput;
  }
};

export const translateText = async (text: string, targetLangCode: string): Promise<string> => {
  try {
    // 1. Prioritize user's selected language
    const langObj = SUPPORTED_LANGUAGES.find(l => l.code === targetLangCode);
    const targetLangName = langObj?.name;

    // 2. Fallback Logic: If language isn't in our supported list, check if code exists.
    // If neither, fail gracefully.
    if (!targetLangName && !targetLangCode) {
        throw new Error("Target language not specified");
    }

    // Use the code as fallback name if the fancy name isn't found
    const effectiveTarget = targetLangName || targetLangCode;

    const ai = getAI();

    const prompt = `
      You are a helpful translator for a local job marketplace in India.
      Translate the following job description into ${effectiveTarget}.
      
      Rules:
      1. Keep it simple, colloquial, and easy for a daily wage worker to understand.
      2. Do NOT add explanations like "Here is the translation".
      3. Return ONLY the translated text.
      
      Original Text: "${text}"
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    const result = response.text?.trim();
    if (!result) throw new Error("Translation service returned empty result");
    
    return result;
  } catch (error) {
    console.error("Gemini translation failed:", error);
    // Return a user-friendly error string that the UI can display
    return `Translation unavailable. Displaying original English text.`;
  }
};

export const generateSpeech = async (text: string): Promise<string | null> => {
  try {
    const ai = getAI();

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    // The API returns raw PCM data in base64
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
  } catch (error) {
    console.error("Gemini TTS failed:", error);
    return null;
  }
};

// Helper to play raw PCM audio from Gemini
export const playRawAudio = async (base64String: string) => {
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    
    // Decode base64
    const binaryString = atob(base64String);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    // Create buffer
    const dataInt16 = new Int16Array(bytes.buffer);
    const numChannels = 1;
    const frameCount = dataInt16.length / numChannels;
    
    const audioBuffer = audioContext.createBuffer(numChannels, frameCount, 24000);
    const channelData = audioBuffer.getChannelData(0);
    
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i] / 32768.0;
    }

    // Play
    const source = audioContext.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioContext.destination);
    source.start();

    return new Promise<void>((resolve) => {
      source.onended = () => {
        resolve();
        audioContext.close();
      };
    });

  } catch (error) {
    console.error("Error playing audio:", error);
  }
};