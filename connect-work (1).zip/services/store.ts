import { Job, User, WorkerCategory, Notification, PersonalEvent, Rating, ChatMessage, PaymentDetails } from "../types";
import { db, auth } from "../firebase";
import { collection, doc, setDoc, getDoc, getDocs, updateDoc, query, where, orderBy, addDoc, deleteDoc, runTransaction, serverTimestamp, onSnapshot } from "firebase/firestore";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, sendPasswordResetEmail, signInWithPopup, GoogleAuthProvider } from "firebase/auth";

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: any;
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export const api = {
  login: async (email: string, password: string): Promise<User> => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const userDoc = await getDoc(doc(db, "users", userCredential.user.uid));
      if (!userDoc.exists()) throw new Error("User profile not found");
      return userDoc.data() as User;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, "users");
      throw error;
    }
  },

  socialLogin: async (provider: string, email: string, name: string): Promise<User> => {
    try {
      const googleProvider = new GoogleAuthProvider();
      const userCredential = await signInWithPopup(auth, googleProvider);
      const userRef = doc(db, "users", userCredential.user.uid);
      const userDoc = await getDoc(userRef);
      
      if (!userDoc.exists()) {
        const newUser: User = {
          id: userCredential.user.uid,
          name: userCredential.user.displayName || name || 'New User',
          email: userCredential.user.email || email,
          phone: '',
          location: '',
          language: 'en',
          role: 'client',
          roleSelected: false,
          isVerified: true,
          walletBalance: 0
        };
        await setDoc(userRef, newUser);
        
        // Create public profile
        const publicProfileRef = doc(db, "public_profiles", newUser.id);
        await setDoc(publicProfileRef, {
          id: newUser.id,
          name: newUser.name,
          role: newUser.role,
          isVerified: newUser.isVerified
        });
        
        return newUser;
      }
      return userDoc.data() as User;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "users");
      throw error;
    }
  },

  register: async (userData: Partial<User>): Promise<User> => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, userData.email!, userData.password!);
      const newUser: User = {
        id: userCredential.user.uid,
        name: userData.name!,
        email: userData.email!,
        phone: userData.phone || '',
        location: userData.location || '',
        language: 'en',
        role: 'client',
        roleSelected: false,
        isVerified: false,
        kycStatus: 'NOT_SUBMITTED',
        walletBalance: 0
      };
      
      await setDoc(doc(db, "users", newUser.id), newUser);
      
      // Create public profile
      await setDoc(doc(db, "public_profiles", newUser.id), {
        id: newUser.id,
        name: newUser.name,
        role: newUser.role,
        isVerified: newUser.isVerified
      });
      
      return newUser;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "users");
      throw error;
    }
  },

  resetPasswordRequest: async (email: string): Promise<boolean> => {
    try {
      await sendPasswordResetEmail(auth, email);
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "auth");
      throw error;
    }
  },

  logout: async () => {
    await signOut(auth);
  },

  updateUser: async (updates: Partial<User>) => {
    if (!auth.currentUser) throw new Error("Not logged in");
    try {
      const userRef = doc(db, "users", auth.currentUser.uid);
      await updateDoc(userRef, updates);
      
      if (updates.name || updates.role || updates.isVerified || updates.workerProfile) {
        const publicProfileRef = doc(db, "public_profiles", auth.currentUser.uid);
        const publicUpdates: any = {};
        if (updates.name) publicUpdates.name = updates.name;
        if (updates.role) publicUpdates.role = updates.role;
        if (updates.isVerified !== undefined) publicUpdates.isVerified = updates.isVerified;
        if (updates.workerProfile) publicUpdates.workerProfile = updates.workerProfile;
        
        await updateDoc(publicProfileRef, publicUpdates).catch(e => console.error("Failed to update public profile", e));
      }
      
      const updatedDoc = await getDoc(userRef);
      return updatedDoc.data() as User;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "users");
      throw error;
    }
  },

  updatePaymentDetails: async (details: Partial<PaymentDetails>) => {
    if (!auth.currentUser) throw new Error("Not logged in");
    try {
      const userRef = doc(db, "users", auth.currentUser.uid);
      const userDoc = await getDoc(userRef);
      const user = userDoc.data() as User;
      
      const newPaymentDetails = { ...user.paymentDetails, ...details };
      const updates: Partial<User> = { paymentDetails: newPaymentDetails };
      
      const hasDetails = newPaymentDetails.upiId || newPaymentDetails.bankAccount;
      if (hasDetails && user.kycStatus === 'NOT_SUBMITTED') {
        updates.kycStatus = 'VERIFIED';
      }
      
      await updateDoc(userRef, updates);
      const updatedDoc = await getDoc(userRef);
      return updatedDoc.data() as User;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "users");
      throw error;
    }
  },

  withdrawFunds: async (amount: number) => {
    if (!auth.currentUser) throw new Error("Not logged in");
    try {
      return await runTransaction(db, async (transaction) => {
        const userRef = doc(db, "users", auth.currentUser!.uid);
        const userDoc = await transaction.get(userRef);
        const user = userDoc.data() as User;

        if ((user.walletBalance || 0) < amount) {
          throw new Error("Insufficient funds");
        }
        if (!user.paymentDetails?.upiId && !user.paymentDetails?.bankAccount) {
          throw new Error("No UPI ID or Bank Account linked");
        }

        const newBalance = (user.walletBalance || 0) - amount;
        transaction.update(userRef, { walletBalance: newBalance });

        const dest = user.paymentDetails?.upiId || `Bank Acc ending in ${user.paymentDetails?.bankAccount?.slice(-4)}`;
        const notifRef = doc(collection(db, "notifications"));
        const notif: Notification = {
          id: notifRef.id,
          userId: user.id,
          message: `₹${amount} withdrawn to ${dest} successfully.`,
          type: 'success',
          read: false,
          timestamp: Date.now()
        };
        transaction.set(notifRef, notif);

        return { ...user, walletBalance: newBalance };
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "users/notifications");
      throw error;
    }
  },

  addFunds: async (amount: number) => {
    if (!auth.currentUser) throw new Error("Not logged in");
    try {
      return await runTransaction(db, async (transaction) => {
        const userRef = doc(db, "users", auth.currentUser!.uid);
        const userDoc = await transaction.get(userRef);
        const user = userDoc.data() as User;

        const newBalance = (user.walletBalance || 0) + amount;
        transaction.update(userRef, { walletBalance: newBalance });

        const notifRef = doc(collection(db, "notifications"));
        const notif: Notification = {
          id: notifRef.id,
          userId: user.id,
          message: `₹${amount} added to your wallet successfully.`,
          type: 'success',
          read: false,
          timestamp: Date.now()
        };
        transaction.set(notifRef, notif);

        return { ...user, walletBalance: newBalance };
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "users/notifications");
      throw error;
    }
  },

  addPersonalEvent: async (event: Omit<PersonalEvent, 'id'>) => {
    if (!auth.currentUser) throw new Error("Not logged in");
    try {
      const userRef = doc(db, "users", auth.currentUser.uid);
      const userDoc = await getDoc(userRef);
      const user = userDoc.data() as User;
      
      if (user.role !== 'worker' || !user.workerProfile) {
        throw new Error("Only workers can add schedule events");
      }

      const newEvent: PersonalEvent = {
        ...event,
        id: Math.random().toString(36).substr(2, 9)
      };

      const schedule = user.workerProfile.personalSchedule || [];
      schedule.push(newEvent);
      
      await updateDoc(userRef, { "workerProfile.personalSchedule": schedule });
      const updatedDoc = await getDoc(userRef);
      return updatedDoc.data() as User;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "users");
      throw error;
    }
  },

  deletePersonalEvent: async (eventId: string) => {
    if (!auth.currentUser) throw new Error("Not logged in");
    try {
      const userRef = doc(db, "users", auth.currentUser.uid);
      const userDoc = await getDoc(userRef);
      const user = userDoc.data() as User;
      
      if (user.workerProfile?.personalSchedule) {
        const schedule = user.workerProfile.personalSchedule.filter(e => e.id !== eventId);
        await updateDoc(userRef, { "workerProfile.personalSchedule": schedule });
      }
      
      const updatedDoc = await getDoc(userRef);
      return updatedDoc.data() as User;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "users");
      throw error;
    }
  },

  postJob: async (jobData: Omit<Job, 'id' | 'postedAt' | 'status' | 'interestedWorkerIds' | 'statusHistory' | 'paymentStatus'>) => {
    try {
      const jobRef = doc(collection(db, "jobs"));
      const newJob: Job = {
        ...jobData,
        id: jobRef.id,
        postedAt: Date.now(),
        status: 'OPEN',
        paymentStatus: 'PENDING',
        statusHistory: [{ status: 'OPEN', timestamp: Date.now(), note: 'Job Posted' }],
        interestedWorkerIds: [],
        isRated: false
      };
      await setDoc(jobRef, newJob);
      return newJob;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, "jobs");
      throw error;
    }
  },

  getJobs: async (filter?: { type: 'client' | 'worker', userId: string, category?: string }) => {
    try {
      const jobsRef = collection(db, "jobs");
      let q = query(jobsRef, orderBy("postedAt", "desc"));
      
      if (filter?.type === 'client') {
        q = query(jobsRef, where("clientId", "==", filter.userId), orderBy("postedAt", "desc"));
      } else if (filter?.type === 'worker') {
        // For workers, we fetch all jobs and filter client-side for now due to complex logic
        // In a real app, we'd use more specific queries
      }
      
      const snapshot = await getDocs(q);
      let jobs = snapshot.docs.map(doc => doc.data() as Job);
      
      if (filter?.type === 'worker') {
        const workerDoc = await getDoc(doc(db, "users", filter.userId));
        const worker = workerDoc.data() as User;
        if (!worker) return [];
        
        jobs = jobs.filter(j => {
          if (j.assignedWorkerId === filter.userId) return true;
          if (j.status !== 'OPEN') return false;
          return worker.workerProfile?.categories.includes(j.category);
        });
      }
      
      return jobs;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, "jobs");
      throw error;
    }
  },

  getJobById: async (jobId: string) => {
    try {
      const jobDoc = await getDoc(doc(db, "jobs", jobId));
      return jobDoc.exists() ? jobDoc.data() as Job : undefined;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, "jobs");
      throw error;
    }
  },

  expressInterest: async (jobId: string, workerId: string) => {
    try {
      return await runTransaction(db, async (transaction) => {
        const jobRef = doc(db, "jobs", jobId);
        const jobDoc = await transaction.get(jobRef);
        if (!jobDoc.exists()) throw new Error("Job not found");
        
        const job = jobDoc.data() as Job;
        if (!job.interestedWorkerIds.includes(workerId)) {
          job.interestedWorkerIds.push(workerId);
          transaction.update(jobRef, { interestedWorkerIds: job.interestedWorkerIds });
        }
        return job;
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "jobs");
      throw error;
    }
  },

  bookWorker: async (jobId: string, workerId: string, method: 'ONLINE' | 'CASH' = 'CASH') => {
    try {
      return await runTransaction(db, async (transaction) => {
        const jobRef = doc(db, "jobs", jobId);
        const jobDoc = await transaction.get(jobRef);
        if (!jobDoc.exists()) throw new Error("Job not found");
        const job = jobDoc.data() as Job;

        const workerRef = doc(db, "users", workerId);
        const workerDoc = await transaction.get(workerRef);
        if (!workerDoc.exists()) throw new Error("Worker not found");
        const worker = workerDoc.data() as User;

        if (method === 'ONLINE') {
          const clientRef = doc(db, "users", job.clientId);
          const clientDoc = await transaction.get(clientRef);
          const client = clientDoc.data() as User;

          if ((client.walletBalance || 0) < job.budget) {
            throw new Error(`Insufficient wallet balance (₹${client.walletBalance}). Please add money or use Cash mode.`);
          }

          transaction.update(clientRef, { walletBalance: (client.walletBalance || 0) - job.budget });
          job.paymentStatus = 'ESCROW_LOCKED';
        } else {
          job.paymentStatus = 'PENDING';
        }

        job.assignedWorkerId = workerId;
        job.assignedWorkerName = worker.name;
        job.assignedWorkerPhone = worker.phone;
        job.assignedWorkerVerified = worker.isVerified;
        job.status = 'BOOKED';
        job.paymentMethod = method;
        job.completionCode = Math.random().toString(36).substr(2, 6).toUpperCase();

        job.statusHistory.push({
          status: 'BOOKED',
          timestamp: Date.now(),
          note: `Worker assigned via ${method}. ${method === 'ONLINE' ? 'Funds locked in Escrow.' : 'Payment pending on completion.'}`
        });

        transaction.update(jobRef, job as any);
        return job;
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "jobs/users");
      throw error;
    }
  },

  completeJob: async (jobId: string) => {
    try {
      return await runTransaction(db, async (transaction) => {
        const jobRef = doc(db, "jobs", jobId);
        const jobDoc = await transaction.get(jobRef);
        if (!jobDoc.exists()) throw new Error("Job not found");
        const job = jobDoc.data() as Job;
        
        if (job.status !== 'BOOKED') throw new Error("Job is not in a booked state");
        
        const isEscrow = job.paymentMethod === 'ONLINE' || job.paymentStatus === 'ESCROW_LOCKED';
        const totalAmount = job.budget;
        const commission = totalAmount * 0.20; 
        const workerPayout = totalAmount - commission;
        
        const workerRef = doc(db, "users", job.assignedWorkerId!);
        const workerDoc = await transaction.get(workerRef);
        const worker = workerDoc.data() as User;

        if (isEscrow) {
          transaction.update(workerRef, { walletBalance: (worker.walletBalance || 0) + workerPayout });
          
          const platformRef = doc(db, "platform", "data");
          const platformDoc = await transaction.get(platformRef);
          const currentRev = platformDoc.exists() ? platformDoc.data().revenue || 0 : 0;
          transaction.set(platformRef, { revenue: currentRev + commission }, { merge: true });
          
          job.paymentStatus = 'RELEASED';
          
          const notifRef = doc(collection(db, "notifications"));
          transaction.set(notifRef, {
            id: notifRef.id,
            userId: worker.id,
            message: `Work Approved! ₹${workerPayout} released to your wallet.`,
            type: 'payment',
            read: false,
            timestamp: Date.now()
          });
        } else {
          job.paymentStatus = 'RELEASED';
          const notifRef = doc(collection(db, "notifications"));
          transaction.set(notifRef, {
            id: notifRef.id,
            userId: worker.id,
            message: `Job Marked Complete. Please collect ₹${totalAmount} cash from client if not already done.`,
            type: 'info',
            read: false,
            timestamp: Date.now()
          });
        }

        job.status = 'COMPLETED';
        job.statusHistory.push({
          status: 'COMPLETED',
          timestamp: Date.now(),
          note: `Job completed. Payment ${isEscrow ? 'released from Escrow' : 'settled via Cash'}.`
        });

        transaction.update(jobRef, job as any);
        return { success: true, payout: isEscrow ? workerPayout : 0, method: job.paymentMethod };
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "jobs/users");
      throw error;
    }
  },

  verifyAndPayout: async (jobId: string, code: string) => {
    try {
      return await runTransaction(db, async (transaction) => {
        const jobRef = doc(db, "jobs", jobId);
        const jobDoc = await transaction.get(jobRef);
        if (!jobDoc.exists()) throw new Error("Job not found");
        const job = jobDoc.data() as Job;
        
        if (job.completionCode !== code) throw new Error("Invalid QR Code / Security Token");
        if (job.status !== 'BOOKED') throw new Error("Job already completed or cancelled");

        const isEscrow = job.paymentMethod === 'ONLINE' || job.paymentStatus === 'ESCROW_LOCKED';
        const totalAmount = job.budget;
        const commission = totalAmount * 0.20; 
        const workerPayout = totalAmount - commission;

        const workerRef = doc(db, "users", job.assignedWorkerId!);
        const workerDoc = await transaction.get(workerRef);
        const worker = workerDoc.data() as User;

        if (isEscrow) {
          transaction.update(workerRef, { walletBalance: (worker.walletBalance || 0) + workerPayout });
          
          const platformRef = doc(db, "platform", "data");
          const platformDoc = await transaction.get(platformRef);
          const currentRev = platformDoc.exists() ? platformDoc.data().revenue || 0 : 0;
          transaction.set(platformRef, { revenue: currentRev + commission }, { merge: true });
        }

        job.paymentStatus = 'RELEASED';
        job.status = 'COMPLETED';
        job.statusHistory.push({
          status: 'COMPLETED',
          timestamp: Date.now(),
          note: `Job verified via QR. Payment ${isEscrow ? 'released' : 'confirmed'}.`
        });

        const notifRef = doc(collection(db, "notifications"));
        transaction.set(notifRef, {
          id: notifRef.id,
          userId: worker.id,
          message: `QR Verified! Job Complete. ${isEscrow ? `₹${workerPayout} added to wallet.` : 'Collect cash from client.'}`,
          type: isEscrow ? 'payment' : 'success',
          read: false,
          timestamp: Date.now()
        });

        transaction.update(jobRef, job as any);
        return { success: true, payout: isEscrow ? workerPayout : 0, commission: isEscrow ? commission : 0 };
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "jobs/users");
      throw error;
    }
  },

  updateJobStatus: async (jobId: string, status: Job['status']) => {
    try {
      const jobRef = doc(db, "jobs", jobId);
      const jobDoc = await getDoc(jobRef);
      if (!jobDoc.exists()) throw new Error("Job not found");
      const job = jobDoc.data() as Job;
      
      job.status = status;
      job.statusHistory.push({
        status: status,
        timestamp: Date.now(),
        note: `Status updated to ${status}`
      });
      
      await updateDoc(jobRef, { status: job.status, statusHistory: job.statusHistory });
      return job;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "jobs");
      throw error;
    }
  },

  rateWorker: async (jobId: string, rating: Omit<Rating, 'id' | 'timestamp' | 'clientId' | 'workerId' | 'jobId'>) => {
    try {
      return await runTransaction(db, async (transaction) => {
        const jobRef = doc(db, "jobs", jobId);
        const jobDoc = await transaction.get(jobRef);
        if (!jobDoc.exists()) throw new Error("Job not found");
        const job = jobDoc.data() as Job;
        
        if (!job.assignedWorkerId) throw new Error("No worker assigned");
        if (job.status !== 'COMPLETED') throw new Error("Job must be completed to rate");

        const workerRef = doc(db, "users", job.assignedWorkerId);
        const workerDoc = await transaction.get(workerRef);
        const worker = workerDoc.data() as User;

        const ratingRef = doc(collection(db, "ratings"));
        const newRating: Rating = {
          id: ratingRef.id,
          jobId: job.id,
          workerId: worker.id,
          clientId: job.clientId,
          stars: rating.stars,
          comment: rating.comment,
          timestamp: Date.now()
        };
        transaction.set(ratingRef, newRating);

        transaction.update(jobRef, { isRated: true });

        const currentAvg = worker.workerProfile?.rating || 0;
        const currentCount = worker.workerProfile?.ratingCount || 0;
        const newCount = currentCount + 1;
        const newAvg = ((currentAvg * currentCount) + rating.stars) / newCount;

        transaction.update(workerRef, {
          "workerProfile.rating": parseFloat(newAvg.toFixed(1)),
          "workerProfile.ratingCount": newCount
        });
        
        const publicProfileRef = doc(db, "public_profiles", worker.id);
        transaction.update(publicProfileRef, {
          "workerProfile.rating": parseFloat(newAvg.toFixed(1)),
          "workerProfile.ratingCount": newCount
        });

        return newRating;
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "ratings/jobs/users");
      throw error;
    }
  },

  getJobMessages: async (jobId: string) => {
    try {
      const q = query(collection(db, "messages"), where("jobId", "==", jobId), orderBy("timestamp", "asc"));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => doc.data() as ChatMessage);
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, "messages");
      throw error;
    }
  },

  sendMessage: async (jobId: string, senderId: string, text: string) => {
    try {
      const msgRef = doc(collection(db, "messages"));
      const newMessage: ChatMessage = {
        id: msgRef.id,
        jobId,
        senderId,
        text,
        timestamp: Date.now(),
        read: false
      };
      await setDoc(msgRef, newMessage);
      return newMessage;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, "messages");
      throw error;
    }
  },

  markMessagesAsRead: async (jobId: string, userId: string) => {
    try {
      const q = query(collection(db, "messages"), where("jobId", "==", jobId), where("read", "==", false));
      const snapshot = await getDocs(q);
      
      const promises = snapshot.docs.map(docSnapshot => {
        const msg = docSnapshot.data() as ChatMessage;
        if (msg.senderId !== userId) {
          return updateDoc(docSnapshot.ref, { read: true });
        }
        return Promise.resolve();
      });
      
      await Promise.all(promises);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "messages");
      throw error;
    }
  },

  getUnreadCounts: async (userId: string) => {
    try {
      // Note: In a real app, we'd query messages where senderId != userId and read == false
      // But we can't easily query "not equal" and "equal" together without composite indexes.
      // For now, we'll fetch all unread messages and filter in memory.
      const q = query(collection(db, "messages"), where("read", "==", false));
      const snapshot = await getDocs(q);
      
      const counts: Record<string, number> = {};
      snapshot.docs.forEach(doc => {
        const msg = doc.data() as ChatMessage;
        if (msg.senderId !== userId) {
          counts[msg.jobId] = (counts[msg.jobId] || 0) + 1;
        }
      });
      return counts;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, "messages");
      throw error;
    }
  },

  getAllWorkers: async () => {
    try {
      const q = query(collection(db, "public_profiles"), where("role", "==", "worker"));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => doc.data() as User);
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, "public_profiles");
      throw error;
    }
  },

  getAllClients: async () => {
    try {
      const q = query(collection(db, "public_profiles"), where("role", "==", "client"));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => doc.data() as User);
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, "public_profiles");
      throw error;
    }
  },

  getWorkersByIds: async (ids: string[]) => {
    if (!ids || ids.length === 0) return [];
    try {
      // Firestore 'in' query supports up to 10 items
      const chunks = [];
      for (let i = 0; i < ids.length; i += 10) {
        chunks.push(ids.slice(i, i + 10));
      }
      
      const results: User[] = [];
      for (const chunk of chunks) {
        const q = query(collection(db, "public_profiles"), where("id", "in", chunk));
        const snapshot = await getDocs(q);
        results.push(...snapshot.docs.map(doc => doc.data() as User));
      }
      return results;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, "public_profiles");
      throw error;
    }
  },

  verifyUser: async (userId: string, isVerified: boolean) => {
    try {
      const userRef = doc(db, "users", userId);
      await updateDoc(userRef, { isVerified });
      
      const publicProfileRef = doc(db, "public_profiles", userId);
      await updateDoc(publicProfileRef, { isVerified }).catch(e => console.error(e));
      
      const updatedDoc = await getDoc(userRef);
      return updatedDoc.data() as User;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, "users");
      throw error;
    }
  }
};
