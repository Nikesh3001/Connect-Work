import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/store';
import { translateText, generateSpeech, playRawAudio } from '../services/geminiService';
import { Job, WorkerCategory, User, PersonalEvent } from '../types';
import { CATEGORIES_LIST, MOCK_CITIES, SUPPORTED_LANGUAGES } from '../constants';
import { MapPin, Phone, CheckCircle, AlertCircle, Calendar, ChevronLeft, ChevronRight, Plus, X, Trash2, Clock, RefreshCw, Map as MapIcon, User as UserIcon, Navigation, Loader2, Search, Droplets, Zap, Wrench, Hammer, Paintbrush, BrickWall, Sparkles, Car, HardHat, Briefcase, Star, ExternalLink, MessageCircle, BadgeCheck, Languages, Tractor, Bell, BellRing, Volume2, BellOff, AlertTriangle, Wallet, CreditCard, QrCode, ArrowUpRight } from 'lucide-react';
import { LocationPicker } from '../components/LocationPicker';
import { ChatInterface } from '../components/ChatInterface';

const getCategoryIcon = (category: WorkerCategory) => {
    const iconProps = { size: 18, className: "shrink-0" };
    switch (category) {
        case WorkerCategory.AGRICULTURE: return <div className="p-2 rounded-lg bg-green-100 text-green-700"><Tractor {...iconProps} /></div>;
        case WorkerCategory.PLUMBER: return <div className="p-2 rounded-lg bg-blue-100 text-blue-600"><Droplets {...iconProps} /></div>;
        case WorkerCategory.ELECTRICIAN: return <div className="p-2 rounded-lg bg-yellow-100 text-yellow-600"><Zap {...iconProps} /></div>;
        case WorkerCategory.MECHANIC: return <div className="p-2 rounded-lg bg-slate-100 text-slate-600"><Wrench {...iconProps} /></div>;
        case WorkerCategory.CARPENTER: return <div className="p-2 rounded-lg bg-orange-100 text-orange-600"><Hammer {...iconProps} /></div>;
        case WorkerCategory.PAINTER: return <div className="p-2 rounded-lg bg-pink-100 text-pink-600"><Paintbrush {...iconProps} /></div>;
        case WorkerCategory.MASON: return <div className="p-2 rounded-lg bg-red-100 text-red-600"><BrickWall {...iconProps} /></div>;
        case WorkerCategory.CLEANER: return <div className="p-2 rounded-lg bg-purple-100 text-purple-600"><Sparkles {...iconProps} /></div>;
        case WorkerCategory.DRIVER: return <div className="p-2 rounded-lg bg-indigo-100 text-indigo-600"><Car {...iconProps} /></div>;
        case WorkerCategory.LABORER: return <div className="p-2 rounded-lg bg-yellow-100 text-yellow-700"><HardHat {...iconProps} /></div>;
        default: return <div className="p-2 rounded-lg bg-slate-100 text-slate-500"><Briefcase {...iconProps} /></div>;
    }
};

export const WorkerDashboard: React.FC = () => {
  const { user, refreshUser, requestNotificationPermission } = useApp();
  const [activeTab, setActiveTab] = useState<'find' | 'wallet' | 'profile'>('find');
  const [availableJobs, setAvailableJobs] = useState<Job[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [unreadCounts, setUnreadCounts] = useState<Record<string, number>>({});
  const [showPermissionBanner, setShowPermissionBanner] = useState(false);
  
  // Translation State
  const [translations, setTranslations] = useState<Record<string, string>>({});
  const [translating, setTranslating] = useState<Record<string, boolean>>({});

  // Audio State
  const [playingAudio, setPlayingAudio] = useState<Record<string, boolean>>({});

  // Job Details Modal State
  const [selectedJobDetails, setSelectedJobDetails] = useState<Job | null>(null);
  
  // Chat State
  const [activeChatJob, setActiveChatJob] = useState<Job | null>(null);

  // QR Modal
  const [showQRJob, setShowQRJob] = useState<Job | null>(null);

  // Profile Form Local States
  const [editName, setEditName] = useState(user?.name || '');
  const [editBio, setEditBio] = useState(user?.workerProfile?.bio || '');
  const [selectedCats, setSelectedCats] = useState<WorkerCategory[]>(user?.workerProfile?.categories || []);
  const [editLocation, setEditLocation] = useState(user?.location || '');
  const [editCoords, setEditCoords] = useState<{lat: number, lng: number} | undefined>(user?.coords);
  
  // Notification state synced with user object
  const notificationsEnabled = user?.notificationsEnabled ?? user?.workerProfile?.notificationsEnabled ?? false;

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
      setToastMessage(msg);
      setTimeout(() => setToastMessage(null), 3000);
  };

  const loadJobs = async () => {
    if (!user) return;
    setIsRefreshing(true);
    const jobs = await api.getJobs({ type: 'worker', userId: user.id });
    setAvailableJobs(jobs);
    const counts = await api.getUnreadCounts(user.id);
    setUnreadCounts(counts);
    setIsRefreshing(false);
  };

  useEffect(() => {
    if (user && (activeTab === 'find')) {
      loadJobs();
    }
    if (Notification.permission === 'default' && notificationsEnabled) {
        setShowPermissionBanner(true);
    }
  }, [user, activeTab]);

  const handleRequestPermission = async () => {
      await requestNotificationPermission();
      if (Notification.permission === 'granted') {
          setShowPermissionBanner(false);
      }
  };

  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
        if (e.key === 'connectwork_db_v3') {
            loadJobs();
            refreshUser(); // For wallet updates
        }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [user]);

  const toggleNotifications = async () => {
      const newState = !notificationsEnabled;
      
      // Prompt for permission if turning ON
      if (newState) {
          if (Notification.permission === 'default') {
              await requestNotificationPermission();
          } else if (Notification.permission === 'denied') {
              showToast("Notifications are blocked. Please enable them in your browser settings to receive real-time job alerts.");
              return; // Don't turn on if denied and they can't see them
          }
      }

      // Save immediately to backend
      try {
          await api.updateUser({ 
              notificationsEnabled: newState,
              workerProfile: user?.workerProfile ? {
                  ...user.workerProfile,
                  notificationsEnabled: newState
              } : undefined
          });
          refreshUser();
      } catch (error) {
          console.error("Failed to update notification settings", error);
      }
  };

  const handleSaveProfile = async () => {
    await api.updateUser({
      name: editName,
      location: editLocation,
      coords: editCoords,
      workerProfile: {
        categories: selectedCats,
        bio: editBio,
        experienceYears: 3, 
        availability: true,
        personalSchedule: user?.workerProfile?.personalSchedule || [],
        notificationsEnabled: notificationsEnabled,
        rating: user?.workerProfile?.rating,
        ratingCount: user?.workerProfile?.ratingCount
      }
    });
    refreshUser();
    showToast('Profile Updated!');
  };

  const handleExpressInterest = async (jobId: string) => {
    if (!user) return;
    await api.expressInterest(jobId, user.id);
    const jobs = await api.getJobs({ type: 'worker', userId: user.id });
    setAvailableJobs(jobs);
  };

  const handleTranslateJob = async (jobId: string, text: string) => {
      // Allow translation even if english, but prioritize user language
      const targetLang = user?.language || 'en';
      
      setTranslating(prev => ({ ...prev, [jobId]: true }));
      try {
          const translated = await translateText(text, targetLang);
          if (translated) {
            setTranslations(prev => ({ ...prev, [jobId]: translated }));
          } else {
            setTranslations(prev => ({ ...prev, [jobId]: "Translation unavailable." }));
          }
      } catch (error) {
          console.error("Translation Error:", error);
          setTranslations(prev => ({ ...prev, [jobId]: "Translation service currently unavailable." }));
      } finally {
          setTranslating(prev => ({ ...prev, [jobId]: false }));
      }
  };

  const handleListenToJob = async (jobId: string, text: string) => {
    if (playingAudio[jobId]) return;
    setPlayingAudio(prev => ({ ...prev, [jobId]: true }));
    try {
        let textToSpeak = text;
        
        // If we have a valid translation that is NOT an error message, speak that.
        // Otherwise speak original text.
        const currentTrans = translations[jobId];
        if (currentTrans && !currentTrans.includes("unavailable") && !currentTrans.includes("failed")) {
            textToSpeak = currentTrans;
        }

        const base64Audio = await generateSpeech(textToSpeak);
        if (base64Audio) await playRawAudio(base64Audio);
    } catch (error) {
        console.error(error);
    } finally {
        setPlayingAudio(prev => ({ ...prev, [jobId]: false }));
    }
  };
  
  const handleWithdraw = async () => {
      if(!user?.walletBalance || user.walletBalance <= 0) return;
      if(!user.paymentDetails?.upiId) {
          showToast("Please add UPI ID in Settings/Wallet first.");
          return;
      }
      try {
          await api.withdrawFunds(user.walletBalance);
          showToast("Withdrawal initiated! Funds will reach your bank shortly.");
          refreshUser();
      } catch(e: any) {
          showToast(e.message);
      }
  }

  const getLanguageName = (code?: string) => {
      return SUPPORTED_LANGUAGES.find(l => l.code === code)?.name || 'Language';
  };

  if (!user?.workerProfile && activeTab === 'find') {
     return (
         <div className="p-6 text-center">
             <AlertCircle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
             <h2 className="text-xl font-bold mb-2">Become a Worker</h2>
             <p className="text-slate-600 mb-6">You need to set up your worker profile before you can see jobs.</p>
             <button 
                onClick={() => setActiveTab('profile')}
                className="bg-indigo-600 text-white px-6 py-2 rounded-lg"
            >
                Create Profile
            </button>
         </div>
     )
  }

  return (
    <div className="pb-20">
      {showMap && (
        <LocationPicker 
            initialLat={editCoords?.lat || user?.coords?.lat}
            initialLng={editCoords?.lng || user?.coords?.lng}
            onConfirm={(lat, lng) => {
                setEditCoords({ lat, lng });
                setShowMap(false);
            }}
            onCancel={() => setShowMap(false)}
        />
      )}
      
      {showPermissionBanner && (
          <div className="bg-indigo-600 text-white px-4 py-3 mx-4 mt-2 rounded-xl flex items-center justify-between shadow-lg animate-fade-in z-50">
              <div className="flex items-center gap-3">
                  <div className="bg-white/20 p-2 rounded-full"><BellRing size={20} /></div>
                  <div>
                      <h4 className="font-bold text-sm">Enable Browser Alerts</h4>
                      <p className="text-xs text-indigo-100">See new jobs even when KaamConnect is closed.</p>
                  </div>
              </div>
              <button 
                onClick={handleRequestPermission}
                className="bg-white text-indigo-600 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-indigo-50"
              >
                  Enable
              </button>
          </div>
      )}

      {/* Completion QR Modal */}
      {showQRJob && (
          <div className="fixed inset-0 bg-black/80 z-[2500] flex items-center justify-center p-4 animate-fade-in backdrop-blur-sm">
              <div className="bg-white w-full max-w-sm rounded-2xl p-6 relative shadow-2xl">
                  <button onClick={() => setShowQRJob(null)} className="absolute right-4 top-4 text-slate-400 hover:text-slate-600"><X size={20}/></button>
                  
                  <div className="text-center mb-6">
                      <h3 className="text-xl font-bold text-slate-800">Job Completion</h3>
                      <p className="text-sm text-slate-500">Show this to {showQRJob.clientName}</p>
                  </div>

                  <div className="bg-slate-100 p-8 rounded-xl flex items-center justify-center mb-6">
                      <img 
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${showQRJob.completionCode}`} 
                        alt="Completion QR" 
                        className="w-48 h-48 mix-blend-multiply"
                      />
                  </div>

                  <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-100 text-center">
                      <p className="text-xs font-bold text-yellow-700 uppercase tracking-widest mb-1">Manual Code</p>
                      <p className="text-3xl font-mono font-bold text-slate-800 tracking-widest">{showQRJob.completionCode}</p>
                  </div>
                  
                  <p className="text-xs text-center text-slate-400 mt-4">
                      Asking client to scan this will release ₹{(showQRJob.budget * 0.8).toFixed(0)} to your wallet.
                  </p>
              </div>
          </div>
      )}

      {/* Full Job Details Modal */}
      {selectedJobDetails && (
        <div className="fixed inset-0 z-[2100] bg-black/60 flex items-center justify-center p-4 animate-fade-in backdrop-blur-sm">
            <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
                <div className="p-4 bg-indigo-600 text-white flex justify-between items-center">
                    <h3 className="font-bold flex items-center gap-2">
                        {getCategoryIcon(selectedJobDetails.category)} 
                        <div>
                            {selectedJobDetails.category}
                        </div>
                    </h3>
                    <button onClick={() => setSelectedJobDetails(null)} className="p-1 hover:bg-white/20 rounded-full">
                        <X size={20} />
                    </button>
                </div>
                
                <div className="overflow-y-auto p-4 space-y-4">
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Client Information</h4>
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm text-slate-500">
                                    <UserIcon size={20} />
                                </div>
                                <div>
                                    <p className="font-bold text-slate-800">{selectedJobDetails.clientName}</p>
                                    <p className="text-xs text-slate-500">Verified Client</p>
                                </div>
                            </div>
                            <a href={`tel:${selectedJobDetails.clientPhone}`} className="bg-green-500 text-white p-2 rounded-full shadow-lg">
                                <Phone size={18} />
                            </a>
                        </div>
                    </div>

                    <div>
                         <div className="flex justify-between items-center mb-1">
                            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Description</h4>
                            <div className="flex gap-2">
                                <button onClick={() => handleListenToJob(selectedJobDetails.id, selectedJobDetails.description)} className="text-xs flex items-center gap-1 text-emerald-600 font-bold">
                                    {playingAudio[selectedJobDetails.id] ? <Loader2 size={12} className="animate-spin" /> : <Volume2 size={12} />}
                                    <span>Listen</span>
                                </button>
                                <button onClick={() => handleTranslateJob(selectedJobDetails.id, selectedJobDetails.description)} className="text-xs flex items-center gap-1 text-indigo-600 font-bold">
                                    {translating[selectedJobDetails.id] ? <Loader2 size={12} className="animate-spin" /> : <Languages size={12} />}
                                    <span>Translate</span>
                                </button>
                            </div>
                         </div>
                         <div className="bg-white border border-slate-100 p-3 rounded-lg text-sm">
                             {selectedJobDetails.description}
                             
                             {/* Translated Text in Modal */}
                             {translations[selectedJobDetails.id] && (
                                <div className={`mt-2 pt-2 border-t ${translations[selectedJobDetails.id].includes('unavailable') ? 'text-orange-600 border-orange-100' : 'text-indigo-700 border-indigo-100'}`}>
                                    {translations[selectedJobDetails.id].includes('unavailable') && <AlertTriangle size={12} className="inline mr-1" />}
                                    <span className="italic">{translations[selectedJobDetails.id]}</span>
                                </div>
                             )}
                         </div>
                    </div>
                </div>
            </div>
        </div>
      )}

      {/* Chat Modal */}
      {activeChatJob && user && (
          <ChatInterface 
             jobId={activeChatJob.id}
             currentUserId={user.id}
             otherUserName={activeChatJob.clientName || 'Client'}
             onClose={() => { setActiveChatJob(null); loadJobs(); }}
          />
      )}

      {/* Tabs */}
      <div className="flex border-b border-slate-200 mb-6 overflow-x-auto">
        <button
          onClick={() => setActiveTab('find')}
          className={`flex-1 py-3 text-sm font-medium whitespace-nowrap px-4 ${
            activeTab === 'find' ? 'text-emerald-600 border-b-2 border-emerald-600' : 'text-slate-500'
          }`}
        >
          Find Work
        </button>
        <button
          onClick={() => setActiveTab('wallet')}
          className={`flex-1 py-3 text-sm font-medium whitespace-nowrap px-4 ${
            activeTab === 'wallet' ? 'text-emerald-600 border-b-2 border-emerald-600' : 'text-slate-500'
          }`}
        >
          Wallet
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`flex-1 py-3 text-sm font-medium whitespace-nowrap px-4 ${
            activeTab === 'profile' ? 'text-emerald-600 border-b-2 border-emerald-600' : 'text-slate-500'
          }`}
        >
          My Profile
        </button>
      </div>

      {activeTab === 'find' ? (
        <div className="space-y-4 animate-fade-in relative px-1">
            
            {/* Real-time Job Alerts Toggle - Primary Location */}
            <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-4 mb-2 flex items-center justify-between shadow-sm">
                <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-xl ${notificationsEnabled ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-500 shadow-inner'}`}>
                        {notificationsEnabled ? <BellRing size={20} className="animate-pulse" /> : <BellOff size={20} />}
                    </div>
                    <div>
                        <h4 className="font-bold text-slate-800 text-sm">Job Alerts</h4>
                        <p className="text-[10px] text-slate-500 font-medium">Get notified when new work is posted nearby</p>
                    </div>
                </div>
                <button 
                    onClick={toggleNotifications}
                    className={`relative w-12 h-6 rounded-full transition-all duration-300 ${notificationsEnabled ? 'bg-indigo-600 shadow-indigo-200' : 'bg-slate-300'}`}
                >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-lg transition-transform duration-300 ${notificationsEnabled ? 'translate-x-7' : 'translate-x-1'}`} />
                </button>
            </div>

            <div className="flex justify-between items-center mb-2 px-1">
                 <h3 className="font-bold text-slate-700">Matching Jobs</h3>
                 <button onClick={loadJobs} className="p-1.5 bg-white border rounded-full text-slate-500">
                    <RefreshCw size={14} className={isRefreshing ? "animate-spin" : ""} />
                 </button>
            </div>

          {availableJobs.length === 0 ? (
            <div className="text-center py-10 text-slate-400 bg-white rounded-xl border border-dashed border-slate-200">
              <AlertCircle className="mx-auto mb-2 opacity-20" size={32} />
              <p>No matching jobs found nearby.</p>
            </div>
          ) : (
            availableJobs.map((job) => {
              const hasApplied = job.interestedWorkerIds.includes(user!.id);
              const isAssignedToMe = job.assignedWorkerId === user!.id;
              if (job.status === 'BOOKED' && !isAssignedToMe) return null; 

              return (
                <div key={job.id} className={`p-4 rounded-xl border shadow-sm ${isAssignedToMe ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-slate-200'}`}>
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-semibold text-slate-800 flex items-center gap-2">
                        {getCategoryIcon(job.category)}
                        <div>{job.category}</div>
                    </h3>
                    <div className="flex flex-col items-end gap-1">
                        <span className="text-xs text-slate-400">{new Date(job.postedAt).toLocaleDateString()}</span>
                        {isAssignedToMe && <span className="text-xs font-bold text-emerald-600">₹{job.budget}</span>}
                    </div>
                  </div>
                  
                  <div className="mb-3">
                      <div className="flex justify-between items-start gap-3">
                          <p className="text-sm text-slate-600 leading-relaxed line-clamp-2">{job.description}</p>
                          <div className="flex flex-col gap-2 shrink-0">
                                <button onClick={() => handleListenToJob(job.id, job.description)} className="p-2 bg-emerald-50 text-emerald-600 rounded-lg border border-emerald-100">
                                    <Volume2 size={16} />
                                </button>
                                <button 
                                    onClick={() => handleTranslateJob(job.id, job.description)} 
                                    className={`p-2 rounded-lg border transition-all ${translating[job.id] ? 'bg-slate-50 text-slate-400 border-slate-200' : 'bg-indigo-50 text-indigo-600 border-indigo-100'}`}
                                    disabled={translating[job.id]}
                                >
                                    {translating[job.id] ? <Loader2 size={16} className="animate-spin" /> : <Languages size={16} />}
                                </button>
                          </div>
                      </div>
                      
                      {translations[job.id] && (
                        <div className={`mt-3 p-3 border rounded-lg text-sm relative animate-fade-in ${
                            translations[job.id].includes('unavailable') 
                                ? 'bg-orange-50 border-orange-100 text-orange-800' 
                                : 'bg-indigo-50 border-indigo-100 text-indigo-800'
                        }`}>
                            <div className={`flex items-center gap-1.5 mb-1.5 pb-1.5 border-b ${
                                translations[job.id].includes('unavailable') ? 'border-orange-200' : 'border-indigo-100/50'
                            }`}>
                                {translations[job.id].includes('unavailable') ? (
                                    <>
                                        <AlertTriangle size={12} className="text-orange-500" />
                                        <span className="text-[10px] uppercase font-bold text-orange-500">Translation Status</span>
                                    </>
                                ) : (
                                    <>
                                        <Sparkles size={12} className="text-indigo-500" />
                                        <span className="text-[10px] uppercase font-bold text-indigo-400">Translated to {getLanguageName(user?.language)}</span>
                                    </>
                                )}
                            </div>
                            <p className="leading-relaxed">{translations[job.id]}</p>
                        </div>
                      )}
                  </div>
                  
                  {!isAssignedToMe && (
                    <div className="flex items-center text-xs text-slate-400 mb-4">
                        <MapPin className="w-3 h-3 mr-1" /> {job.location}
                        <span className="mx-2">•</span>
                        <span className="font-bold text-slate-700">₹{job.budget}</span>
                    </div>
                  )}

                  {isAssignedToMe ? (
                     <div className="mt-3 pt-3 border-t border-emerald-200">
                         <div className="flex justify-between items-center mb-3">
                            <p className="text-emerald-700 font-bold text-sm flex items-center gap-1">
                                <CheckCircle size={14} /> BOOKED FOR YOU
                            </p>
                            <span className="bg-yellow-50 text-yellow-700 text-[10px] font-bold px-2 py-1 rounded border border-yellow-200">
                                ESCROW SECURED
                            </span>
                         </div>
                         <div className="flex gap-2">
                             <button onClick={() => setShowQRJob(job)} className="flex-1 bg-emerald-600 text-white px-3 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2 hover:bg-emerald-700">
                                <QrCode size={16} /> Finish & Get Paid
                             </button>
                             <button onClick={() => setActiveChatJob(job)} className="px-3 py-2 bg-indigo-50 text-indigo-600 rounded-lg border border-indigo-200 hover:bg-indigo-100">
                                <MessageCircle size={18} />
                             </button>
                         </div>
                     </div>
                  ) : (
                    <button
                        onClick={() => handleExpressInterest(job.id)}
                        disabled={hasApplied}
                        className={`w-full py-2.5 rounded-lg text-sm font-bold transition-all ${
                        hasApplied
                            ? 'bg-slate-100 text-slate-400'
                            : 'bg-emerald-600 text-white shadow-lg shadow-emerald-100'
                        }`}
                    >
                        {hasApplied ? 'Interest Sent' : 'I am Interested'}
                    </button>
                  )}
                </div>
              );
            })
          )}
        </div>
      ) : activeTab === 'wallet' ? (
          <div className="space-y-6 animate-fade-in px-1">
              {/* Wallet Card */}
              <div className="bg-gradient-to-br from-indigo-800 to-indigo-600 text-white p-6 rounded-2xl shadow-xl relative overflow-hidden">
                  <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl"></div>
                  <div className="relative z-10">
                      <p className="text-indigo-200 text-sm font-medium mb-1">Total Earnings Balance</p>
                      <h2 className="text-4xl font-bold mb-6">₹{user?.walletBalance?.toFixed(2) || '0.00'}</h2>
                      
                      <div className="flex gap-3">
                          <button 
                            onClick={handleWithdraw}
                            className="flex-1 bg-white text-indigo-700 py-2.5 rounded-xl font-bold text-sm hover:bg-indigo-50 transition-colors flex items-center justify-center gap-2"
                          >
                              <ArrowUpRight size={18} /> Withdraw
                          </button>
                          <div className="bg-indigo-900/50 px-4 py-2 rounded-xl flex items-center text-sm font-mono text-indigo-100 border border-white/10">
                              <span className="mr-2 opacity-50">****</span>
                              {user?.paymentDetails?.upiId ? user.paymentDetails.upiId.split('@')[0].slice(-4) : 'ADD'}
                          </div>
                      </div>
                  </div>
              </div>

              {/* Transactions (Mock) */}
              <div className="bg-white rounded-xl border border-slate-200 p-4">
                  <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                      <CreditCard size={18} /> Recent Transactions
                  </h3>
                  <div className="space-y-4">
                      {/* Using Notifications as mock transactions for now */}
                      <div className="flex items-center justify-between py-2 border-b border-slate-100">
                          <div className="flex items-center gap-3">
                              <div className="bg-emerald-100 p-2 rounded-full text-emerald-600">
                                  <ArrowUpRight size={16} className="rotate-180" />
                              </div>
                              <div>
                                  <p className="text-sm font-bold text-slate-700">Payment Received</p>
                                  <p className="text-xs text-slate-400">Job Completion</p>
                              </div>
                          </div>
                          <span className="text-emerald-600 font-bold text-sm">+ ₹0.00</span>
                      </div>
                  </div>
                  <p className="text-center text-xs text-slate-400 mt-4">No recent activity.</p>
              </div>

              {/* Payment Settings */}
              <div className="bg-white rounded-xl border border-slate-200 p-4">
                  <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                      <Wallet size={18} /> Payment Methods
                  </h3>
                  <div>
                      <label className="block text-xs font-medium text-slate-500 mb-1">Linked UPI ID</label>
                      <div className="flex gap-2">
                          <input 
                            type="text" 
                            placeholder="user@upi"
                            className="flex-1 p-2 border border-slate-300 rounded-lg text-sm"
                            defaultValue={user?.paymentDetails?.upiId}
                            onBlur={(e) => {
                                if(e.target.value && e.target.value !== user?.paymentDetails?.upiId) {
                                    api.updatePaymentDetails({ upiId: e.target.value }).then(refreshUser);
                                }
                            }}
                          />
                          <button className="bg-slate-100 text-slate-600 px-3 py-2 rounded-lg text-xs font-bold border border-slate-200">
                              Update
                          </button>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-2 flex items-center gap-1">
                          <CheckCircle size={10} className="text-green-500" />
                          Encrypted & Secure Storage
                      </p>
                  </div>
              </div>
          </div>
      ) : (
        <div className="space-y-6 animate-fade-in p-1">
          <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 text-white p-5 rounded-2xl shadow-lg relative overflow-hidden">
             <div className="absolute top-0 right-0 p-4 opacity-10"><Star size={120} /></div>
             <div className="relative z-10">
                 <p className="text-indigo-100 text-sm font-medium uppercase tracking-wider mb-2">My Rating</p>
                 <div className="flex items-end gap-3">
                     <h2 className="text-5xl font-bold">{user?.workerProfile?.rating ? user.workerProfile.rating.toFixed(1) : 'New'}</h2>
                     <div className="flex mb-2"><Star size={20} fill="gold" className="text-yellow-400" /></div>
                 </div>
             </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
             <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full ${notificationsEnabled ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-100 text-slate-400'}`}>
                    <Bell size={20} />
                </div>
                <div>
                    <h4 className="font-bold text-slate-800 text-sm">Job Alerts</h4>
                    <p className="text-xs text-slate-500">Enable notifications to see new jobs.</p>
                </div>
             </div>
             <button onClick={toggleNotifications} className={`relative w-11 h-6 rounded-full ${notificationsEnabled ? 'bg-indigo-600' : 'bg-slate-300'}`}>
                <span className={`absolute top-1 bg-white w-4 h-4 rounded-full transition-all ${notificationsEnabled ? 'left-6' : 'left-1'}`} />
             </button>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
            <input type="text" value={editName} onChange={(e) => setEditName(e.target.value)} className="w-full p-3 border border-slate-300 rounded-lg" />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Skills</label>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES_LIST.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCats(prev => prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat])}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${selectedCats.includes(cat) ? 'bg-emerald-600 border-emerald-600 text-white' : 'bg-white border-slate-300 text-slate-600'}`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <button onClick={handleSaveProfile} className="w-full py-3 bg-emerald-600 text-white rounded-lg font-bold shadow-md shadow-emerald-200">
            Save Profile
          </button>
        </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-slate-800 text-white px-6 py-3 rounded-full shadow-2xl z-[100] animate-fade-in-up flex items-center gap-2 text-sm font-medium">
          <CheckCircle size={16} className="text-emerald-400" />
          {toastMessage}
        </div>
      )}
    </div>
  );
};