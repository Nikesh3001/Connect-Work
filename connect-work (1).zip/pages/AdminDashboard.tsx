import React, { useEffect, useState } from 'react';
import { api } from '../services/store';
import { useApp } from '../context/AppContext';
import { User } from '../types';
import { Shield, User as UserIcon, MapPin, Briefcase, Hammer, Mail, Loader2, LogOut, CheckCircle, XCircle } from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { logout } = useApp();
  const [activeTab, setActiveTab] = useState<'workers' | 'clients'>('workers');
  const [workers, setWorkers] = useState<User[]>([]);
  const [clients, setClients] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
      setToastMessage(msg);
      setTimeout(() => setToastMessage(null), 3000);
  };

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      const [allWorkers, allClients] = await Promise.all([
        api.getAllWorkers(),
        api.getAllClients()
      ]);
      setWorkers(allWorkers);
      setClients(allClients);
      setIsLoading(false);
    };
    loadData();
  }, []);

  const handleVerify = async (userId: string, status: boolean) => {
    // Optimistic Update
    const updateList = (list: User[]) => list.map(u => u.id === userId ? { ...u, isVerified: status } : u);
    
    if (activeTab === 'workers') setWorkers(prev => updateList(prev));
    else setClients(prev => updateList(prev));

    try {
        await api.verifyUser(userId, status);
    } catch (error) {
        console.error("Verification failed", error);
        showToast("Failed to update status. Please try again.");
        // Reload data to ensure consistency on error
        const [allWorkers, allClients] = await Promise.all([
             api.getAllWorkers(),
             api.getAllClients()
        ]);
        setWorkers(allWorkers);
        setClients(allClients);
    }
  };

  const renderUserList = (users: User[], type: 'worker' | 'client') => {
      if (users.length === 0) {
          return (
            <div className="p-10 bg-white rounded-xl border border-dashed border-slate-300 text-center text-slate-400">
                <p>No {type}s found in the system.</p>
            </div>
          );
      }

      return users.map(user => (
        <div key={user.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col gap-3 transition-all hover:shadow-md">
            <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-full ${type === 'worker' ? 'bg-emerald-100 text-emerald-600' : 'bg-indigo-100 text-indigo-600'}`}>
                        <UserIcon size={20} />
                    </div>
                    <div>
                        <h4 className="font-bold text-slate-800 text-sm">{user.name || 'Unknown User'}</h4>
                        <p className="text-xs text-slate-500 font-medium">{user.phone}</p>
                        <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-0.5">
                            <Mail size={10} /> {user.email}
                        </div>
                    </div>
                </div>
                <span className={`text-[10px] px-2 py-1 rounded-full font-bold uppercase tracking-wide ${
                    user.isVerified ? 'bg-green-50 text-green-700' : 'bg-yellow-50 text-yellow-700'
                }`}>
                    {user.isVerified ? 'Verified' : 'Pending'}
                </span>
            </div>
            
            <div className="flex items-center text-xs text-slate-500 bg-slate-50 p-2 rounded-lg">
                <MapPin size={12} className="mr-1.5 text-slate-400" /> 
                {user.location || 'No location set'}
            </div>

            {type === 'worker' && user.workerProfile && (
                <div className="pt-2 border-t border-slate-100 mt-1">
                    <div className="flex gap-1 flex-wrap mb-2">
                        {user.workerProfile.categories.map(c => (
                            <span key={c} className="bg-emerald-50 text-emerald-700 border border-emerald-100 text-[10px] px-2 py-0.5 rounded-full font-medium">{c}</span>
                        ))}
                    </div>
                    {user.workerProfile.bio && (
                        <p className="text-xs text-slate-500 italic line-clamp-2">
                            "{user.workerProfile.bio}"
                        </p>
                    )}
                </div>
            )}
            
            <div className="mt-3 pt-3 border-t border-slate-100 flex gap-2">
                {!user.isVerified ? (
                    <button 
                        onClick={() => handleVerify(user.id, true)}
                        className="flex-1 py-2 bg-emerald-600 text-white text-xs rounded-lg font-bold hover:bg-emerald-700 flex items-center justify-center gap-1 transition-colors"
                    >
                        <CheckCircle size={14} /> Approve
                    </button>
                ) : (
                     <button 
                        onClick={() => handleVerify(user.id, false)}
                        className="flex-1 py-2 bg-red-50 text-red-600 text-xs rounded-lg font-bold hover:bg-red-100 border border-red-100 flex items-center justify-center gap-1 transition-colors"
                    >
                        <XCircle size={14} /> Revoke
                    </button>
                )}
            </div>

            <div className="text-[10px] text-slate-300 text-right mt-1">
                ID: {user.id}
            </div>
        </div>
      ));
  };

  return (
    <div className="animate-fade-in pb-20">
      <div className="flex items-center justify-between mb-6 bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
        <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-lg text-white">
                <Shield size={24} />
            </div>
            <div>
                <h2 className="text-xl font-bold text-slate-800">Admin Console</h2>
                <p className="text-xs text-slate-500">Manage users and platform activity</p>
            </div>
        </div>
        <button 
            onClick={logout}
            className="flex items-center gap-2 px-3 py-2 bg-slate-100 text-slate-600 rounded-lg hover:bg-red-50 hover:text-red-600 transition-colors text-sm font-medium"
        >
            <LogOut size={16} />
            <span className="hidden sm:inline">Sign Out</span>
        </button>
      </div>
      
      <div className="flex border-b border-slate-200 mb-6 bg-white rounded-t-xl px-2 pt-2">
        <button
          onClick={() => setActiveTab('workers')}
          className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 transition-colors relative top-[1px] ${
            activeTab === 'workers' 
                ? 'text-emerald-600 border-b-2 border-emerald-600' 
                : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Hammer size={16} /> 
          Workers 
          {!isLoading && <span className="text-[10px] bg-slate-100 px-1.5 py-0.5 rounded-full text-slate-600">{workers.length}</span>}
        </button>
        <button
          onClick={() => setActiveTab('clients')}
          className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 transition-colors relative top-[1px] ${
            activeTab === 'clients' 
                ? 'text-indigo-600 border-b-2 border-indigo-600' 
                : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Briefcase size={16} /> 
          Clients 
          {!isLoading && <span className="text-[10px] bg-slate-100 px-1.5 py-0.5 rounded-full text-slate-600">{clients.length}</span>}
        </button>
      </div>
      
      <div className="space-y-4">
        {isLoading ? (
             <div className="flex flex-col items-center justify-center py-20 text-slate-400">
                <Loader2 size={32} className="animate-spin mb-2 text-indigo-500" />
                <p className="text-sm">Fetching users...</p>
             </div>
        ) : (
            activeTab === 'workers' ? renderUserList(workers, 'worker') : renderUserList(clients, 'client')
        )}
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-slate-800 text-white px-6 py-3 rounded-full shadow-2xl z-[100] animate-fade-in-up flex items-center gap-2 text-sm font-medium">
          <CheckCircle size={16} className="text-emerald-400" />
          {toastMessage}
        </div>
      )}
    </div>
  );
};