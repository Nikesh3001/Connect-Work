import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { User, Mail, MapPin, Phone, Lock, Save, Camera, Languages, Bell, Map as MapIcon, Search, Loader2, ShieldCheck, CreditCard, Landmark, Wallet, Plus, Trash2, Check, Banknote, X, CheckCircle } from 'lucide-react';
import { SUPPORTED_LANGUAGES } from '../constants';
import { LocationPicker } from '../components/LocationPicker';
import { api } from '../services/store';

export const ProfileSettings: React.FC = () => {
  const { user, updateUserProfile, requestNotificationPermission, refreshUser } = useApp();
  const [isEditing, setIsEditing] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Local state for form
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [location, setLocation] = useState(user?.location || '');
  const [password, setPassword] = useState(user?.password || '');
  const [language, setLanguage] = useState(user?.language || 'en');
  const [coords, setCoords] = useState(user?.coords);
  const [profilePicture, setProfilePicture] = useState(user?.profilePicture || '');
  // Initialize notifications from user pref or fallback to worker profile for legacy
  const [notificationsEnabled, setNotificationsEnabled] = useState(
      user?.notificationsEnabled ?? user?.workerProfile?.notificationsEnabled ?? false
  );

  // Bank & Payment State
  const [upiId, setUpiId] = useState(user?.paymentDetails?.upiId || '');
  const [bankAccount, setBankAccount] = useState(user?.paymentDetails?.bankAccount || '');
  const [ifsc, setIfsc] = useState(user?.paymentDetails?.ifsc || '');
  const [isEditingPayment, setIsEditingPayment] = useState(false);
  const [isSavingPayment, setIsSavingPayment] = useState(false);

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
      setToastMessage(msg);
      setTimeout(() => setToastMessage(null), 3000);
  };

  const [showAddFunds, setShowAddFunds] = useState(false);
  const [addFundsAmount, setAddFundsAmount] = useState('1000');

  // Sync state with user prop when it changes (e.g. on login or refresh)
  useEffect(() => {
    if (user) {
        setName(user.name || '');
        setEmail(user.email || '');
        setPhone(user.phone || '');
        setLocation(user.location || '');
        setPassword(user.password || '');
        setLanguage(user.language || 'en');
        setCoords(user.coords);
        setProfilePicture(user.profilePicture || '');
        setNotificationsEnabled(user.notificationsEnabled ?? user.workerProfile?.notificationsEnabled ?? false);
        
        // Sync Payment Details
        setUpiId(user.paymentDetails?.upiId || '');
        setBankAccount(user.paymentDetails?.bankAccount || '');
        setIfsc(user.paymentDetails?.ifsc || '');
    }
  }, [user]);

  if (!user) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Construct worker profile update if applicable - sync notification setting there too for legacy
    const updatedWorkerProfile = user.role === 'worker' && user.workerProfile ? {
        ...user.workerProfile,
        notificationsEnabled
    } : user.workerProfile;

    await updateUserProfile({
        name,
        email,
        phone,
        location,
        password,
        language,
        coords,
        profilePicture,
        notificationsEnabled, // Save to top level
        workerProfile: updatedWorkerProfile
    });
    setIsEditing(false);
    showToast('Settings updated successfully!');
  };

  const handleSavePayment = async () => {
      setIsSavingPayment(true);
      try {
          await api.updatePaymentDetails({
              upiId,
              bankAccount,
              ifsc
          });
          refreshUser();
          setIsEditingPayment(false);
      } catch (error) {
          console.error(error);
          showToast("Failed to save payment details");
      } finally {
          setIsSavingPayment(false);
      }
  };

  const handleLocationSelect = async (lat: number, lng: number) => {
    setCoords({ lat, lng });
    setShowMap(false);
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
        const data = await response.json();
        const address = data.address?.city || data.address?.town || data.display_name.split(',')[0];
        setLocation(address);
    } catch(e) {
        setLocation(`${lat.toFixed(4)}, ${lng.toFixed(4)}`);
    }
  };

  const handleSearchLocation = async () => {
    if (location && location.trim().length > 0) {
        setIsSearching(true);
        try {
            // Forward Geocoding: Try to find coordinates from the text input
            const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(location)}`);
            const data = await response.json();
            
            if (data && data.length > 0) {
                const lat = parseFloat(data[0].lat);
                const lng = parseFloat(data[0].lon);
                setCoords({ lat, lng });
            } else {
                showToast("Location not found. Try a different query.");
            }
        } catch (error) {
            console.error("Geocoding failed", error);
        } finally {
            setIsSearching(false);
        }
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        if (file.size > 4 * 1024 * 1024) { // 4MB Limit
            showToast("Image size is too large. Please choose an image under 4MB.");
            return;
        }
        const reader = new FileReader();
        reader.onloadend = () => {
            setProfilePicture(reader.result as string);
            setIsEditing(true); // Switch to edit mode so they can save
        };
        reader.readAsDataURL(file);
    }
  };

  const toggleNotifications = async () => {
      if (!isEditing) return;
      
      const newState = !notificationsEnabled;
      setNotificationsEnabled(newState);

      if (newState) {
          // If turning on, request permission if not granted
          if (Notification.permission === 'default') {
              await requestNotificationPermission();
          } else if (Notification.permission === 'denied') {
              showToast("Notifications are blocked in your browser settings. Please enable them manually.");
          }
      }
  };

  return (
    <div className="animate-fade-in pb-20">
      {showMap && (
        <LocationPicker 
            initialLat={coords?.lat || user.coords?.lat}
            initialLng={coords?.lng || user.coords?.lng}
            onConfirm={handleLocationSelect}
            onCancel={() => setShowMap(false)}
        />
      )}

      <div className="bg-indigo-600 pb-16 pt-6 px-4 rounded-b-3xl -mx-4 mb-4 shadow-lg text-white">
          <div className="flex flex-col items-center">
             <div className="relative">
                <div className="w-24 h-24 rounded-full bg-white/20 flex items-center justify-center text-4xl font-bold backdrop-blur-sm border-4 border-white/10 mb-3 overflow-hidden">
                    {profilePicture ? (
                        <img src={profilePicture} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                        user.name.charAt(0).toUpperCase()
                    )}
                </div>
                <button 
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute bottom-2 right-0 bg-white text-indigo-600 p-1.5 rounded-full shadow-lg hover:bg-slate-100 transition-colors"
                >
                    <Camera size={16} />
                </button>
                <input 
                    type="file" 
                    ref={fileInputRef}
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageUpload}
                />
             </div>
             <div className="flex items-center gap-2">
                 <h2 className="text-xl font-bold">{user.name}</h2>
                 {user.isVerified && <ShieldCheck size={18} className="text-emerald-300" />}
             </div>
             <p className="text-indigo-100 text-sm">{user.role.toUpperCase()}</p>
             
             {/* Wallet Quick View */}
             <div className="mt-4 bg-white/10 backdrop-blur-md rounded-2xl p-3 flex items-center justify-between w-full max-w-[200px] border border-white/20">
                 <div className="flex items-center gap-2">
                     <Wallet size={16} className="text-indigo-200" />
                     <span className="text-xs font-medium text-indigo-100">Balance</span>
                 </div>
                 <div className="flex items-center gap-2">
                     <span className="font-bold">₹{user.walletBalance?.toFixed(0) || 0}</span>
                     <button 
                        onClick={() => setShowAddFunds(true)}
                        className="bg-white text-indigo-600 p-1 rounded-full hover:bg-indigo-50 transition-colors"
                     >
                         <Plus size={12} />
                     </button>
                 </div>
             </div>
          </div>
      </div>

      <div className="px-4 -mt-10 space-y-4">
          
          {/* Main Profile Form */}
          <form onSubmit={handleSave} className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 space-y-5">
             <div className="flex justify-between items-center mb-2">
                 <h3 className="font-bold text-slate-800">Account Settings</h3>
                 <button 
                    type="button" 
                    onClick={() => setIsEditing(!isEditing)}
                    className="text-sm text-indigo-600 font-medium hover:text-indigo-800"
                 >
                    {isEditing ? 'Cancel' : 'Edit'}
                 </button>
             </div>
             
             {/* KYC Status Badge */}
             <div className="bg-slate-50 p-3 rounded-lg flex items-center justify-between">
                 <div className="flex items-center gap-2">
                    <CreditCard size={18} className="text-slate-400" />
                    <span className="text-xs font-bold text-slate-500 uppercase">KYC Status</span>
                 </div>
                 <span className={`text-xs font-bold px-2 py-1 rounded-full uppercase ${
                     user.kycStatus === 'VERIFIED' ? 'bg-green-100 text-green-700' : 
                     user.kycStatus === 'PENDING' ? 'bg-yellow-100 text-yellow-700' : 'bg-slate-200 text-slate-500'
                 }`}>
                     {user.kycStatus || 'NOT SUBMITTED'}
                 </span>
             </div>

             <div className="space-y-4">
                 
                 {/* Language Section */}
                 <div className="group">
                    <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">App Language</label>
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg group-focus-within:ring-2 group-focus-within:ring-indigo-500/20 transition-all">
                        <Languages className="w-5 h-5 text-slate-400" />
                        <select 
                            disabled={!isEditing}
                            value={language}
                            onChange={(e) => setLanguage(e.target.value)}
                            className="bg-transparent w-full outline-none text-slate-700 disabled:text-slate-500 bg-none"
                        >
                            {SUPPORTED_LANGUAGES.map(lang => (
                                <option key={lang.code} value={lang.code}>{lang.name}</option>
                            ))}
                        </select>
                    </div>
                 </div>

                 {/* Notifications Section - Now available for all roles */}
                 <div className="group">
                    <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">
                        {user.role === 'worker' ? 'Job Alerts & Notifications' : 'Notifications'}
                    </label>
                    <button 
                        type="button"
                        onClick={toggleNotifications}
                        disabled={!isEditing}
                        className={`w-full flex items-center justify-between p-3 rounded-lg transition-all text-left border ${
                            notificationsEnabled 
                                ? 'bg-indigo-50 border-indigo-200' 
                                : 'bg-slate-50 border-transparent'
                        } ${!isEditing && 'opacity-70'}`}
                    >
                        <div className="flex items-center gap-3">
                            <Bell className={`w-5 h-5 ${notificationsEnabled ? 'text-indigo-600' : 'text-slate-400'}`} />
                            <div className="flex flex-col">
                                <span className={`text-sm ${notificationsEnabled ? 'text-indigo-800 font-medium' : 'text-slate-600'}`}>
                                    {notificationsEnabled ? 'Enabled' : 'Disabled'}
                                </span>
                                {user.role === 'worker' && notificationsEnabled && (
                                    <span className="text-[10px] text-indigo-600">
                                        You will receive alerts for new matching jobs nearby.
                                    </span>
                                )}
                            </div>
                        </div>
                        
                        {/* Toggle Switch UI */}
                        <div className={`w-10 h-5 rounded-full relative transition-colors ${notificationsEnabled ? 'bg-indigo-600' : 'bg-slate-300'}`}>
                            <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-transform ${notificationsEnabled ? 'left-6' : 'left-1'}`}></div>
                        </div>
                    </button>
                 </div>

                 <div className="group">
                    <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">Full Name</label>
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg group-focus-within:ring-2 group-focus-within:ring-indigo-500/20 transition-all">
                        <User className="w-5 h-5 text-slate-400" />
                        <input 
                            type="text" 
                            disabled={!isEditing}
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="bg-transparent w-full outline-none text-slate-700 disabled:text-slate-500"
                        />
                    </div>
                 </div>

                 <div className="group">
                    <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">Email Address</label>
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg group-focus-within:ring-2 group-focus-within:ring-indigo-500/20 transition-all">
                        <Mail className="w-5 h-5 text-slate-400" />
                        <input 
                            type="email" 
                            disabled={!isEditing}
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="bg-transparent w-full outline-none text-slate-700 disabled:text-slate-500"
                        />
                    </div>
                 </div>

                 <div className="group">
                    <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">Phone Number</label>
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg group-focus-within:ring-2 group-focus-within:ring-indigo-500/20 transition-all">
                        <Phone className="w-5 h-5 text-slate-400" />
                        <input 
                            type="tel" 
                            disabled={!isEditing}
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            className="bg-transparent w-full outline-none text-slate-700 disabled:text-slate-500"
                        />
                    </div>
                 </div>

                 <div className="group">
                    <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">Default Location / Pincode</label>
                    <div className="flex items-center gap-2">
                        <div className="flex-1 flex items-center gap-3 p-3 bg-slate-50 rounded-lg group-focus-within:ring-2 group-focus-within:ring-indigo-500/20 transition-all relative">
                            <MapPin className="w-5 h-5 text-slate-400 shrink-0" />
                            <input 
                                type="text" 
                                disabled={!isEditing}
                                value={location}
                                onChange={(e) => setLocation(e.target.value)}
                                placeholder="Enter City or Pincode"
                                className="bg-transparent w-full outline-none text-slate-700 disabled:text-slate-500 pr-2"
                                onKeyDown={(e) => {
                                    if(e.key === 'Enter' && isEditing) {
                                        e.preventDefault();
                                        handleSearchLocation();
                                    }
                                }}
                            />
                        </div>
                        {isEditing && (
                             <button 
                                type="button"
                                onClick={handleSearchLocation}
                                disabled={isSearching || !location}
                                className="p-3 bg-indigo-50 text-indigo-600 rounded-lg border border-indigo-200 shrink-0"
                                title="Search Location"
                            >
                                {isSearching ? <Loader2 size={20} className="animate-spin" /> : <Search size={20} />}
                            </button>
                        )}
                        {isEditing && (
                            <button 
                                type="button" 
                                onClick={() => setShowMap(true)}
                                className="p-3 bg-indigo-50 text-indigo-600 rounded-lg border border-indigo-200 shrink-0"
                                title="Pick on Map"
                            >
                                <MapIcon size={20} />
                            </button>
                        )}
                    </div>
                 </div>

                 <div className="group">
                    <label className="block text-xs font-medium text-slate-500 mb-1 uppercase tracking-wider">Password</label>
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg group-focus-within:ring-2 group-focus-within:ring-indigo-500/20 transition-all">
                        <Lock className="w-5 h-5 text-slate-400" />
                        <input 
                            type={isEditing ? "text" : "password"}
                            disabled={!isEditing}
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="bg-transparent w-full outline-none text-slate-700 disabled:text-slate-500"
                        />
                    </div>
                 </div>
             </div>

             {isEditing && (
                 <button 
                    type="submit"
                    className="w-full flex justify-center items-center py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-500 shadow-md shadow-indigo-200 transition-all active:scale-95"
                 >
                    <Save className="w-4 h-4 mr-2" /> Save Changes
                 </button>
             )}
          </form>

          {/* Payment Methods Section (PhonePe Style) */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
              <div className="flex justify-between items-center mb-4">
                  <div>
                      <h3 className="font-bold text-slate-800">Payment Methods</h3>
                      <p className="text-xs text-slate-500">Manage Bank Account & UPI</p>
                  </div>
                  {!isEditingPayment ? (
                      <button 
                        onClick={() => setIsEditingPayment(true)}
                        className="text-indigo-600 text-sm font-bold flex items-center gap-1 hover:bg-indigo-50 px-3 py-1.5 rounded-lg transition-colors"
                      >
                          {bankAccount || upiId ? 'Edit' : 'Add New'}
                      </button>
                  ) : (
                       <button 
                        onClick={() => setIsEditingPayment(false)}
                        className="text-slate-400 text-sm font-medium hover:text-slate-600"
                      >
                          Cancel
                      </button>
                  )}
              </div>

              {isEditingPayment ? (
                  <div className="space-y-4 animate-fade-in">
                       {/* Bank Account Inputs */}
                       <div className="border border-indigo-100 rounded-xl p-4 bg-indigo-50/50">
                           <h4 className="flex items-center gap-2 font-bold text-sm text-indigo-800 mb-3">
                               <Landmark size={16} /> Bank Details
                           </h4>
                           <div className="space-y-3">
                                <div>
                                    <label className="text-xs font-medium text-slate-500 ml-1">Account Number</label>
                                    <input 
                                        type="text" 
                                        value={bankAccount}
                                        onChange={(e) => setBankAccount(e.target.value.replace(/\D/g, ''))}
                                        placeholder="Enter Account Number"
                                        className="w-full p-3 bg-white border border-indigo-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                                    />
                                </div>
                                <div>
                                    <label className="text-xs font-medium text-slate-500 ml-1">IFSC Code</label>
                                    <input 
                                        type="text" 
                                        value={ifsc}
                                        onChange={(e) => setIfsc(e.target.value.toUpperCase())}
                                        placeholder="e.g. SBIN0001234"
                                        className="w-full p-3 bg-white border border-indigo-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none uppercase"
                                        maxLength={11}
                                    />
                                </div>
                           </div>
                       </div>

                       {/* UPI Input */}
                       <div className="border border-indigo-100 rounded-xl p-4 bg-indigo-50/50">
                           <h4 className="flex items-center gap-2 font-bold text-sm text-indigo-800 mb-3">
                               <Wallet size={16} /> UPI VPA
                           </h4>
                           <div>
                                <label className="text-xs font-medium text-slate-500 ml-1">UPI ID</label>
                                <input 
                                    type="text" 
                                    value={upiId}
                                    onChange={(e) => setUpiId(e.target.value)}
                                    placeholder="e.g. user@okaxis"
                                    className="w-full p-3 bg-white border border-indigo-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                                />
                           </div>
                       </div>

                       <button 
                            onClick={handleSavePayment}
                            disabled={isSavingPayment}
                            className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
                        >
                            {isSavingPayment ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                            Verify & Save Details
                       </button>
                  </div>
              ) : (
                  <div className="space-y-3">
                      {/* Bank Card Display */}
                      <div className={`flex items-center p-4 rounded-xl border ${bankAccount ? 'border-indigo-200 bg-white' : 'border-dashed border-slate-200 bg-slate-50'}`}>
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-4 ${bankAccount ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-200 text-slate-400'}`}>
                              <Landmark size={20} />
                          </div>
                          <div className="flex-1">
                              {bankAccount ? (
                                  <>
                                    <p className="font-bold text-slate-800 text-sm flex items-center gap-2">
                                        State Bank of India 
                                        {/* Mock Verified Badge */}
                                        <span className="bg-green-100 text-green-700 text-[10px] px-1.5 py-0.5 rounded font-bold flex items-center">
                                            <Check size={10} className="mr-0.5" /> Verified
                                        </span>
                                    </p>
                                    <p className="text-xs text-slate-500 font-mono mt-0.5">
                                        •••• {bankAccount.slice(-4)} | {ifsc}
                                    </p>
                                  </>
                              ) : (
                                  <p className="text-sm text-slate-500 font-medium">No Bank Account Linked</p>
                              )}
                          </div>
                      </div>

                      {/* UPI Card Display */}
                      <div className={`flex items-center p-4 rounded-xl border ${upiId ? 'border-purple-200 bg-white' : 'border-dashed border-slate-200 bg-slate-50'}`}>
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-4 ${upiId ? 'bg-purple-100 text-purple-600' : 'bg-slate-200 text-slate-400'}`}>
                              <Wallet size={20} />
                          </div>
                          <div className="flex-1">
                              {upiId ? (
                                  <>
                                    <p className="font-bold text-slate-800 text-sm flex items-center gap-2">
                                        Unified Payments Interface (UPI)
                                        <span className="bg-green-100 text-green-700 text-[10px] px-1.5 py-0.5 rounded font-bold flex items-center">
                                            <Check size={10} className="mr-0.5" /> Verified
                                        </span>
                                    </p>
                                    <p className="text-xs text-slate-500 mt-0.5">{upiId}</p>
                                  </>
                              ) : (
                                  <p className="text-sm text-slate-500 font-medium">No UPI ID Linked</p>
                              )}
                          </div>
                      </div>
                  </div>
              )}
              
              <div className="mt-4 flex items-center justify-center gap-2 text-[10px] text-slate-400 bg-slate-50 p-2 rounded-lg">
                  <ShieldCheck size={12} className="text-green-500" />
                  <span>100% Secure Payments • PCI-DSS Compliant</span>
              </div>
          </div>

          <div className="mt-6 text-center text-xs text-slate-400">
             <p>Member since {new Date().getFullYear()}</p>
             <p className="mt-1">Version 1.0.4</p>
          </div>
      </div>

      {/* Add Funds Modal */}
      {showAddFunds && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
              <div className="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl animate-slide-up">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="text-xl font-bold text-slate-800">Add Funds</h3>
                      <button onClick={() => setShowAddFunds(false)} className="text-slate-400 hover:text-slate-600 bg-slate-100 p-2 rounded-full">
                          <X size={20} />
                      </button>
                  </div>
                  
                  <div className="mb-6">
                      <label className="block text-sm font-medium text-slate-700 mb-2">Amount (₹)</label>
                      <input 
                          type="number" 
                          value={addFundsAmount}
                          onChange={(e) => setAddFundsAmount(e.target.value)}
                          className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-lg font-bold"
                          placeholder="Enter amount"
                      />
                  </div>

                  <button 
                      onClick={async () => {
                          const amount = parseInt(addFundsAmount);
                          if (!isNaN(amount) && amount > 0) {
                              await api.addFunds(amount);
                              refreshUser();
                              showToast(`₹${amount} added to wallet!`);
                              setShowAddFunds(false);
                          } else {
                              showToast("Please enter a valid amount.");
                          }
                      }}
                      className="w-full py-3.5 bg-indigo-600 text-white rounded-xl font-bold text-lg shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-colors"
                  >
                      Add ₹{addFundsAmount || '0'}
                  </button>
              </div>
          </div>
      )}
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-slate-800 text-white px-6 py-3 rounded-full shadow-2xl z-[100] animate-fade-in-up flex items-center gap-2 text-sm font-medium">
          <CheckCircle size={16} className="text-emerald-400" />
          {toastMessage}
        </div>
      )}
    </div>
  );
};