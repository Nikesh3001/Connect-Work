import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/store';
import { optimizeJobDescription, generateSpeech, playRawAudio, translateText } from '../services/geminiService';
import { Job, WorkerCategory, User, JobStatus } from '../types';
import { CATEGORIES_LIST, MOCK_CITIES, AGRI_SUB_CATEGORIES } from '../constants';
import { MapPin, Wand2, Phone, MessageCircle, CheckCircle, Clock, Navigation, Loader2, Map as MapIcon, ChevronDown, ChevronUp, History, Filter, X, Search, Droplets, Zap, Wrench, Hammer, Paintbrush, BrickWall, Sparkles, Car, HardHat, Briefcase, Star, StarHalf, User as UserIcon, BadgeCheck, MessageSquare, Tractor, Sprout, Volume2, ShieldCheck, QrCode, Banknote, CreditCard, Wallet, Plus, Users } from 'lucide-react';
import { LocationPicker } from '../components/LocationPicker';
import { ChatInterface } from '../components/ChatInterface';

const getCategoryIcon = (category: WorkerCategory) => {
    const iconProps = { size: 18, className: "shrink-0" };
    switch (category) {
        case WorkerCategory.AGRICULTURE: return <div className="p-2 rounded-lg bg-green-100 text-green-700"><Tractor {...iconProps} /></div>;
        case WorkerCategory.PLUMBER: return <div className="p-2 rounded-lg bg-blue-100 text-blue-600"><Droplets {...iconProps} /></div>;
        case WorkerCategory.ELECTRICIAN: return <div className="p-2 rounded-lg bg-yellow-100 text-yellow-600"><Zap {...iconProps} /></div>;
        case WorkerCategory.MECHANIC: return <div className="p-2 rounded-lg bg-slate-100 text-slate-600"><Wrench {...iconProps} /></div>;
        case WorkerCategory.CARPENTER: return <div className="p-2 rounded-lg bg-orange-100 text-orange-600"><Hammer {...iconProps} /></div>;
        case WorkerCategory.PAINTER: return <div className="p-2 rounded-lg bg-pink-100 text-pink-600"><Paintbrush {...iconProps} /></div>;
        case WorkerCategory.MASON: return <div className="p-2 rounded-lg bg-red-100 text-red-600"><BrickWall {...iconProps} /></div>;
        case WorkerCategory.CLEANER: return <div className="p-2 rounded-lg bg-purple-100 text-purple-600"><Sparkles {...iconProps} /></div>;
        case WorkerCategory.DRIVER: return <div className="p-2 rounded-lg bg-indigo-100 text-indigo-600"><Car {...iconProps} /></div>;
        case WorkerCategory.LABORER: return <div className="p-2 rounded-lg bg-yellow-100 text-yellow-700"><HardHat {...iconProps} /></div>;
        default: return <div className="p-2 rounded-lg bg-slate-100 text-slate-500"><Briefcase {...iconProps} /></div>;
    }
};

export const ClientDashboard: React.FC = () => {
  const { user, refreshUser } = useApp();
  const [activeTab, setActiveTab] = useState<'post' | 'my-jobs' | 'wallet'>('post');
  
  // Job Form State
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<WorkerCategory | ''>('');
  const [subCategory, setSubCategory] = useState<string | undefined>(undefined);
  const [location, setLocation] = useState(user?.location || '');
  const [budget, setBudget] = useState('');
  const [coords, setCoords] = useState<{lat: number, lng: number} | undefined>(user?.coords);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isPosting, setIsPosting] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [postSuccess, setPostSuccess] = useState(false);

  // My Jobs State
  const [myJobs, setMyJobs] = useState<Job[]>([]);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [interestedWorkers, setInterestedWorkers] = useState<User[]>([]);
  const [unreadCounts, setUnreadCounts] = useState<Record<string, number>>({});
  
  // Chat State
  const [activeChatJob, setActiveChatJob] = useState<Job | null>(null);
  
  // Rating State
  const [jobToRate, setJobToRate] = useState<Job | null>(null);
  const [ratingStars, setRatingStars] = useState(0);
  const [ratingComment, setRatingComment] = useState('');
  const [isSubmittingRating, setIsSubmittingRating] = useState(false);

  // QR Scanning State
  const [scanJob, setScanJob] = useState<Job | null>(null);
  const [qrInput, setQrInput] = useState('');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  
  // Completion Loading State
  const [isCompletingJob, setIsCompletingJob] = useState<string | null>(null);
  
  // Booking Loading State
  const [isBooking, setIsBooking] = useState<string | null>(null);

  // Filtering State
  const [filterStatus, setFilterStatus] = useState<JobStatus | 'ALL'>('ALL');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [appliedFilterStatus, setAppliedFilterStatus] = useState<JobStatus | 'ALL'>('ALL');
  const [appliedFilterCategory, setAppliedFilterCategory] = useState<string>('ALL');
  
  // Expanded card state for details view (History + Map)
  const [expandedJobId, setExpandedJobId] = useState<string | null>(null);

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
      setToastMessage(msg);
      setTimeout(() => setToastMessage(null), 3000);
  };

  const [showAddFunds, setShowAddFunds] = useState(false);
  const [addFundsAmount, setAddFundsAmount] = useState('1000');

  // Profile completion check
  if (!user?.name) {
    return (
      <div className="p-6 bg-white rounded-xl shadow-sm">
        <h2 className="text-xl font-bold mb-4">Complete Profile</h2>
        <input 
            type="text" 
            placeholder="Your Name" 
            className="w-full p-3 border rounded mb-4"
            onBlur={(e) => {
                if(e.target.value) {
                    api.updateUser({ name: e.target.value }).then(refreshUser);
                }
            }}
        />
        <p className="text-sm text-slate-500">Please enter your name to continue.</p>
      </div>
    );
  }

  const fetchMyJobs = async () => {
    if (user) {
      const jobs = await api.getJobs({ type: 'client', userId: user.id });
      setMyJobs(jobs);
      const counts = await api.getUnreadCounts(user.id);
      setUnreadCounts(counts);
    }
  };

  useEffect(() => {
    if (activeTab === 'my-jobs') {
      fetchMyJobs();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab]);

  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
        if (e.key === 'connectwork_db_v3') {
            fetchMyJobs();
            refreshUser();
        }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [user]);

  const handleOptimize = async () => {
    if (!description) return;
    setIsOptimizing(true);
    const optimized = await optimizeJobDescription(description, category || 'General');
    setDescription(optimized);
    setIsOptimizing(false);
  };

  const handleListenToDescription = async () => {
      if (!description) return;
      if (isPlayingAudio) return; // Prevent multiple clicks

      setIsPlayingAudio(true);
      try {
          // 1. If user has a preferred language other than English, translate first
          let textToSpeak = description;
          if (user?.language && user.language !== 'en') {
              textToSpeak = await translateText(description, user.language);
          }

          // 2. Generate Audio
          const base64Audio = await generateSpeech(textToSpeak);
          
          if (base64Audio) {
              // 3. Play Audio
              await playRawAudio(base64Audio);
          } else {
              showToast("Could not generate audio at this time.");
          }
      } catch (error) {
          console.error("Audio playback error:", error);
          showToast("Failed to play audio.");
      } finally {
          setIsPlayingAudio(false);
      }
  };

  const handleLocationSelect = async (lat: number, lng: number) => {
    setCoords({ lat, lng });
    setShowMap(false);
    
    // Reverse Geocoding
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
        const data = await response.json();
        
        let humanReadableAddress = '';
        if (data.address) {
            const parts = [
                data.address.road,
                data.address.village || data.address.suburb || data.address.residential || data.address.neighbourhood,
                data.address.city || data.address.town || data.address.county,
                data.address.state_district
            ].filter(Boolean);
            
            if (parts.length > 0) {
                humanReadableAddress = parts.join(', ');
            } else {
                humanReadableAddress = data.display_name.split(',').slice(0, 3).join(',');
            }
        } else {
            humanReadableAddress = `GPS: ${lat.toFixed(4)}, ${lng.toFixed(4)}`;
        }
        setLocation(humanReadableAddress);
    } catch (error) {
        console.error("Geocoding failed", error);
        setLocation(`${lat.toFixed(5)}, ${lng.toFixed(5)}`);
    }
  };

  const handleSearchLocation = async () => {
    if (location && location.trim().length > 0) {
        setIsSearching(true);
        try {
            // Forward Geocoding: Try to find coordinates from the text input
            const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(location)}`);
            const data = await response.json();
            
            if (data && data.length > 0) {
                const lat = parseFloat(data[0].lat);
                const lng = parseFloat(data[0].lon);
                setCoords({ lat, lng });
            } else {
                showToast("Location not found. Try a different query.");
            }
        } catch (error) {
            console.error("Geocoding failed", error);
        } finally {
            setIsSearching(false);
        }
    }
  };

  const handlePostJob = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !category || !budget) return;
    setIsPosting(true);
    
    let finalTitle = `${category} needed in ${location}`;
    if (category === WorkerCategory.AGRICULTURE && subCategory) {
        finalTitle = `${subCategory} needed in ${location}`;
    }

    await api.postJob({
      clientId: user.id,
      clientName: user.name,
      clientPhone: user.phone,
      title: finalTitle,
      description,
      category,
      subCategory,
      location,
      budget: parseInt(budget, 10),
      coords,
    });
    setIsPosting(false);
    setDescription('');
    setCategory('');
    setSubCategory(undefined);
    setBudget('');
    setActiveTab('my-jobs');
    setPostSuccess(true);
    setTimeout(() => setPostSuccess(false), 3000);
  };

  const handleViewWorkers = async (job: Job) => {
    // Fetch latest job data to ensure we have up-to-date interested workers
    const latestJob = await api.getJobById(job.id);
    if (!latestJob) return;
    
    setSelectedJob(latestJob);
    const workers = await api.getWorkersByIds(latestJob.interestedWorkerIds);
    setInterestedWorkers(workers);
  };

  const handleBookWorker = async (workerId: string) => {
    if (!selectedJob) return;

    setIsBooking(workerId);
    try {
        // Defaulting to CASH to bypass wallet escrow logic
        const updatedJob = await api.bookWorker(selectedJob.id, workerId, 'CASH');
        
        // Optimistically update local state to avoid flicker/delay
        setMyJobs(prevJobs => prevJobs.map(j => j.id === updatedJob.id ? updatedJob : j));
        refreshUser(); // Update wallet balance in header
        
        showToast("Worker Booked Successfully!");
            
        setSelectedJob(null);
    } catch (e: any) {
        console.error("Booking Error:", e);
        showToast("Booking failed: " + (e.message || "Unknown error"));
    } finally {
        setIsBooking(null);
        fetchMyJobs();
    }
  };

  const handleMarkCompleted = async (job: Job) => {
      setIsCompletingJob(job.id);
      try {
          const result = await api.completeJob(job.id);
          
          setMyJobs(prev => prev.map(j => j.id === job.id ? { ...j, status: 'COMPLETED', paymentStatus: 'RELEASED' } : j));
          
          showToast(result.method === 'ONLINE' 
            ? `Success! Funds released to worker.` 
            : `Success! Job marked as completed.`);
      } catch(error: any) {
          showToast(error.message);
      } finally {
          setIsCompletingJob(null);
          fetchMyJobs();
      }
  };

  const handleVerifyPayment = async () => {
      if (!scanJob || !qrInput) return;
      setIsProcessingPayment(true);
      try {
          const result = await api.verifyAndPayout(scanJob.id, qrInput);
          showToast(`Success! Job verified & completed.`);
          setScanJob(null);
          setQrInput('');
          fetchMyJobs();
      } catch (error: any) {
          showToast(error.message);
      } finally {
          setIsProcessingPayment(false);
      }
  };

  const handleUpdateStatus = async (jobId: string, status: JobStatus) => {
      await api.updateJobStatus(jobId, status);
      fetchMyJobs();
  };

  const toggleDetails = (jobId: string) => {
      setExpandedJobId(expandedJobId === jobId ? null : jobId);
  };

  const openRatingModal = (job: Job) => {
      setJobToRate(job);
      setRatingStars(0);
      setRatingComment('');
  };

  const submitRating = async () => {
      if (!jobToRate || ratingStars === 0) return;
      setIsSubmittingRating(true);
      try {
          await api.rateWorker(jobToRate.id, {
              stars: ratingStars,
              comment: ratingComment
          });
          setJobToRate(null);
          fetchMyJobs();
      } catch (e) {
          showToast("Failed to submit rating");
      } finally {
          setIsSubmittingRating(false);
      }
  };

  // Filter Logic
  const filteredJobs = myJobs.filter(job => {
      if (appliedFilterStatus !== 'ALL' && job.status !== appliedFilterStatus) return false;
      if (appliedFilterCategory !== 'ALL' && job.category !== appliedFilterCategory) return false;
      return true;
  });

  return (
    <div className="pb-20">
      {postSuccess && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-emerald-600 text-white px-4 py-3 rounded-xl shadow-lg shadow-emerald-200 animate-fade-in">
            <div className="bg-white/20 p-1 rounded-full"><CheckCircle size={16} /></div>
            <p className="text-sm font-bold">Job Posted Successfully!</p>
        </div>
      )}

      {showMap && (
        <LocationPicker 
            initialLat={coords?.lat}
            initialLng={coords?.lng}
            onConfirm={handleLocationSelect}
            onCancel={() => setShowMap(false)}
        />
      )}

      {/* Chat Modal */}
      {activeChatJob && user && (
          <ChatInterface 
             jobId={activeChatJob.id}
             currentUserId={user.id}
             otherUserName={activeChatJob.assignedWorkerName || 'Worker'}
             onClose={() => {
                 setActiveChatJob(null);
                 fetchMyJobs(); // Refresh counts on close
             }}
          />
      )}

      {/* Tabs */}
      <div className="flex border-b border-slate-200 mb-6">
        <button
          onClick={() => setActiveTab('post')}
          className={`flex-1 py-3 text-sm font-medium ${
            activeTab === 'post' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500'
          }`}
        >
          Post a Job
        </button>
        <button
          onClick={() => setActiveTab('my-jobs')}
          className={`flex-1 py-3 text-sm font-medium ${
            activeTab === 'my-jobs' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500'
          }`}
        >
          My Jobs
        </button>
        <button
          onClick={() => setActiveTab('wallet')}
          className={`flex-1 py-3 text-sm font-medium ${
            activeTab === 'wallet' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500'
          }`}
        >
          Wallet
        </button>
      </div>

      {activeTab === 'post' ? (
        <form onSubmit={handlePostJob} className="space-y-6 animate-fade-in">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Service Category</label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {CATEGORIES_LIST.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => { setCategory(cat); setSubCategory(undefined); }}
                  className={`p-3 rounded-lg text-sm border flex items-center justify-center gap-2 ${
                    category === cat
                      ? 'bg-indigo-50 border-indigo-500 text-indigo-700 font-medium ring-1 ring-indigo-500'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {getCategoryIcon(cat)}
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Agriculture Sub-Category Section */}
          {category === WorkerCategory.AGRICULTURE && (
              <div className="animate-fade-in p-4 bg-green-50 border border-green-200 rounded-xl">
                  <h4 className="flex items-center gap-2 text-sm font-bold text-green-800 mb-3">
                      <Sprout size={16} /> Select Agriculture Requirement
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                      {AGRI_SUB_CATEGORIES.map((sub) => (
                          <button
                            key={sub.id}
                            type="button"
                            onClick={() => setSubCategory(sub.label)}
                            className={`p-3 rounded-lg text-xs font-medium border flex flex-col items-center justify-center gap-1 text-center transition-all ${
                                subCategory === sub.label
                                    ? 'bg-white border-green-600 text-green-700 shadow-md transform scale-105'
                                    : 'bg-white/60 border-green-100 text-slate-600 hover:bg-white'
                            }`}
                          >
                              <span className="text-xl">{sub.icon}</span>
                              {sub.label}
                          </button>
                      ))}
                  </div>
              </div>
          )}

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Location</label>
            <div className="flex gap-2">
                <div className="relative flex-1">
                <MapPin className="absolute left-3 top-3.5 h-5 w-5 text-slate-400" />
                <input
                    type="text"
                    list="cities"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleSearchLocation(); } }}
                    placeholder="Area, Street, or Pincode"
                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-indigo-500"
                />
                <datalist id="cities">
                    {MOCK_CITIES.map(c => <option key={c} value={c} />)}
                </datalist>
                </div>
                <button 
                    type="button"
                    onClick={handleSearchLocation}
                    disabled={isSearching}
                    className="px-4 bg-indigo-50 border border-indigo-200 text-indigo-600 rounded-lg hover:bg-indigo-100 transition-colors flex items-center justify-center min-w-[3rem]"
                    title="Search Location"
                >
                    {isSearching ? <Loader2 size={20} className="animate-spin" /> : <Search size={20} />}
                </button>
                <button 
                    type="button"
                    onClick={() => setShowMap(true)}
                    className="px-4 bg-indigo-50 border border-indigo-200 text-indigo-600 rounded-lg hover:bg-indigo-100 transition-colors flex items-center justify-center min-w-[3rem]"
                    title="Pick on Map"
                >
                    <MapIcon size={20} />
                </button>
            </div>
            {coords && <p className="text-xs text-green-600 mt-1 flex items-center"><CheckCircle size={10} className="mr-1"/> Exact pin selected</p>}
          </div>

          <div className="grid grid-cols-2 gap-4">
              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Budget (₹)</label>
                  <div className="relative">
                      <span className="absolute left-3 top-3 text-slate-500">₹</span>
                      <input 
                        type="number"
                        value={budget}
                        onChange={(e) => setBudget(e.target.value)}
                        placeholder="500"
                        className="w-full pl-8 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-indigo-500"
                      />
                  </div>
              </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="block text-sm font-medium text-slate-700">Description</label>
              <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={handleListenToDescription}
                    disabled={!description || isPlayingAudio}
                    className={`text-xs flex items-center gap-1 font-medium transition-colors px-2 py-1 rounded-md border ${
                        isPlayingAudio 
                            ? 'bg-green-100 text-green-700 border-green-200' 
                            : 'bg-white text-slate-600 border-slate-200 hover:text-indigo-600 hover:border-indigo-200'
                    } disabled:opacity-50`}
                  >
                     {isPlayingAudio ? <Loader2 size={12} className="animate-spin" /> : <Volume2 size={12} />}
                     {isPlayingAudio ? 'Playing...' : 'Listen'}
                  </button>
                  <button
                    type="button"
                    onClick={handleOptimize}
                    disabled={!description || isOptimizing}
                    className="text-xs flex items-center text-indigo-600 hover:text-indigo-800 disabled:opacity-50"
                  >
                    <Wand2 className="w-3 h-3 mr-1" />
                    {isOptimizing ? 'Optimizing...' : 'AI Polish'}
                  </button>
              </div>
            </div>
            <textarea
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-3 border border-slate-300 rounded-lg focus:ring-indigo-500"
              placeholder={category === WorkerCategory.AGRICULTURE 
                ? "Describe field size, equipment needed, or specific crop details..." 
                : "Describe the issue (e.g., dripping tap in kitchen)..."
              }
            />
          </div>

          <button
            type="submit"
            disabled={isPosting || !category || !budget || (category === WorkerCategory.AGRICULTURE && !subCategory)}
            className="w-full py-3 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-500 disabled:opacity-50 shadow-lg shadow-indigo-200 transition-transform active:scale-95 flex items-center justify-center gap-2"
          >
            {isPosting ? <Loader2 className="animate-spin" /> : <ShieldCheck size={20} />}
            {isPosting ? 'Posting...' : 'Post Job'}
          </button>
        </form>
      ) : activeTab === 'my-jobs' ? (
        <div className="space-y-4 animate-fade-in">
          {/* Filters */}
          <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
                        <Filter size={16} /> Filter Jobs
                    </div>
                    {(appliedFilterStatus !== 'ALL' || appliedFilterCategory !== 'ALL' || filterStatus !== 'ALL' || filterCategory !== 'ALL') && (
                        <button 
                            onClick={() => { 
                                setFilterStatus('ALL'); 
                                setFilterCategory('ALL'); 
                                setAppliedFilterStatus('ALL');
                                setAppliedFilterCategory('ALL');
                            }}
                            className="text-xs text-indigo-600 flex items-center gap-1 hover:underline"
                        >
                            <X size={12} /> Clear
                        </button>
                    )}
                </div>
                <div className="flex gap-2">
                    <select 
                        value={filterStatus} 
                        onChange={(e) => setFilterStatus(e.target.value as any)}
                        className="flex-1 p-2 border border-slate-200 rounded-lg text-xs bg-slate-50 focus:ring-2 focus:ring-indigo-500 outline-none"
                    >
                        <option value="ALL">All Status</option>
                        <option value="OPEN">Open</option>
                        <option value="BOOKED">Booked</option>
                        <option value="COMPLETED">Completed</option>
                        <option value="CANCELLED">Cancelled</option>
                    </select>

                    <select 
                        value={filterCategory} 
                        onChange={(e) => setFilterCategory(e.target.value)}
                        className="flex-1 p-2 border border-slate-200 rounded-lg text-xs bg-slate-50 focus:ring-2 focus:ring-indigo-500 outline-none"
                    >
                        <option value="ALL">All Categories</option>
                        {CATEGORIES_LIST.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    </select>
                </div>
                <button
                    onClick={() => {
                        setAppliedFilterStatus(filterStatus);
                        setAppliedFilterCategory(filterCategory);
                    }}
                    className="w-full mt-2 py-2 bg-indigo-50 text-indigo-600 border border-indigo-200 rounded-lg text-xs font-bold hover:bg-indigo-100 transition-colors"
                >
                    Apply Filter
                </button>
           </div>

          {filteredJobs.length === 0 ? (
            <div className="text-center py-10 text-slate-400">
              <p>{myJobs.length === 0 ? 'No jobs posted yet.' : 'No jobs match your filters.'}</p>
            </div>
          ) : (
            filteredJobs.map((job) => (
              <div key={job.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm transition-all">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-slate-800 flex items-center gap-2">
                      {getCategoryIcon(job.category)}
                      <div>
                        {job.category}
                        {job.subCategory && <span className="block text-xs text-slate-500 font-normal">{job.subCategory}</span>}
                      </div>
                  </h3>
                  <div className="flex flex-col items-end gap-1">
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                        job.status === 'OPEN' ? 'bg-green-100 text-green-700' :
                        job.status === 'BOOKED' ? 'bg-blue-100 text-blue-700' : 
                        job.status === 'COMPLETED' ? 'bg-slate-100 text-slate-700' : 'bg-red-100 text-red-700'
                      }`}>
                        {job.status}
                      </span>
                      <span className="text-xs font-bold text-slate-700">₹{job.budget}</span>
                  </div>
                </div>
                <p className="text-sm text-slate-600 mb-3">{job.description}</p>
                <div className="mb-4">
                    <div className="flex items-center text-xs text-slate-400 mb-2">
                        <MapPin className="w-3 h-3 mr-1" /> {job.location}
                        <span className="mx-2">•</span>
                        <Clock className="w-3 h-3 mr-1" /> {new Date(job.postedAt).toLocaleDateString()}
                    </div>
                </div>

                {/* Actions */}
                {job.status === 'OPEN' && (
                  <button
                    onClick={() => handleViewWorkers(job)}
                    className="w-full py-2 border border-indigo-200 text-indigo-600 rounded-lg text-sm font-medium hover:bg-indigo-50"
                  >
                    View Interested Workers ({job.interestedWorkerIds.length})
                  </button>
                )}

                {/* Display Assigned Worker for BOOKED or COMPLETED status only */}
                {job.assignedWorkerId && (job.status === 'BOOKED' || job.status === 'COMPLETED') && (
                    <div className="mb-4 bg-white p-4 rounded-xl border border-indigo-100 shadow-sm">
                        <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-50">
                            <BadgeCheck className="text-indigo-600" size={16} />
                            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Assigned Professional</span>
                        </div>
                        
                        <div className="flex items-center gap-4 mb-4">
                            <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 text-lg font-bold border-2 border-white shadow-md">
                                {job.assignedWorkerName ? job.assignedWorkerName.charAt(0).toUpperCase() : <UserIcon size={24} />}
                            </div>
                            <div>
                                <h4 className="font-bold text-slate-800 text-base">{job.assignedWorkerName}</h4>
                                <div className="flex items-center gap-2 text-sm text-slate-500">
                                    <Phone size={14} />
                                    <span className="font-mono">{job.assignedWorkerPhone || 'No Phone'}</span>
                                </div>
                                {job.assignedWorkerVerified && (
                                    <span className="mt-1 flex items-center text-[10px] text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded-full border border-blue-100 font-medium w-fit">
                                        <BadgeCheck size={10} className="mr-0.5" /> Verified
                                    </span>
                                )}
                            </div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-2">
                                <a 
                                    href={`tel:${job.assignedWorkerPhone}`}
                                    className="flex flex-col items-center justify-center gap-1 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 transition-colors"
                                >
                                    <Phone size={18} className="text-green-600" />
                                    <span className="text-[10px] font-medium">Call</span>
                                </a>
                                
                                <a 
                                    href={`https://wa.me/${job.assignedWorkerPhone?.replace(/\D/g,'')}`}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="flex flex-col items-center justify-center gap-1 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 transition-colors"
                                >
                                    <MessageSquare size={18} className="text-emerald-500" />
                                    <span className="text-[10px] font-medium">WhatsApp</span>
                                </a>

                                <button 
                                    onClick={() => setActiveChatJob(job)}
                                    className="relative flex flex-col items-center justify-center gap-1 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 transition-colors"
                                >
                                    <div className="relative">
                                        <MessageCircle size={18} className="text-indigo-600" />
                                        {unreadCounts[job.id] > 0 && (
                                            <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full border border-white">
                                                {unreadCounts[job.id]}
                                            </span>
                                        )}
                                    </div>
                                    <span className="text-[10px] font-medium">Chat</span>
                                </button>
                        </div>
                        
                        {job.status === 'BOOKED' && (
                            <div className={`mt-3 text-xs p-2 rounded flex items-start gap-2 ${job.paymentMethod === 'ONLINE' ? 'bg-indigo-50 text-indigo-700' : 'bg-yellow-50 text-yellow-700'}`}>
                                <div className="mt-0.5"><ShieldCheck size={12} /></div>
                                <p>
                                    {job.paymentMethod === 'ONLINE' 
                                        ? "Escrow Active. Payment secured. Only release after work is complete."
                                        : "Booking Confirmed. Payment pending (Cash/Offline) upon completion."}
                                </p>
                            </div>
                        )}
                    </div>
                )}

                {job.status === 'BOOKED' && (
                  <div className="space-y-2">
                        {/* Primary Action: Mark Completed (Direct Payout) */}
                        <button 
                             onClick={() => handleMarkCompleted(job)}
                             disabled={isCompletingJob === job.id}
                             className={`w-full py-3 text-white rounded-lg text-sm font-bold shadow-lg flex items-center justify-center gap-2 ${
                                 job.paymentMethod === 'ONLINE' 
                                    ? 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-200'
                                    : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200'
                             }`}
                        >
                            {isCompletingJob === job.id ? <Loader2 className="animate-spin" size={18}/> : <CheckCircle size={18} />}
                            {job.paymentMethod === 'ONLINE' ? 'Release Payment & Complete' : 'Mark Work Completed'}
                        </button>

                        <div className="flex gap-2">
                            <button 
                                onClick={() => setScanJob(job)}
                                className="flex-1 py-2 bg-slate-50 text-slate-700 border border-slate-200 rounded-lg text-xs font-bold hover:bg-slate-100 flex items-center justify-center gap-2"
                            >
                                <QrCode size={16} /> Scan QR (Optional)
                            </button>
                            <button 
                                onClick={() => handleUpdateStatus(job.id, 'CANCELLED')}
                                className="flex-1 py-2 bg-red-50 text-red-600 border border-red-100 rounded-lg text-xs font-medium hover:bg-red-100"
                            >
                                Cancel Job
                            </button>
                        </div>
                  </div>
                )}
                
                {/* Rating Button for Completed Jobs */}
                {job.status === 'COMPLETED' && (
                     <div className="mt-3">
                         {job.isRated ? (
                             <div className="w-full py-2 bg-slate-50 border border-slate-200 text-slate-500 rounded-lg text-sm flex items-center justify-center gap-2">
                                 <Star size={16} fill="gold" className="text-yellow-400" /> Rated
                             </div>
                         ) : (
                             <button
                                onClick={() => openRatingModal(job)}
                                className="w-full py-2 bg-yellow-50 border border-yellow-200 text-yellow-700 rounded-lg text-sm font-medium hover:bg-yellow-100 flex items-center justify-center gap-2"
                             >
                                 <Star size={16} /> Rate Worker
                             </button>
                         )}
                     </div>
                )}

                {/* Details Toggle Button */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex justify-center">
                    <button 
                        onClick={() => toggleDetails(job.id)}
                        className="flex items-center text-xs font-medium text-slate-500 hover:text-indigo-600 transition-colors bg-slate-50 px-3 py-1.5 rounded-full"
                    >
                        {expandedJobId === job.id ? (
                            <>Hide Details <ChevronUp size={14} className="ml-1"/></>
                        ) : (
                            <>View Details <ChevronDown size={14} className="ml-1"/></>
                        )}
                    </button>
                </div>
                    
                {/* Expanded Details Section */}
                {expandedJobId === job.id && (
                        <div className="mt-4 space-y-4 animate-fade-in bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                            
                            {/* Map Section */}
                            {job.coords && (
                                <div className="rounded-xl overflow-hidden border border-slate-200 bg-white shadow-sm">
                                    <div className="p-2 border-b border-slate-100 flex items-center justify-between bg-slate-50">
                                        <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
                                            <MapIcon size={14} className="text-indigo-500" />
                                            Location Map
                                        </div>
                                        <a 
                                            href={`https://www.google.com/maps/search/?api=1&query=${job.coords.lat},${job.coords.lng}`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="text-[10px] text-indigo-600 hover:underline flex items-center gap-1"
                                        >
                                            <Navigation size={10} /> Open GPS
                                        </a>
                                    </div>
                                    <div className="h-48 w-full relative">
                                        <LocationPicker 
                                            initialLat={job.coords.lat}
                                            initialLng={job.coords.lng}
                                            readOnly={true}
                                            embedded={true}
                                        />
                                    </div>
                                </div>
                            )}

                            {/* Status History Timeline */}
                            <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-sm">
                                <h4 className="text-xs font-bold text-slate-500 mb-3 flex items-center gap-2 uppercase tracking-wider">
                                    <History size={12} /> Status History
                                </h4>
                                <div className="relative pl-2">
                                    <div className="absolute left-[9px] top-2 bottom-2 w-0.5 bg-slate-100"></div>
                                    <div className="space-y-4">
                                        {job.statusHistory?.map((entry, idx) => (
                                            <div key={idx} className="relative flex items-start pl-6">
                                                <div className={`absolute left-0 top-1 w-5 h-5 rounded-full border-2 flex items-center justify-center z-10 bg-white ${
                                                    idx === job.statusHistory!.length - 1 ? 'border-indigo-500 text-indigo-600' : 'border-slate-300 text-slate-400'
                                                }`}>
                                                    <div className={`w-1.5 h-1.5 rounded-full ${idx === job.statusHistory!.length - 1 ? 'bg-indigo-600' : 'bg-slate-300'}`}></div>
                                                </div>
                                                <div>
                                                    <p className="text-xs font-bold text-slate-700">{entry.status}</p>
                                                    <p className="text-[10px] text-slate-500">{new Date(entry.timestamp).toLocaleString()}</p>
                                                    {entry.note && <p className="text-xs text-slate-600 mt-0.5 bg-slate-50 p-1.5 rounded border border-slate-100 italic">{entry.note}</p>}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                )}
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="space-y-6 animate-fade-in px-1">
            {/* Wallet Card */}
            <div className="bg-gradient-to-br from-indigo-800 to-indigo-600 text-white p-6 rounded-2xl shadow-xl relative overflow-hidden">
                <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl"></div>
                <div className="relative z-10">
                    <p className="text-indigo-200 text-sm font-medium mb-1">Available Balance</p>
                    <h2 className="text-4xl font-bold mb-6">₹{user?.walletBalance?.toFixed(2) || '0.00'}</h2>
                    
                    <div className="flex gap-3">
                        <button 
                          onClick={() => setShowAddFunds(true)}
                          className="flex-1 bg-white text-indigo-700 py-2.5 rounded-xl font-bold text-sm hover:bg-indigo-50 transition-colors flex items-center justify-center gap-2"
                        >
                            <Plus size={18} /> Add Money
                        </button>
                    </div>
                </div>
            </div>

            {/* Payment Settings */}
            <div className="bg-white rounded-xl border border-slate-200 p-4">
                <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <Wallet size={18} /> Payment Methods
                </h3>
                <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Linked UPI ID</label>
                    <div className="flex gap-2">
                        <input 
                          type="text" 
                          placeholder="user@upi"
                          className="flex-1 p-2 border border-slate-300 rounded-lg text-sm"
                          defaultValue={user?.paymentDetails?.upiId}
                          onBlur={(e) => {
                              if(e.target.value && e.target.value !== user?.paymentDetails?.upiId) {
                                  api.updatePaymentDetails({ upiId: e.target.value }).then(refreshUser);
                              }
                          }}
                        />
                        <button className="bg-slate-100 text-slate-600 px-3 py-2 rounded-lg text-xs font-bold border border-slate-200">
                            Update
                        </button>
                    </div>
                </div>
            </div>
        </div>
      )}

      {/* Modal for Selecting Workers */}
      {selectedJob && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-t-2xl sm:rounded-2xl p-6 shadow-2xl animate-fade-in-up">
            <h3 className="text-lg font-bold mb-4 text-slate-800">Select a Professional</h3>
            <div className="max-h-[60vh] overflow-y-auto space-y-3 mb-4 pr-1">
              {interestedWorkers.length === 0 ? (
                <p className="text-slate-500 text-center py-8 bg-slate-50 rounded-lg border border-dashed border-slate-200">
                    No interest expressed yet.<br/>
                    <span className="text-xs">Check back later!</span>
                </p>
              ) : (
                interestedWorkers.map(w => (
                  <div key={w.id} className="p-4 border border-slate-200 rounded-xl bg-slate-50/50 hover:bg-white transition-colors">
                    <div className="flex justify-between items-start mb-3">
                        <div>
                            <div className="flex items-center gap-1">
                                <p className="font-bold text-slate-800">{w.name}</p>
                                {w.isVerified && (
                                    <BadgeCheck size={14} className="text-blue-500" />
                                )}
                            </div>
                            <div className="flex items-center text-xs mt-1">
                                {w.workerProfile?.rating ? (
                                    <>
                                        <div className="flex text-yellow-400 mr-1">
                                            {Array.from({length: Math.round(w.workerProfile.rating)}).map((_,i) => <Star key={i} size={10} fill="currentColor"/>)}
                                        </div>
                                        <span className="text-slate-400">({w.workerProfile.rating})</span>
                                    </>
                                ) : (
                                    <span className="text-slate-400">New Worker</span>
                                )}
                            </div>
                        </div>
                        <div className="text-right">
                             <span className="text-xs font-bold text-slate-600 block">Experience</span>
                             <span className="text-xs text-slate-500">{w.workerProfile?.experienceYears || 0} Years</span>
                        </div>
                    </div>
                    
                    <div className="mt-3">
                         <button
                            onClick={() => handleBookWorker(w.id)}
                            disabled={isBooking !== null}
                            className="w-full py-2.5 bg-indigo-600 text-white text-sm font-bold rounded-lg hover:bg-indigo-700 shadow-md shadow-indigo-100 disabled:opacity-50 flex items-center justify-center gap-2"
                         >
                            {isBooking === w.id ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle size={16} />}
                            Book Worker
                         </button>
                    </div>
                  </div>
                ))
              )}
            </div>
            <button
              onClick={() => setSelectedJob(null)}
              className="w-full py-3 text-slate-500 font-medium hover:text-slate-700 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* QR Scanner / Payment Release Modal */}
      {scanJob && (
          <div className="fixed inset-0 bg-black/80 z-[60] flex items-center justify-center p-4 animate-fade-in backdrop-blur-sm">
              <div className="bg-white w-full max-w-sm rounded-2xl p-6 shadow-2xl relative">
                  <button onClick={() => setScanJob(null)} className="absolute right-4 top-4 text-slate-400 hover:text-slate-600"><X size={20}/></button>
                  
                  <div className="text-center mb-6">
                      <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4 text-indigo-600 animate-pulse">
                          <QrCode size={32} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-800">Scan Worker's QR</h3>
                      <p className="text-sm text-slate-500 mt-1">
                          Ask {scanJob.assignedWorkerName} to show their completion QR code to verify.
                      </p>
                  </div>

                  {/* Simulation of Camera View */}
                  <div className="bg-black rounded-lg h-48 mb-4 flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-0 border-2 border-green-500 opacity-50 m-8 rounded-lg animate-pulse"></div>
                      <p className="text-white/50 text-xs">Camera Simulator Active</p>
                  </div>

                  <div className="space-y-4">
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase">Or Enter Code Manually</label>
                          <input 
                            type="text" 
                            value={qrInput}
                            onChange={(e) => setQrInput(e.target.value.toUpperCase())}
                            placeholder="e.g. A1B2"
                            className="w-full p-3 text-center text-2xl font-mono tracking-widest border border-slate-300 rounded-lg mt-1 focus:ring-2 focus:ring-indigo-500 uppercase"
                            maxLength={4}
                          />
                      </div>
                      
                      <button 
                        onClick={handleVerifyPayment}
                        disabled={isProcessingPayment || qrInput.length < 4}
                        className="w-full py-3 bg-emerald-600 text-white rounded-lg font-bold hover:bg-emerald-700 disabled:opacity-50 flex items-center justify-center gap-2"
                      >
                         {isProcessingPayment ? <Loader2 className="animate-spin" /> : <Banknote size={20} />}
                         Verify & Complete Job
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Rating Modal */}
      {jobToRate && (
          <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4 animate-fade-in">
              <div className="bg-white w-full max-w-sm rounded-2xl p-6 shadow-2xl scale-100">
                  <div className="text-center mb-4">
                      <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-3 text-yellow-600">
                          <Star size={24} fill="currentColor" />
                      </div>
                      <h3 className="text-lg font-bold text-slate-800">Rate {jobToRate.assignedWorkerName}</h3>
                      <p className="text-sm text-slate-500">How was your experience?</p>
                  </div>

                  <div className="flex justify-center gap-2 mb-6">
                      {[1, 2, 3, 4, 5].map((star) => (
                          <button 
                            key={star}
                            onClick={() => setRatingStars(star)}
                            className={`p-1 transition-transform hover:scale-110 ${ratingStars >= star ? 'text-yellow-400' : 'text-slate-200'}`}
                          >
                              <Star size={32} fill="currentColor" />
                          </button>
                      ))}
                  </div>
                  
                  <textarea 
                    className="w-full p-3 border border-slate-200 rounded-lg text-sm mb-4 focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                    placeholder="Write a comment (optional)..."
                    rows={3}
                    value={ratingComment}
                    onChange={(e) => setRatingComment(e.target.value)}
                  />

                  <div className="flex gap-2">
                      <button 
                        onClick={() => setJobToRate(null)}
                        className="flex-1 py-3 text-slate-500 font-medium hover:bg-slate-50 rounded-lg"
                      >
                          Skip
                      </button>
                      <button 
                        onClick={submitRating}
                        disabled={ratingStars === 0 || isSubmittingRating}
                        className="flex-1 py-3 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 disabled:opacity-50"
                      >
                          {isSubmittingRating ? 'Submitting...' : 'Submit Review'}
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Add Funds Modal */}
      {showAddFunds && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
              <div className="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl animate-slide-up">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="text-xl font-bold text-slate-800">Add Funds</h3>
                      <button onClick={() => setShowAddFunds(false)} className="text-slate-400 hover:text-slate-600 bg-slate-100 p-2 rounded-full">
                          <X size={20} />
                      </button>
                  </div>
                  
                  <div className="mb-6">
                      <label className="block text-sm font-medium text-slate-700 mb-2">Amount (₹)</label>
                      <input 
                          type="number" 
                          value={addFundsAmount}
                          onChange={(e) => setAddFundsAmount(e.target.value)}
                          className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-lg font-bold"
                          placeholder="Enter amount"
                      />
                  </div>

                  <button 
                      onClick={async () => {
                          const amount = parseInt(addFundsAmount);
                          if (!isNaN(amount) && amount > 0) {
                              await api.addFunds(amount);
                              refreshUser();
                              showToast(`₹${amount} added to wallet!`);
                              setShowAddFunds(false);
                          } else {
                              showToast("Please enter a valid amount.");
                          }
                      }}
                      className="w-full py-3.5 bg-indigo-600 text-white rounded-xl font-bold text-lg shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-colors"
                  >
                      Add ₹{addFundsAmount || '0'}
                  </button>
              </div>
          </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-slate-800 text-white px-6 py-3 rounded-full shadow-2xl z-[100] animate-fade-in-up flex items-center gap-2 text-sm font-medium">
          <CheckCircle size={16} className="text-emerald-400" />
          {toastMessage}
        </div>
      )}
    </div>
  );
};