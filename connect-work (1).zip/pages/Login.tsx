import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/store';
import { Mail, Lock, User, Phone, MapPin, ArrowRight, Chrome, Facebook, Key, ArrowLeft, CheckCircle, Sprout, GraduationCap, Loader2 } from 'lucide-react';
import { APP_NAME } from '../constants';

export const Login: React.FC = () => {
  const { login, socialLogin, register } = useApp();
  const [isLoginView, setIsLoginView] = useState(true);
  const [showForgot, setShowForgot] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Form States
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [rememberMe, setRememberMe] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');
    setIsSubmitting(true);

    try {
      if (showForgot) {
         if (!email) throw new Error("Please enter your email.");
         await api.resetPasswordRequest(email);
         setSuccessMsg(`Reset link sent to ${email}`);
      } else if (isLoginView) {
        await login(email, password);
      } else {
        if (!name || !email || !password || !phone) {
            throw new Error("Please fill in all required fields.");
        }
        await register({ name, email, password, phone, location });
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleClick = async () => {
      setError('');
      setIsSubmitting(true);
      try {
          await socialLogin('google', '', ''); // Email and name will be fetched from Google
      } catch (err: any) {
          setError(err.message || 'Google login failed');
          setIsSubmitting(false);
      }
  };

  const handleFacebookLogin = async () => {
      setError('');
      setIsSubmitting(true);
      try {
          await socialLogin('facebook', '', ''); // Email and name will be fetched from Facebook
      } catch (err: any) {
          setError(err.message || 'Facebook login failed');
          setIsSubmitting(false);
      }
  };

  const toggleForgot = () => {
      setShowForgot(!showForgot);
      setError('');
      setSuccessMsg('');
  };

  return (
    <div className="min-h-screen bg-[#F3F4F6] md:flex md:items-center md:justify-center p-0 relative overflow-hidden">
      
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
          <div className="absolute -top-[30%] -left-[10%] w-[70%] h-[70%] bg-indigo-200/30 rounded-full blur-[100px]"></div>
          <div className="absolute top-[20%] -right-[10%] w-[50%] h-[60%] bg-emerald-100/40 rounded-full blur-[100px]"></div>
      </div>

      {/* Main Card Container */}
      <div className="w-full max-w-[1050px] h-full md:h-[680px] bg-white md:rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row relative z-10 border border-white/40">
        
        {/* Left Side - Visuals */}
        <div className="w-full md:w-[45%] relative hidden md:block overflow-hidden bg-slate-900 group">
            {/* Background Image - Professional Workplace / Connection Theme */}
            <div 
                className="absolute inset-0 bg-cover bg-center transition-transform duration-[30s] ease-in-out group-hover:scale-110"
                style={{ backgroundImage: `url('https://images.unsplash.com/photo-1573167243872-43c6433b9d40?q=80&w=1969&auto=format&fit=crop')` }}
            ></div>
            
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-b from-indigo-900/80 via-indigo-900/60 to-slate-900/90 mix-blend-multiply"></div>
            
            <div className="relative z-10 h-full flex flex-col justify-between p-10 text-white">
                <div>
                     {/* Logo Area */}
                     <div className="flex items-center gap-3 mb-8">
                         <div className="bg-white/10 backdrop-blur-md border border-white/20 p-2.5 rounded-xl shadow-lg">
                            <Sprout className="text-emerald-300" size={24} />
                         </div>
                         <h1 className="text-xl font-bold tracking-tight text-white/90">
                            Connect<span className="text-indigo-300">Work</span>
                         </h1>
                    </div>
                    
                    <div className="space-y-6 animate-fade-in pt-4">
                        <h2 className="text-4xl font-bold text-white leading-tight drop-shadow-sm">
                            Empowering <br/>
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-200 to-emerald-200">Local Communities</span>
                        </h2>
                        <p className="text-indigo-100 font-light leading-relaxed text-base border-l-2 border-indigo-400/50 pl-4">
                            Connect securely with skilled professionals in your area. 
                            Simple booking, secure escrow payments, and verified profiles.
                        </p>
                    </div>
                </div>

                {/* Bottom Stats / Student Info */}
                <div className="animate-fade-in space-y-6">
                    <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-4 rounded-2xl">
                        <div className="flex items-center gap-2 mb-2 text-indigo-200 text-xs font-bold uppercase tracking-wider">
                             <GraduationCap size={14} />
                             LBRCE Student Project
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed">
                            A fully functional marketplace platform demonstrating advanced React patterns and secure workflow simulation.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        {/* Right Side - Form */}
        <div className="w-full md:w-[55%] flex flex-col h-full bg-white relative">
            
            {/* Mobile Header Branding */}
            <div className="md:hidden bg-gradient-to-r from-indigo-600 to-indigo-700 p-8 pb-10 text-white text-center rounded-b-[2.5rem] mb-4 relative z-10 shadow-lg">
                <div className="bg-white/10 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 backdrop-blur-md border border-white/20 shadow-inner">
                    <Sprout size={32} className="text-emerald-300" />
                </div>
                <h1 className="text-2xl font-bold tracking-tight">{APP_NAME}</h1>
                <p className="text-xs text-indigo-200 font-medium mt-1 uppercase tracking-wide">Secure Local Services</p>
            </div>

            <div className="flex-1 overflow-y-auto px-8 md:px-16 py-10 custom-scrollbar flex flex-col justify-center">
                
                {/* Header Section */}
                <div className="text-center mb-10">
                    {!showForgot && (
                        <>
                            <h2 className="text-3xl font-extrabold text-slate-800 tracking-tight mb-2">
                                {isLoginView ? 'Welcome Back' : 'Join Us'}
                            </h2>
                            <p className="text-slate-500 text-sm">
                                {isLoginView 
                                    ? 'Please enter your details to sign in.' 
                                    : 'Create an account to start your journey.'}
                            </p>
                        </>
                    )}
                </div>

                {showForgot ? (
                    <div className="text-center animate-fade-in max-w-sm mx-auto">
                        <div className="mx-auto w-20 h-20 bg-indigo-50 rounded-full flex items-center justify-center mb-6 text-indigo-600 ring-4 ring-indigo-50/50">
                            <Key size={32} />
                        </div>
                        <h2 className="text-2xl font-bold text-slate-800 mb-2">Reset Password</h2>
                        <p className="text-slate-500 text-sm mb-8">
                            No worries! Enter your email and we will send you reset instructions.
                        </p>
                        
                        {successMsg ? (
                            <div className="bg-green-50 border border-green-100 text-green-700 p-4 rounded-xl text-sm mb-6 flex items-start gap-3 text-left">
                                <CheckCircle size={18} className="shrink-0 mt-0.5" />
                                <div>{successMsg}</div>
                            </div>
                        ) : (
                            <form onSubmit={handleSubmit} className="space-y-4">
                                <div className="group relative">
                                    <Mail className="absolute left-4 top-3.5 h-5 w-5 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                                    <input
                                        type="email"
                                        placeholder="Enter your email"
                                        required
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        className="block w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white transition-all outline-none"
                                    />
                                </div>
                                <button
                                    type="submit"
                                    disabled={isSubmitting}
                                    className="w-full py-3.5 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-500 transition-all shadow-lg shadow-indigo-200 hover:shadow-indigo-300"
                                >
                                    {isSubmitting ? 'Sending Link...' : 'Send Reset Link'}
                                </button>
                            </form>
                        )}
                        
                        <button 
                            onClick={toggleForgot}
                            className="mt-8 flex items-center justify-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-800 transition-colors"
                        >
                            <ArrowLeft size={16} /> Back to Login
                        </button>
                    </div>
                ) : (
                    <form onSubmit={handleSubmit} className="space-y-5 animate-fade-in max-w-sm mx-auto w-full">
                        
                        {!isLoginView && (
                            <div className="group relative">
                                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                    <User className="h-5 w-5 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                                </div>
                                <input
                                    type="text"
                                    placeholder="Full Name"
                                    required
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    className="block w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white transition-all outline-none text-sm placeholder:text-slate-400"
                                />
                            </div>
                        )}

                        <div className="group relative">
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                <Mail className="h-5 w-5 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                            </div>
                            <input
                                type="email"
                                placeholder="Email Address"
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="block w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white transition-all outline-none text-sm placeholder:text-slate-400"
                            />
                        </div>

                        {!isLoginView && (
                            <>
                                <div className="group relative">
                                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                        <Phone className="h-5 w-5 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                                    </div>
                                    <input
                                        type="tel"
                                        placeholder="Phone Number"
                                        required
                                        value={phone}
                                        onChange={(e) => setPhone(e.target.value)}
                                        className="block w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white transition-all outline-none text-sm placeholder:text-slate-400"
                                    />
                                </div>
                                <div className="group relative">
                                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                        <MapPin className="h-5 w-5 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                                    </div>
                                    <input
                                        type="text"
                                        placeholder="City / Location"
                                        value={location}
                                        onChange={(e) => setLocation(e.target.value)}
                                        className="block w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white transition-all outline-none text-sm placeholder:text-slate-400"
                                    />
                                </div>
                            </>
                        )}

                        <div className="group relative">
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                <Lock className="h-5 w-5 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                            </div>
                            <input
                                type="password"
                                placeholder="Password"
                                required
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="block w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white transition-all outline-none text-sm placeholder:text-slate-400"
                            />
                        </div>

                        {isLoginView && (
                            <div className="flex items-center justify-between text-sm pt-1">
                                <label className="flex items-center gap-2 cursor-pointer group">
                                    <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${rememberMe ? 'bg-indigo-600 border-indigo-600' : 'border-slate-300 bg-white group-hover:border-indigo-400'}`}>
                                        {rememberMe && <CheckCircle size={12} className="text-white" />}
                                    </div>
                                    <input 
                                        type="checkbox" 
                                        checked={rememberMe}
                                        onChange={() => setRememberMe(!rememberMe)}
                                        className="hidden"
                                    />
                                    <span className="text-slate-500 group-hover:text-slate-700 transition-colors">Remember me</span>
                                </label>
                                <button type="button" onClick={toggleForgot} className="text-indigo-600 font-semibold hover:text-indigo-700 transition-colors">
                                    Forgot Password?
                                </button>
                            </div>
                        )}

                        {error && <p className="text-red-600 text-sm text-center bg-red-50 border border-red-100 p-3 rounded-xl animate-shake">{error}</p>}

                        <button
                            type="submit"
                            disabled={isSubmitting}
                            className="w-full py-3.5 px-4 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-500 hover:shadow-indigo-300 transform transition-all active:scale-[0.98] flex justify-center items-center mt-2"
                        >
                            {isSubmitting ? <Loader2 className="animate-spin" size={20} /> : (isLoginView ? 'Sign In' : 'Create Account')}
                            {!isSubmitting && <ArrowRight size={18} className="ml-2 group-hover:translate-x-1 transition-transform" />}
                        </button>
                    </form>
                )}

                {!showForgot && (
                    <div className="mt-8 max-w-sm mx-auto w-full">
                        <div className="relative">
                            <div className="absolute inset-0 flex items-center">
                                <div className="w-full border-t border-slate-200"></div>
                            </div>
                            <div className="relative flex justify-center text-xs uppercase tracking-wider font-bold">
                                <span className="px-4 bg-white text-slate-400">Or continue with</span>
                            </div>
                        </div>

                        <div className="mt-6 grid grid-cols-2 gap-4">
                            <button 
                                onClick={handleGoogleClick}
                                disabled={isSubmitting}
                                className="flex justify-center items-center py-2.5 px-4 border border-slate-200 rounded-xl hover:bg-slate-50 hover:border-slate-300 transition-all group"
                            >
                                <Chrome className="w-5 h-5 text-slate-600 group-hover:text-red-500 transition-colors mr-2" />
                                <span className="text-sm font-semibold text-slate-600 group-hover:text-slate-800">Google</span>
                            </button>
                            <button 
                                onClick={handleFacebookLogin}
                                disabled={isSubmitting}
                                className="flex justify-center items-center py-2.5 px-4 border border-slate-200 rounded-xl hover:bg-slate-50 hover:border-slate-300 transition-all group"
                            >
                                <Facebook className="w-5 h-5 text-slate-600 group-hover:text-blue-600 transition-colors mr-2" />
                                <span className="text-sm font-semibold text-slate-600 group-hover:text-slate-800">Facebook</span>
                            </button>
                        </div>

                        <div className="mt-8 text-center">
                            <p className="text-slate-500 text-sm">
                                {isLoginView ? "Don't have an account?" : "Already have an account?"}
                                <button 
                                    onClick={() => { setIsLoginView(!isLoginView); setError(''); }}
                                    className="ml-2 text-indigo-600 font-bold hover:text-indigo-800 transition-colors"
                                >
                                    {isLoginView ? 'Sign Up' : 'Log In'}
                                </button>
                            </p>
                        </div>
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};
