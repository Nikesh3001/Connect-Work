import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { MapPin, Navigation, Check, X, Loader2 } from 'lucide-react';

interface LocationPickerProps {
    initialLat?: number;
    initialLng?: number;
    onConfirm?: (lat: number, lng: number) => void;
    onCancel?: () => void;
    readOnly?: boolean;
    embedded?: boolean;
}

export const LocationPicker: React.FC<LocationPickerProps> = ({ 
    initialLat, 
    initialLng, 
    onConfirm, 
    onCancel, 
    readOnly = false,
    embedded = false 
}) => {
    const mapContainerRef = useRef<HTMLDivElement>(null);
    const mapInstanceRef = useRef<L.Map | null>(null);
    const [center, setCenter] = useState<{ lat: number; lng: number } | null>(null);
    const [isLocating, setIsLocating] = useState(false);

    // Initialize Map
    useEffect(() => {
        if (!mapContainerRef.current || mapInstanceRef.current) return;

        // Default to a central location (e.g., India center) if no initial coords, or browser geolocation later
        const defaultLat = initialLat || 20.5937; 
        const defaultLng = initialLng || 78.9629;
        const zoomLevel = initialLat ? 15 : 5;

        const map = L.map(mapContainerRef.current, {
            zoomControl: !embedded, // Hide zoom control in embedded mode to keep UI clean
            attributionControl: false,
            dragging: true, // Always allow dragging for interactivity
            touchZoom: true, // Always allow touch zoom
            scrollWheelZoom: !embedded, // Disable scroll zoom if embedded to prevent scroll trapping
            doubleClickZoom: true,
            boxZoom: true,
            keyboard: true,
        }).setView([defaultLat, defaultLng], zoomLevel);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
        }).addTo(map);

        mapInstanceRef.current = map;
        setCenter({ lat: defaultLat, lng: defaultLng });

        if (initialLat && initialLng) {
            L.marker([initialLat, initialLng]).addTo(map);
        }

        if (!readOnly) {
            map.on('move', () => {
                const c = map.getCenter();
                setCenter({ lat: c.lat, lng: c.lng });
            });
        }

        if (!initialLat && !initialLng && !readOnly) {
            handleLocateMe();
        }
        
        return () => {
            map.remove();
            mapInstanceRef.current = null;
        };
    }, []);

    const handleLocateMe = () => {
        setIsLocating(true);
        if (!navigator.geolocation) {
            console.warn("Geolocation not supported");
            setIsLocating(false);
            return;
        }
        navigator.geolocation.getCurrentPosition(
            (pos) => {
                const { latitude, longitude } = pos.coords;
                mapInstanceRef.current?.setView([latitude, longitude], 16);
                setIsLocating(false);
            },
            (err) => {
                console.error(err);
                setIsLocating(false);
            }
        );
    };

    const handleConfirm = () => {
        if (center && onConfirm) {
            onConfirm(center.lat, center.lng);
        }
    };

    const containerClass = embedded 
        ? "w-full h-full relative rounded-xl overflow-hidden bg-slate-100" 
        : "fixed inset-0 z-[2000] bg-white flex flex-col animate-fade-in";

    return (
        <div className={containerClass}>
            {/* Header - Only if not embedded */}
            {!embedded && (
                <div className="bg-white p-4 shadow-md z-10 flex justify-between items-center border-b border-slate-100">
                    <button onClick={onCancel} className="p-2 rounded-full hover:bg-slate-100 text-slate-500">
                        <X size={24} />
                    </button>
                    <h3 className="font-bold text-slate-800">{readOnly ? 'Job Location' : 'Pin Location'}</h3>
                    {!readOnly && (
                        <button 
                            onClick={handleConfirm} 
                            className="flex items-center gap-1 bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-indigo-200 hover:bg-indigo-700"
                        >
                            <Check size={18} /> Confirm
                        </button>
                    )}
                </div>
            )}

            {/* Map Container */}
            <div className={`flex-1 relative bg-slate-100 ${embedded ? 'min-h-full' : ''}`}>
                <div ref={mapContainerRef} className="absolute inset-0 z-0" />
                
                {/* Center Pin Marker (Only in Edit Mode) */}
                {!readOnly && (
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 pointer-events-none -mt-4">
                        <MapPin size={48} className="text-indigo-600 drop-shadow-xl fill-indigo-100" />
                        <div className="w-2 h-2 bg-indigo-800 rounded-full mx-auto -mt-1 shadow-sm"></div>
                    </div>
                )}

                {/* Floating Controls */}
                {!readOnly && (
                    <button 
                        onClick={handleLocateMe}
                        className="absolute bottom-6 right-6 z-10 bg-white p-3 rounded-full shadow-lg border border-slate-200 text-indigo-600 hover:bg-indigo-50 active:scale-95 transition-transform"
                    >
                        {isLocating ? <Loader2 size={24} className="animate-spin" /> : <Navigation size={24} />}
                    </button>
                )}
                
                {!readOnly && (
                    <div className="absolute top-4 left-1/2 -translate-x-1/2 z-10 bg-white/90 backdrop-blur px-4 py-2 rounded-full shadow-sm text-xs font-medium text-slate-600 border border-slate-200 pointer-events-none">
                        Move map to adjust pin
                    </div>
                )}
            </div>
            
            {/* Footer Info - Only if not embedded */}
            {!embedded && (
                <div className="bg-white p-4 border-t border-slate-100">
                    <p className="text-xs text-slate-400 uppercase tracking-wider mb-1">
                        {readOnly ? 'Exact Location' : 'Selected Coordinates'}
                    </p>
                    <p className="font-mono text-slate-700 font-medium">
                        {readOnly && initialLat && initialLng 
                            ? `${initialLat.toFixed(6)}, ${initialLng.toFixed(6)}` 
                            : center ? `${center.lat.toFixed(6)}, ${center.lng.toFixed(6)}` : 'Locating...'}
                    </p>
                </div>
            )}
        </div>
    );
};