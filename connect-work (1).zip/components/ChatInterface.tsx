import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/store';
import { ChatMessage } from '../types';
import { Send, User as UserIcon, X, Loader2 } from 'lucide-react';

interface ChatInterfaceProps {
    jobId: string;
    currentUserId: string;
    otherUserName: string;
    onClose: () => void;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
    jobId, 
    currentUserId, 
    otherUserName,
    onClose
}) => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [newMessage, setNewMessage] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [isSending, setIsSending] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const loadMessages = async () => {
        const msgs = await api.getJobMessages(jobId);
        setMessages(msgs);
        setIsLoading(false);
        // Mark as read immediately when viewed
        await api.markMessagesAsRead(jobId, currentUserId);
    };

    // Initial Load and Polling/Listener
    useEffect(() => {
        loadMessages();
        
        // Poll for new messages every 3 seconds
        const interval = setInterval(() => {
            loadMessages();
        }, 3000);

        // Also listen for local storage changes (if user is testing in two tabs)
        const handleStorageChange = (e: StorageEvent) => {
            if (e.key === 'connectwork_db_v3') {
                loadMessages();
            }
        };
        window.addEventListener('storage', handleStorageChange);

        return () => {
            clearInterval(interval);
            window.removeEventListener('storage', handleStorageChange);
        };
    }, [jobId]);

    // Auto-scroll to bottom
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newMessage.trim()) return;

        setIsSending(true);
        try {
            await api.sendMessage(jobId, currentUserId, newMessage);
            setNewMessage('');
            loadMessages(); // Refresh immediately
        } finally {
            setIsSending(false);
        }
    };

    return (
        <div className="fixed inset-0 z-[2200] bg-black/50 flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white w-full max-w-md h-[80vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden">
                {/* Header */}
                <div className="bg-indigo-600 p-4 flex items-center justify-between text-white shrink-0">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                            <UserIcon size={20} />
                        </div>
                        <div>
                            <h3 className="font-bold text-sm">{otherUserName}</h3>
                            <p className="text-xs text-indigo-200">Online</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                        <X size={20} />
                    </button>
                </div>

                {/* Messages Area */}
                <div className="flex-1 overflow-y-auto p-4 bg-slate-50 space-y-4">
                    {isLoading ? (
                        <div className="flex justify-center items-center h-full text-slate-400">
                            <Loader2 size={24} className="animate-spin" />
                        </div>
                    ) : messages.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-full text-slate-400 text-sm">
                            <p>No messages yet.</p>
                            <p>Start the conversation!</p>
                        </div>
                    ) : (
                        messages.map((msg) => {
                            const isMe = msg.senderId === currentUserId;
                            return (
                                <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                                    <div className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-sm shadow-sm ${
                                        isMe 
                                            ? 'bg-indigo-600 text-white rounded-br-none' 
                                            : 'bg-white text-slate-700 border border-slate-200 rounded-bl-none'
                                    }`}>
                                        <p>{msg.text}</p>
                                        <p className={`text-[10px] mt-1 text-right ${isMe ? 'text-indigo-200' : 'text-slate-400'}`}>
                                            {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                        </p>
                                    </div>
                                </div>
                            );
                        })
                    )}
                    <div ref={messagesEndRef} />
                </div>

                {/* Input Area */}
                <form onSubmit={handleSend} className="p-3 bg-white border-t border-slate-100 flex gap-2 shrink-0">
                    <input 
                        type="text" 
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type a message..."
                        className="flex-1 bg-slate-100 border-none rounded-full px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                    <button 
                        type="submit" 
                        disabled={!newMessage.trim() || isSending}
                        className="p-2.5 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                        {isSending ? <Loader2 size={20} className="animate-spin" /> : <Send size={20} className="ml-0.5" />}
                    </button>
                </form>
            </div>
        </div>
    );
};