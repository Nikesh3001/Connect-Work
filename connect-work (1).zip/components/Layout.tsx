import React from 'react';
import { useApp } from '../context/AppContext';
import { LogOut, User as UserIcon, Briefcase, ShieldCheck } from 'lucide-react';
import { APP_NAME } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { user, logout, updateUserProfile, currentView, setView } = useApp();

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col md:flex-row md:justify-center">
      
      <div className="w-full max-w-md md:max-w-4xl mx-auto bg-white shadow-2xl overflow-hidden flex flex-col md:flex-row min-h-screen md:min-h-0 md:h-[90vh] md:my-auto md:rounded-2xl">
        
        {/* Desktop Sidebar (Visible only on md+) */}
        {user && !user.isAdmin && user.roleSelected && (
            <aside className="hidden md:flex w-64 bg-slate-50 border-r border-slate-200 flex-col p-6">
                <div className="mb-8">
                     <h1 className="text-2xl font-bold text-indigo-700 tracking-tight">{APP_NAME}</h1>
                     <span className="text-xs bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full uppercase tracking-wider font-semibold mt-1 inline-block">
                        {user.role}
                    </span>
                </div>

                <nav className="flex-1 space-y-2">
                    <button 
                        onClick={() => setView('dashboard')}
                        className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${currentView === 'dashboard' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-200'}`}
                    >
                        <Briefcase size={20} />
                        <span className="font-medium">Jobs</span>
                    </button>
                    <button 
                        onClick={() => setView('settings')}
                        className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${currentView === 'settings' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-200'}`}
                    >
                        <UserIcon size={20} />
                        <span className="font-medium">Profile</span>
                    </button>
                </nav>

                <div className="pt-6 border-t border-slate-200">
                    <button onClick={logout} className="flex items-center gap-2 text-slate-500 hover:text-red-600 transition-colors">
                        <LogOut size={18} />
                        <span className="text-sm font-medium">Sign Out</span>
                    </button>
                </div>
            </aside>
        )}

        <div className="flex-1 flex flex-col h-full overflow-hidden">
            {/* Mobile Header (Hidden on md+ if role selected, otherwise visible) */}
            <header className={`bg-indigo-600 text-white p-4 flex justify-between items-center sticky top-0 z-50 ${user && !user.isAdmin && user.roleSelected ? 'md:hidden' : ''}`}>
                <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight">{APP_NAME}</h1>
                {user && (
                    <span className="text-xs bg-indigo-700 px-2 py-0.5 rounded-full uppercase tracking-wider font-semibold">
                    {user.role}
                    </span>
                )}
                </div>
                
                {user && (
                <div className="flex items-center gap-3">
                    {user.isAdmin && <ShieldCheck size={20} className="text-yellow-300" />}
                    {!user.isAdmin && user.roleSelected && (
                        <button 
                        onClick={() => updateUserProfile({ roleSelected: false })} 
                        className="text-xs bg-indigo-500 hover:bg-indigo-400 text-white px-2 py-1 rounded transition-colors"
                        >
                        Switch Role
                        </button>
                    )}
                    <button onClick={logout} className="p-2 hover:bg-indigo-700 rounded-full transition-colors md:hidden">
                        <LogOut size={20} />
                    </button>
                </div>
                )}
            </header>

            {/* Main Content */}
            <main className="flex-1 overflow-y-auto p-4 scrollbar-hide relative bg-white">
                {children}
            </main>

            {/* Mobile Bottom Nav (Only if logged in and not admin) */}
            {user && !user.isAdmin && user.roleSelected && (
                <nav className="md:hidden bg-white border-t border-slate-200 p-3 flex justify-around items-center">
                <button 
                    onClick={() => setView('dashboard')}
                    className={`flex flex-col items-center transition-colors ${currentView === 'dashboard' ? 'text-indigo-600' : 'text-slate-400'}`}
                >
                    <Briefcase size={24} />
                    <span className="text-xs font-medium mt-1">Jobs</span>
                </button>
                <button 
                    onClick={() => setView('settings')}
                    className={`flex flex-col items-center transition-colors ${currentView === 'settings' ? 'text-indigo-600' : 'text-slate-400'}`}
                >
                    <UserIcon size={24} />
                    <span className="text-xs font-medium mt-1">Profile</span>
                </button>
                </nav>
            )}
        </div>
      </div>
    </div>
  );
};