import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { User, Job, ChatMessage } from '../types';
import { api } from '../services/store';
import { auth, db } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, onSnapshot, collection, query, where, orderBy } from 'firebase/firestore';

type AppView = 'dashboard' | 'settings';

interface AppContextType {
  user: User | null;
  isLoading: boolean;
  currentView: AppView;
  setView: (view: AppView) => void;
  login: (email: string, password: string) => Promise<void>;
  socialLogin: (provider: string, email: string, name: string) => Promise<void>;
  register: (data: Partial<User>) => Promise<void>;
  logout: () => void;
  updateUserProfile: (data: Partial<User>) => Promise<void>;
  refreshUser: () => void;
  requestNotificationPermission: () => Promise<void>;
}

// Helper: Haversine Formula for distance in km
function getDistanceFromLatLonInKm(lat1: number, lon1: number, lat2: number, lon2: number) {
  var R = 6371; // Radius of the earth in km
  var dLat = deg2rad(lat2-lat1);
  var dLon = deg2rad(lon2-lon1); 
  var a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2)
    ; 
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  var d = R * c; // Distance in km
  return d;
}

function deg2rad(deg: number) {
  return deg * (Math.PI/180)
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [currentView, setView] = useState<AppView>('dashboard');
  
  const lastJobCheckRef = useRef<number>(Date.now());
  const lastMessageCheckRef = useRef<number>(Date.now());

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        // Listen to user document
        const userRef = doc(db, 'users', firebaseUser.uid);
        const unsubscribeUser = onSnapshot(userRef, (docSnap) => {
          if (docSnap.exists()) {
            setUser(docSnap.data() as User);
          } else {
            setUser(null);
          }
          setIsLoading(false);
        }, (error) => {
          console.error("Error fetching user data:", error);
          setIsLoading(false);
        });

        return () => unsubscribeUser();
      } else {
        setUser(null);
        setIsLoading(false);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // --- Real-time Notification Logic ---
  useEffect(() => {
    if (!user) return;

    // Listen for new jobs (Worker only)
    let unsubscribeJobs: () => void;
    if (user.role === 'worker') {
      const jobsQuery = query(collection(db, 'jobs'), where('status', '==', 'OPEN'), orderBy('postedAt', 'desc'));
      unsubscribeJobs = onSnapshot(jobsQuery, (snapshot) => {
        const notificationsEnabled = user.notificationsEnabled ?? user.workerProfile?.notificationsEnabled ?? false;
        if (!notificationsEnabled) return;

        snapshot.docChanges().forEach((change) => {
          if (change.type === 'added') {
            const job = change.doc.data() as Job;
            if (job.postedAt > lastJobCheckRef.current) {
              lastJobCheckRef.current = Date.now();

              // 1. Check Category Match
              const hasCategory = user.workerProfile?.categories.includes(job.category);
              
              // 2. Check Location Match
              let hasLocation = false;
              if (user.coords && job.coords) {
                  const dist = getDistanceFromLatLonInKm(
                      user.coords.lat, user.coords.lng,
                      job.coords.lat, job.coords.lng
                  );
                  if (dist <= 30) hasLocation = true;
              }
              if (!hasLocation) {
                  const userLoc = user.location?.toLowerCase() || '';
                  const jobLoc = job.location?.toLowerCase() || '';
                  if (userLoc && jobLoc && (jobLoc.includes(userLoc) || userLoc.includes(jobLoc))) {
                      hasLocation = true;
                  }
                  if (!userLoc) hasLocation = true; 
              }

              if (hasCategory && hasLocation) {
                  sendSystemNotification(
                      `New ${job.category} Job Nearby!`,
                      `${job.title} in ${job.location}`,
                      'job-alert'
                  );
              }
            }
          }
        });
      });
    }

    // Listen for new messages
    const messagesQuery = query(collection(db, 'messages'), orderBy('timestamp', 'asc'));
    const unsubscribeMessages = onSnapshot(messagesQuery, (snapshot) => {
      const notificationsEnabled = user.notificationsEnabled ?? user.workerProfile?.notificationsEnabled ?? false;
      if (!notificationsEnabled) return;

      snapshot.docChanges().forEach((change) => {
        if (change.type === 'added') {
          const msg = change.doc.data() as ChatMessage;
          if (msg.timestamp > lastMessageCheckRef.current && msg.senderId !== user.id) {
            lastMessageCheckRef.current = Date.now();
            
            // We need to fetch the job to know if it's for us
            // In a real app, we'd probably query messages where we are a participant
            // For now, we'll just check if we are involved in the job
            api.getJobById(msg.jobId).then(job => {
              if (!job) return;
              let isForMe = false;
              let title = 'New Message';

              if (user.role === 'client' && job.clientId === user.id) {
                  isForMe = true;
                  title = `Message from ${job.assignedWorkerName || 'Worker'}`;
              } else if (user.role === 'worker' && job.assignedWorkerId === user.id) {
                  isForMe = true;
                  title = `Message from ${job.clientName || 'Client'}`;
              }

              if (isForMe) {
                  sendSystemNotification(
                      title,
                      msg.text,
                      'chat-alert'
                  );
              }
            });
          }
        }
      });
    });

    return () => {
      if (unsubscribeJobs) unsubscribeJobs();
      if (unsubscribeMessages) unsubscribeMessages();
    };
  }, [user]);

  // Helper to send actual browser notification
  const sendSystemNotification = (title: string, body: string, soundType: 'job-alert' | 'chat-alert') => {
      const audio = new Audio(
          soundType === 'job-alert' 
              ? 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3' 
              : 'https://assets.mixkit.co/active_storage/sfx/2354/2354-preview.mp3' 
      );
      audio.play().catch(e => console.log("Audio play failed (user interaction needed first)", e));

      if (Notification.permission === 'granted') {
          const notif = new Notification(title, {
              body: body,
              icon: 'https://cdn-icons-png.flaticon.com/512/3043/3043233.png',
              tag: Date.now().toString() 
          });
          
          notif.onclick = () => {
              window.focus();
              notif.close();
          };
      }
  };

  const refreshUser = () => {
    // User is automatically refreshed via onSnapshot
  }

  const login = async (email: string, pass: string) => {
    setIsLoading(true);
    try {
      await api.login(email, pass);
      setView('dashboard');
      lastJobCheckRef.current = Date.now();
      lastMessageCheckRef.current = Date.now();
    } finally {
      setIsLoading(false);
    }
  };

  const socialLogin = async (provider: string, email: string, name: string) => {
      setIsLoading(true);
      try {
          await api.socialLogin(provider, email, name);
          setView('dashboard');
          lastJobCheckRef.current = Date.now();
          lastMessageCheckRef.current = Date.now();
      } finally {
          setIsLoading(false);
      }
  };

  const register = async (data: Partial<User>) => {
    setIsLoading(true);
    try {
      await api.register(data);
      setView('dashboard');
      lastJobCheckRef.current = Date.now();
      lastMessageCheckRef.current = Date.now();
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    await api.logout();
    setView('dashboard');
  };

  const updateUserProfile = async (data: Partial<User>) => {
    setIsLoading(true);
    try {
      await api.updateUser(data);
    } finally {
      setIsLoading(false);
    }
  };

  const requestNotificationPermission = async () => {
      if (!('Notification' in window)) {
          console.warn("This browser does not support desktop notification");
          return;
      }
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
          new Notification("Notifications Enabled", { 
              body: "You will now receive real-time job and chat alerts!",
              icon: 'https://cdn-icons-png.flaticon.com/512/3043/3043233.png'
          });
      }
  };

  return (
    <AppContext.Provider value={{ user, isLoading, currentView, setView, login, socialLogin, register, logout, updateUserProfile, refreshUser, requestNotificationPermission }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};